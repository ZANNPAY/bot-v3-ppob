/**
   * Create By Anantha
   * Contact Me on wa.me/6285174667722
   * Follow 
*/

require('./config')
const { BufferJSON, WA_DEFAULT_EPHEMERAL, generateWAMessageFromContent, proto, generateWAMessageContent, generateWAMessage, prepareWAMessageMedia, areJidsSameUser, getContentType } = require('@whiskeysockets/baileys')
const axios = require('axios')
const FileType = require('file-type')
const fetch = require('node-fetch')
const crypto = require('crypto')
const fs = require('fs')
const { sizeFormatter} = require("human-readable")
const format = sizeFormatter()
const os = require('os');
const { exec } = require("child_process");
const speed = require('performance-now');
const util = require('util')
const chalk = require('chalk')
const moment = require('moment-timezone');
const { clockString, getTime, isUrl, sleep, runtime, fetchJson, getBuffer, jsonformat, reSize, generateProfilePicture, getRandom } = require('./SETTING/GET_API/myfunc')
const jam = moment.tz('asia/makassar').format('HH:mm:ss')
const ms = toMs = require('ms');
const { color, bgcolor } = require('./SETTING/GET_API/color')
const { merchant, secret, signature, digiuser, digiapi, OpenAikey, nomorKu } = require("./SETTING/GET_API/apikey")
global.tanggalserver = `${moment.tz(`Asia/${global.Wilayah}`).format('DD/MM/YY')}`;
const { getHarga } = require('./SETTING/GET_API/getHarga')
const { getProduk } = require('./SETTING/GET_API/getpro')
const { getPasca } = require('./SETTING/GET_API/getPasca')
const { getLayanann } = require('./SETTING/GET_API/getSmm'); 
const api_key = "9hg0pjrcztur46gh3728ip0joytnluf";
const secret_key = "y831jmeebnqrlowrd7f94n79yigkt60u6shmxz10pa5u3ojc8v";
global.waktuserver = `${moment.tz(`Asia/${global.Wilayah}`).format('HH:mm:ss')}`;         
let http = require('http')
            http.get({'host': 'api.ipify.org', 'port': 80, 'path': '/'}, function(resp) {
            resp.on('data', function(ip) {
                (global.ipserver = ip);
            })
          })

global.db = JSON.parse(fs.readFileSync('./SETTING/DB/database.json'))
if (global.db) global.db = {
sticker: {},
database: {}, 
game: {},
others: {},
users: {},
chats: {},
...(global.db || {})
}

global.limitawal = {
    premium: "Infinity",
    free: 100
}

module.exports = AnanthaGanz = async (AnanthaGanz, m, chatUpdate, store) => {
try {
        var body = (m.mtype === 'conversation') ? m.message.conversation : (m.mtype == 'imageMessage') ? m.message.imageMessage.caption : (m.mtype == 'videoMessage') ? m.message.videoMessage.caption : (m.mtype == 'extendedTextMessage') ? m.message.extendedTextMessage.text : (m.mtype == 'buttonsResponseMessage') ? m.message.buttonsResponseMessage.selectedButtonId : (m.mtype == 'listResponseMessage') ? m.message.listResponseMessage.singleSelectReply.selectedRowId : (m.mtype == 'templateButtonReplyMessage') ? m.message.templateButtonReplyMessage.selectedId : (m.mtype === 'messageContextInfo') ? (m.message.buttonsResponseMessage?.selectedButtonId || m.message.listResponseMessage?.singleSelectReply.selectedRowId || m.text) : ''
        var budy = (typeof m.text == 'string' ? m.text : '')
        global.prefix = prefa ? /^[°•π÷×¶∆£¢€¥®™+✓_=|~!?@#$%^&.©^]/gi.test(body) ? body.match(/^[°•π÷×¶∆£¢€¥®™+✓_=|~!?@#$%^&.©^]/gi)[0] : "" : prefa ?? global.prefix
                global.prefix
        const isCmd = body.startsWith(prefix)
        const command = body.replace(prefix, '').trim().split(/ +/).shift().toLowerCase()
        var args = body.trim().split(/ +/).slice(1)
        args = args.concat(['','','','','',''])
        const pushname = m.pushName || "No Name"
        const botNumber = global.botNumber
        const sender = m.isGroup ? (m.key.participant ? m.key.participant : m.participant) : m.key.remoteJid
        const dengan_nol = sender.split('@')[0].replace('62', '0');
        const isOwner = [`${owner}@s.whatsapp.net`] == sender ? true : [`${owner}@s.whatsapp.net`].includes(sender) ? true : false
        const itsMe = m.sender == botNumber ? true : false
        const text = q = args.join(" ").trim()
        const fatkuns = (m.quoted || m)
       const quoted = (
    fatkuns.mtype == 'buttonsMessage'
) ? fatkuns[Object.keys(fatkuns)[1]] : (
    fatkuns.mtype == 'templateMessage' && fatkuns.hydratedTemplate && Object.keys(fatkuns.hydratedTemplate).length > 1
) ? fatkuns.hydratedTemplate[Object.keys(fatkuns.hydratedTemplate)[1]] : (
    fatkuns.mtype == 'product'
) ? fatkuns[Object.keys(fatkuns)[0]] : (
    m.quoted ? m.quoted : m
);
        const mime = (quoted.msg || quoted).mimetype || ''
        const qmsg = (quoted.msg || quoted)
        const isMedia = /image|video|sticker|audio/.test(mime)         
        const from = m.key.remoteJid    
        const groupMetadata = m.isGroup ? await AnanthaGanz.groupMetadata(m.chat).catch(e => {}) : ''
        const groupName = m.isGroup ? groupMetadata.subject : ''
        const participants = m.isGroup ? await groupMetadata.participants : ''
        const groupAdmins = m.isGroup ? await participants.filter(v => v.admin !== null).map(v => v.id) : ''
        const groupOwner = m.isGroup ? groupMetadata.owner : ''
        const groupMembers = m.isGroup ? groupMetadata.participants : ''
    	const isBotAdmins = m.isGroup ? groupAdmins.includes(botNumber) : false
        const isGroupAdmins = m.isGroup ? groupAdmins.includes(m.sender) : false
    	const isAdmins = m.isGroup ? groupAdmins.includes(m.sender) : false
	    const tanggal = moment().tz(`Asia/${global.Wilayah}`).format("ll")
   	    const mentionUser = [...new Set([...(m.mentionedJid || []), ...(m.quoted ? [m.quoted.sender] : [])])]    
	try {
            const isNumber = x => typeof x === 'number' && !isNaN(x)
const user = global.db.users[m.sender]
if (typeof user !== 'object') global.db.users[m.sender] = {}
const chats = global.db.chats[m.chat]
if (typeof chats !== 'object') global.db.chats[m.chat] = {}
if (user) {
if (!isNumber(user.afkTime)) user.afkTime = -1
if (!('afkReason' in user)) user.afkReason = ''
} else global.db.users[m.sender] = {
afkTime: -1,
afkReason: '',
}
} catch (err) {
console.error(err)
}
const reply = (teks) => {AnanthaGanz.sendMessage(from, { text: teks }, { quoted: m })}
for (let jid of mentionUser) {
let user = global.db.users[jid]
if (!user) continue
let afkTime = user.afkTime
if (!afkTime || afkTime < 0) continue
let reason = user.afkReason || ''
m.reply(`Jangan tag dia bang, orangnya lagi AFK\n
${reason ? 'Alasan : ' + reason : 'Alasan : Nothing.'}
Selama ${clockString(new Date - afkTime)}
`.trim())
}
if (db.users[m.sender].afkTime > -1) {
let user = global.db.users[m.sender]
m.reply(`
@${pushname} sudah kembali dari AFK\n
Selama : ${clockString(new Date - user.afkTime)}
`.trim())
user.afkTime = -1
user.afkReason = ''
}    

      if (m.message) {
            AnanthaGanz.readMessages([key])  // Fungsi ini digunakan untuk membaca pesan. 'key' mungkin merupakan parameter atau variabel yang mewakili kunci untuk pengambilan pesan.

console.log(
  chalk.black(chalk.bgWhite('[ PESAN ]')),  // Mencatat latar belakang putih dengan teks hitam dan '[ PESAN ]' di tengah
  chalk.black(chalk.bgGreen(new Date)),     // Mencatat tanggal saat ini dengan latar belakang hijau dan teks hitam
  chalk.black(chalk.bgBlue(budy || m.mtype)) + '\n' +  // Mencatat 'budy' atau 'm.mtype' dengan latar belakang biru dan teks hitam
  chalk.magenta('=> Dari'),  // Mencatat '=> Dari' dalam warna magenta
  chalk.green(pushname),     // Mencatat 'pushname' dalam warna hijau
  chalk.yellow(dengan_nol) + '\n' +  // Mencatat 'm.sender' dalam warna kuning
  chalk.blueBright('=> Di'),  // Mencatat '=> Di' dalam warna biru cerah
  chalk.green(m.isGroup ? pushname : 'Private Chat', dengan_nol)  // Mencatat 'pushname' jika 'm.isGroup' bernilai true, jika tidak 'Private Chat', dalam warna hijau
)
        }

const fs = require('fs');

const getDepoData = () => {
    return JSON.parse(fs.readFileSync(`./SETTING/DB/TRANSACTION/Api/Deposit/${cek("deposit", m.sender)}.json`));
};

const checkUserData = (userId, property) => {
    const deppo = getDepoData();
    const userData = Object.values(deppo).find(data => data.id === userId);
    return userData ? userData[property] : null;
};

const checkIdDepo = (userId) => {
    return !!checkUserData(userId, 'id');
};

const checkRefDepo = (userId) => {
    return checkUserData(userId, 'ref');
};

const checkStsDepo = (userId) => {
    return checkUserData(userId, 'status');
};

const checkIdBuy = (userId) => {
    return !!checkUserData(userId, 'id');
};

const checkRefBuy = (userId) => {
    return checkUserData(userId, 'ref');
};

if (command) {

}
function formatmoney(amount, options = {}) {
  const {
    currency = "IDR",
    locale = "id",
    minimumFractionDigits = 0,
    maximumFractionDigits = 0,
    useSymbol = true
  } = options;

  const formattedAmount = amount.toLocaleString(locale, {
    style: "currency",
    currency,
    minimumFractionDigits,
    maximumFractionDigits,
  });

  return useSymbol ? formattedAmount : formattedAmount.replace(/[^\d.,]/g, '');
}
async function loading() {
    const frames = ["Z", "ZA", "ZAN", "ZANN", "ZANNS", "ZANNST", "ZANNSTO", "ZANNSTOR", "ZANNSTORE"]; // Simbol untuk animasi loading
    const loadingFrames = ["⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧"]; // Simbol untuk loading frames

    let message = await AnanthaGanz.sendMessage(from, { text: `${frames[0]}. ${loadingFrames[0]}` }); // Menambahkan titik dan loading frame pada teks pertama
    let i = 1;
    let j = 1;

    const interval = setInterval(async () => {
        if (i === frames.length) {
            clearInterval(interval);
            await AnanthaGanz.sendMessage(from, { text: `ZANNSTORE`, edit: message.key });
        } else {
            await AnanthaGanz.sendMessage(from, { text: `${frames[i]}. ${loadingFrames[j]}`, edit: message.key }); // Menambahkan titik dan loading frame pada setiap frame
            i++;
            j = (j + 1) % loadingFrames.length; // Pilih frame berikutnya dari loading frames
        }
    }, 500); // Mengubah interval menjadi 500 ms
    // Simulasi proses loading (gantilah dengan proses nyata Anda)
    await new Promise(resolve => setTimeout(resolve, 5000)); // Menunggu teks "ZANNSTORE." terisi penuh
}
const sendContact = (jid, numbers, name, quoted, mn) => {
let number = numbers.replace(/[^0-9]/g, '')
const vcard = 'BEGIN:VCARD\n' 
+ 'VERSION:3.0\n' 
+ 'FN:' + name + '\n'
+ 'ORG:;\n'
+ 'TEL;type=CELL;type=VOICE;waid=' + number + ':+' + number + '\n'
+ 'END:VCARD'
return AnanthaGanz.sendMessage(from, { contacts: { displayName: name, contacts: [{ vcard }] }, mentions : mn ? mn : []},{ quoted: quoted })
}

function generateRandomString(length) {
  const chars = '1234567890';
  let result = '';
  const randomBytes = crypto.randomBytes(length);

  for (let i = 0; i < length; i++) {
    const byte = randomBytes[i] % chars.length;
    result += chars.charAt(byte);
  }

  return result.toLowerCase();
}

function generateRandomDateCode() {
  const now = new Date();
  const month = String(now.getMonth() + 1).padStart(2, '0');
  const date = String(now.getDate()).padStart(2, '0');
  const randomCode = generateRandomString(4); // Ubah panjang kode acak sesuai kebutuhan
  return `${date}${month}${randomCode}`;
}
function generateRandomString1(length) {
  const chars = '11223344556677889911100';
  let result = '';
  const randomBytes = crypto.randomBytes(length);

  for (let i = 0; i < length; i++) {
    const byte = randomBytes[i] % chars.length;
    result += chars.charAt(byte);
  }

  return result.toLowerCase();
}
    const mentions = (teks, memberr, id) => {
(id == null || id == undefined || id == false) ? AnanthaGanz.sendMessage(from, {text: teks.trim(), jpegThumbnail: global.AnanthaGanzmenu}, text, { sendEphemeral: true, contextInfo: { mentions: memberr } }) : AnanthaGanz.sendMessage(from, {text: teks.trim(), jpegThumbnail: global.AnanthaGanzmenu}, text, { sendEphemeral: true, quoted: m, contextInfo: { mentions: memberr } })
}
    
const randomPay = generateRandomString(8);
const pascarandom = generateRandomString(4);
const angkaString = generateRandomString1(3);
const erg = generateRandomString(2);
function boolToString(value) {
  return value ? 'iyah' : 'tidak';
}

const formatp = sizeFormatter({
  std: 'JEDEC', //'SI' = default | 'IEC' | 'JEDEC'
  decimalPlaces: 2,
  keepTrailingZeroes: false,
  render: (literal, symbol) => `${literal} ${symbol}B`,
})

const isUrl = (url) => {
  return url.match(new RegExp(/https?:\/\/(www\.)?[-a-zA-Z0-9@:%._+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b([-a-zA-Z0-9()@:%_+.~#?&/=]*)/, 'gi'))
}

const jsonformat = (string) => {
  return JSON.stringify(string, null, 2)
}

// Berfungsi Untuk Hit Api & Mengirim Data Headers
const fetchJson = async (url, options) => {
  try {
      options ? options : {}
      const res = await axios({
          method: 'GET',
          url: url,
          headers: {
              'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/95.0.4638.69 Safari/537.36'
          },
          ...options
      })
      return res.data
  } catch (err) {
      return err
  }
}
let r = JSON.parse(fs.readFileSync('./SETTING/DB/datadigiflaz.json'))
let aa = JSON.parse(fs.readFileSync('./SETTING/DB/user.json'))
const daftar = () => {
m.reply(`You are not registered yet`)
}
let user = JSON.parse(fs.readFileSync('./SETTING/DB/user.json'))
const cek = (satu, dua) => { 
let x1 = false
Object.keys(user).forEach((i) => {
if (user[i].id == dua){x1 = i}})
if (x1 !== false) {
if (satu == "id"){ return user[x1].id }
if (satu == "product_name"){ return user[x1].product_name }
if (satu == "price"){ return user[x1].price }
if (satu == "saldo"){ return user[x1].saldo }
if (satu == "tanggal_deposit"){ return user[x1].tanggal_deposit }    
if (satu == "deposit"){ return user[x1].deposit }
if (satu == "reff_deposit"){ return user[x1].reff_deposit }
if (satu == "tujuan"){ return user[x1].tujuan }   
 if (satu == "reff"){ return user[x1].reff }   
if (satu == "desc"){ return user[x1].desc }
if (satu == "status"){ return user[x1].status }    
if (satu == "buyer_sku_code"){ return user[x1].buyer_sku_code }
if (satu == "email"){ return user[x1].email }
if (satu == "verfiyemail"){ return user[x1].verfiyemail }
if (satu == "level"){ return user[x1].level }
if (satu == "desc_prabayar"){ return user[x1].desc_prabayar }
if (satu == "syarat"){ return user[x1].syarat }
if (satu == "layanan"){ return user[x1].layanan }
if (satu == "verificationCode"){ return user[x1].verificationCode }
if (satu == "cekVerify"){ return user[x1].cekVerify }

}
if (x1 == false) { return null } 
}
let sett = (satu, dua, tiga) => { 
Object.keys(user).forEach((i) => {
if (user[i].id == dua){
if (satu == "+saldo")
{ user[i].saldo += tiga
fs.writeFileSync('./SETTING/DB/user.json', JSON.stringify(user))}
if (satu == "-saldo"){
user[i].saldo -= tiga
fs.writeFileSync('./SETTING/DB/user.json', JSON.stringify(user))}
if (satu == "price"){ user[i].price = tiga
fs.writeFileSync('./SETTING/DB/user.json', JSON.stringify(user))}
if (satu == "email"){ user[i].email = tiga
fs.writeFileSync('./SETTING/DB/user.json', JSON.stringify(user))}
if (satu == "tanggal_trx"){ user[i].tanggal_trx = tiga
fs.writeFileSync('./SETTING/DB/user.json', JSON.stringify(user))}    
if (satu == "tanggal_deposit"){ user[i].tanggal_deposit = tiga
fs.writeFileSync('./SETTING/DB/user.json', JSON.stringify(user))} 
 if (satu == "status"){ user[i].status = tiga
fs.writeFileSync('./SETTING/DB/user.json', JSON.stringify(user))}
if (satu == "product_name"){ user[i].product_name = tiga
fs.writeFileSync('./SETTING/DB/user.json', JSON.stringify(user))}
if (satu == "reff"){ user[i].reff = tiga
fs.writeFileSync('./SETTING/DB/user.json', JSON.stringify(user))}
if (satu == "deposit"){ user[i].deposit = tiga
fs.writeFileSync('./SETTING/DB/user.json', JSON.stringify(user))}
if (satu == "reff_deposit"){ user[i].reff_deposit = tiga
fs.writeFileSync('./SETTING/DB/user.json', JSON.stringify(user))}
if (satu == "buyer_sku_code"){ user[i].buyer_sku_code = tiga
fs.writeFileSync('./SETTING/DB/user.json', JSON.stringify(user))}
if (satu == "tujuan"){ user[i].tujuan = tiga
fs.writeFileSync('./SETTING/DB/user.json', JSON.stringify(user))}
if (satu == "desc"){ user[i].desc = tiga
fs.writeFileSync('./SETTING/DB/user.json', JSON.stringify(user))}
if (satu == "verfiyemail"){ user[i].verfiyemail = tiga
fs.writeFileSync('./SETTING/DB/user.json', JSON.stringify(user))}
if (satu == "level"){ user[i].level = tiga
fs.writeFileSync('./SETTING/DB/user.json', JSON.stringify(user))}
if (satu == "desc_prabayar"){ user[i].desc_prabayar = tiga
fs.writeFileSync('./SETTING/DB/user.json', JSON.stringify(user))}
if (satu == "syarat"){ user[i].syarat = tiga
fs.writeFileSync('./SETTING/DB/user.json', JSON.stringify(user))}
if (satu == "layanan"){ user[i].layanan = tiga
fs.writeFileSync('./SETTING/DB/user.json', JSON.stringify(user))}
if (satu == "verificationCode"){ user[i].verificationCode = tiga
fs.writeFileSync('./SETTING/DB/user.json', JSON.stringify(user))}
if (satu == "cekVerify"){ user[i].cekVerify = tiga
fs.writeFileSync('./SETTING/DB/user.json', JSON.stringify(user))}

}})
}
if (cek("id", m.sender) == null) {
    if (m.sender == nomorKu) { // Ganti "id_pemilik" dengan ID pemilik yang valid
        user.push({
            id: m.sender,
            product_name: "",
            tujuan: "",
            price: 0,
            email: "Belum Verifikasi Email",
            saldo: 0,
            reff: "",
            buyer_sku_code: "",
            status: true,
            desc: "",
            deposit: "",
            syarat: true,
            reff_deposit: true,
            tanggal_deposit: "",
            desc_prabayar: "",
            verfiyemail: true,
            cekVerify: true,
            verificationCode: "",
            wilayah: "Makassar",
            level: "Premium", // Jika pemilik, set level menjadi "Premium"
            layanan: ""
        });
    } else {
        user.push({
            id: m.sender,
            product_name: "",
            tujuan: "",
            price: 0,
            email: "Belum Verifikasi Email",
            saldo: 0,
            reff: "",
            buyer_sku_code: "",
            status: true,
            desc: "",
            deposit: "",
            syarat: true,
            reff_deposit: true,
            tanggal_deposit: "",
            desc_prabayar: "",
            verfiyemail: true,
            cekVerify: true,
            verificationCode: "",
            wilayah: "Makassar",
            level: "Basic", // Jika bukan pemilik, set level menjadi "Basic"
            layanan: ""
        });
    }
fs.writeFileSync('./SETTING/DB/user.json', JSON.stringify(user))
let te = `Yo, ${m.pushName}! Akun Kamu Udah Dibuatin, Tinggal Kamu Melakukan Verifikasi aja untuk lanjutin :)\n\n${toko}`;
  AnanthaGanz.sendPoll(m.chat, te,["Menu",".setemail","Syarat & Ketentuan [ Wajib ]"])
}
if (command) {
AnanthaGanz.readMessages([m.key]) 
}


const nodemailer = require('nodemailer');
function cancelPay() {
        let axios = require('axios');
        let md5 = require('md5');
        let FormData = require('form-data');
        let keynya = global.key;
        var data = new FormData();
        let uni = `${cek("deposit", m.sender)}`
        let signnya = md5(keynya + uni + 'CancelTransaction'); // Fixed the signature calculation
         
        data.append('key', keynya);
        data.append('request', "cancel");
        data.append('unique_code', uni);
        data.append('signature', signnya);

        var config = {
            method: 'post',
            maxBodyLength: Infinity,
            url: 'https://paydisini.co.id/api/',
            headers: { 
                ...data.getHeaders()
            },
            data: data
        };

        axios(config)
        .then(function (response) {
            fs.unlinkSync(`./SETTING/DB/TRANSACTION/Api/Deposit/${cek("deposit", m.sender)}.json`);
            sendExpDepo(sender);
            setTimeout(() => {
                sett("deposit", m.sender, "");
            }, 5000);
        })
        .catch(function (error) {
            console.log(error);
        });
        }
         function createReceipt() {
        const { createCanvas, loadImage } = require('canvas');
const path = require('path');
  const width = 800; // Lebar struk
  const height = 1200; // Tinggi struk
  const canvas = createCanvas(width, height);
  const context = canvas.getContext('2d');

  // Mengatur warna latar belakang
  context.fillStyle = '#fff';
  context.fillRect(0, 0, width, height);

  // Menambahkan teks 'ZANNSTOREE' dan tanggal dengan posisi yang disesuaikan
  context.font = 'bold 30px Arial';
  context.fillStyle = '#000';
  context.textAlign = 'left';
  context.fillText('ZANNSTORE', 10, 150); // Posisi disesuaikan
  context.font = '25px Arial';
  context.fillText(`${cek("waktupesanan", m.sender)}`, 10, 200); // Posisi disesuaikan
  context.textAlign = 'center';
  context.font = 'italic 30px Arial';
  context.fillText('===============================', width / 2, 220);

  // Menambahkan detail transaksi dengan font yang lebih besar
  context.textAlign = 'center';
  context.font = 'bold 40px Arial';
  context.fillText('STRUK PEMBELIAN', width / 2, 330);
  context.fillStyle = '#000';
  context.textAlign = 'left';
  context.font = 'serif 35px Arial';
  context.fillText(`\nID TRX : ${cek("idtrx", m.sender)}`, 10, 380);
  context.fillText(`\nLayanan : ${cek("nama", m.sender)}`, 10, 420);
  context.fillText(`\nTujuan : ${cek("target", m.sender)}`, 10, 460);
  context.fillText(`\nHarga : ${cek("harga", m.sender)}`, 10, 500);
  context.fillText('\nStatus : Succes', 10, 540);
  
  context.textAlign = 'center';
  context.font = 'bold 40px Arial';
  context.fillText('SN/KODE/TOKEN :', width / 2, 680);
  context.font = 'bold 12px Arial';
  context.fillText(`${cek("token", m.sender)}`, width / 2, 750);
  
  context.textAlign = 'center';
  context.font = 'italic 30px Arial';
  context.fillText('===============================', width / 2, 890);
  context.textAlign = 'center';
  context.font = 'italic 30px Arial';
  context.fillText('JASA TOPUP ALL GAME & TOPUP LAINNYA', width / 2, 950);
  
  // Menambahkan instruksi di bawah serial number
  context.textAlign = 'center';
  context.font = 'italic 35px Arial';
  context.fillText('Thank You', width / 2, 1000);


  let filename = `./SETTING/DB/TRANSACTION/${cek("idtrx", m.sender)}.png`
  const buffer = canvas.toBuffer('image/png');
  fs.writeFileSync(filename, buffer);
  let metida = fs.readFileSync(filename);
  AnanthaGanz.sendMessage(from,{image: metida, caption: "for" },  { quoted: m })
  setTimeout(() => {
  sett("idtrx", m.sender, "")
sett("nama", m.sender, "")
sett("target", m.sender, "")  
sett("harga", m.sender, "")  
sett("token", m.sender, "")  
sett("waktupesanan", m.sender, "")
  fs.unlinkSync(filename);
  }, 4000);
}




function sendConfirmationEmail(email, code) {
    // Simpan kode konfirmasi bersama dengan alamat email pengguna
let dia = cek("id", m.sender)
    // Konfigurasi transporter untuk Gmail SMTP
    let transporter = nodemailer.createTransport({
        service: 'gmail',
        auth: {
            user: `${global.emailNotif}`,
            pass: `${pwNotif}`
        }
    });

    // Siapkan email yang akan dikirim
    let mailOptions = {
        from: `${global.emailNotif}`,
        to: email,
        subject: `Code Verifikasi! ${footer}`,
        html: `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Verifikasi Akun Kamu</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .container {
            text-align: center;
        }

        h2 {
            color: #333;
        }

        p {
            color: #666;
        }

        .btn {
            display: inline-block;
            background-color: #007bff;
            color: #fff;
            padding: 10px 20px;
            text-decoration: none;
            border-radius: 5px;
            margin-top: 20px;
            transition: background-color 0.3s ease;
        }

        .btn:hover {
            background-color: #0056b3;
        }

        .powered {
            margin-top: 20px;
            font-size: 12px;
            color: #999;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>ZANNSTORE - PT ZANNPAY INDONESIA</h2>
        <p>Yuk Klik Tombol Verifikasi Di bawah ini agar akun kamu cepat terverifikasi! :)</p>
        <a href="https://api.whatsapp.com/send?phone=6285174667722&text=Registrasi%20${code}" class="btn">Confirm Register</a>
        <p class="powered">Powered by Anantha</p>
    </div>
</body>
</html>`
    };
sett("verificationCode", dia, `${code}`)
    // Kirim email
    transporter.sendMail(mailOptions, function(error, info){
        if (error) {
            console.log(error);
        } else {
            console.log('Berhasil Mengirim Email : ' + info.response);
        }
    });
}
function sendEmail() {
    // Konfigurasi transporter untuk Gmail SMTP
    let transporter = nodemailer.createTransport({
        service: 'gmail',
        auth: {
            user: `${global.emailNotif}`,
            pass: `${pwNotif}`
        }
    });

    // Siapkan email yang akan dikirim
    let mailOptions = {
    from: `${global.emailNotif}`,
    to: `${cek("email", m.sender)}`,
    subject: `Yeyy! Makasih ya udah bergabung`,
    html: `
<!DOCTYPE html>
<html>
<head>
<title>Yeyy! Pendaftaran Akun kamu berhasil</title>
<style>
    body {
        background-color: #3498db;
        font-family: Arial, sans-serif;
        margin: 0;
        padding: 0;
    }
    .content {
        padding: 20px;
        background-color: rgba(255, 255, 255, 0.8);
        border-radius: 10px;
        margin: 50px auto;
        max-width: 600px;
        text-align: center;
    }
    .button {
        border: none;
        padding: 10px;
        text-align: center;
        text-decoration: none;
        display: inline-block;
        font-size: 14px;
        margin: 4px 2px;
        cursor: pointer;
        border-radius: 50%;
        width: 50px;
        height: 50px;
        transition-duration: 0.4s;
        background-size: 70%;
        background-repeat: no-repeat;
        background-position: center;
    }
    .whatsapp, .instagram, .telegram {
        position: fixed;
        bottom: 10px;
        width: 30px;
        height: 30px;
        background-size: cover;
        border-radius: 50%;
        transition: transform 0.3s ease;
    }
    .whatsapp:hover, .instagram:hover, .telegram:hover {
        transform: scale(1.1);
    }
    .whatsapp {
        left: 10px;
        background-image: url('https://telegra.ph/file/501bd6f9e379a0799c562.jpg');
    }
    .instagram {
        left: 50px;
        background-image: url('https://upload.wikimedia.org/wikipedia/commons/a/a5/Instagram_icon.png');
    }
    .telegram {
        left: 90px;
        background-image: url('https://telegra.ph/file/d00d6fc6e399068d1223e.jpg');
    }
    .button:hover {
        opacity: 0.8;
    }
</style>
</head>
<body>

<div class="content">
    <h2>Makasih ya :)</h2>
    <p>
        Yoo ${pushname},<br><br>
        Yeyy zan punya teman baru! Hehe, makasih telah mendaftar di ${footer}. Zan senang sekali punya teman.<br><br>
        <h2>Ini ya detail akun kamu :</h2>
        <p><strong>Nama :</strong> ${pushname}</p>
        <p><strong>Email :</strong> ${cek("email", m.sender)}</p>
        <p><strong>Level :</strong> ${cek("level", m.sender)}</p>
        <p><strong>Saldo :</strong> ${cek("saldo", m.sender)}</p>
        <p><strong>Nomor :</strong> ${dengan_nol}</p>
        Kalo kamu ada yang ditanya atau dibantu, langsung aja <a href="https://wa.me/${owner}" style="color: #3498db; text-decoration: none;">WhatsApp</a>.<br><br>
        Makasih banget ya udah percaya sama zan :)<br><br>
        Cheers,<br>
        © ＰＴ ＺＡＮＮＰＡＹ ＩＮＤＯＮＥＳＩＡ
    </p>
    <div class="button-container">
        <a href="https://wa.me/${owner}" class="button">
            <div class="whatsapp"></div>
        </a>
        <a href="https://instagram.com/zannstore_real" class="button">
            <div class="instagram"></div>
        </a>
        <a href="https://t.me/CsZannstore" class="button">
            <div class="telegram"></div>
        </a>
    </div>
    <div class="footer" style="text-align: center; color: #ccc;">
        <p>Powered by Anantha</p>
    </div>
</div>

</body>
</html>`
};

    // Kirim email
    transporter.sendMail(mailOptions, function(error, info){
        if (error) {
            console.log(error);
        } else {
            console.log('Email sent: ' + info.response);
        }
    });
}


          /* Fuction DEPOSIT BERHASIL*/
            function sendEmailDepo(sender, pushname, ref_sender, method, price_sender, fee_sender, total_sender) {
                const transporter = nodemailer.createTransport({
                    service: 'gmail',
                    auth: {
            user: `${global.emailNotif}`,
            pass: `${pwNotif}`
        }
    });

    // Siapkan email yang akan dikirim
    let mailOptions = {
    from: `${global.emailNotif}`,
    to: `${cek("email", m.sender)}`,
    subject: `Yeyy! deposit ${formatmoney(price_sender)}, udah berhasil!`,
    html: `
<!DOCTYPE html>
<html>
<head>
<title>Detail Pembayaran Kamu</title>
<style>
    body {
        background-color: #3498db;
        font-family: Arial, sans-serif;
    }
    .content {
        padding: 20px;
        background-color: rgba(255, 255, 255, 0.8);
        border-radius: 10px;
    }
    .button {
        border: none;
        padding: 10px;
        text-align: center;
        text-decoration: none;
        display: inline-block;
        font-size: 14px;
        margin: 4px 2px;
        cursor: pointer;
        border-radius: 50%;
        width: 50px;
        height: 50px;
        transition-duration: 0.4s;
        background-size: 70%;
        background-repeat: no-repeat;
        background-position: center;
    }
 .whatsapp {
    position: fixed;
    bottom: 10px;
    left: 10px;
    background-image: url('https://telegra.ph/file/501bd6f9e379a0799c562.jpg');
    background-size: cover;
    border-radius: 50%;
    width: 30px; /* Ukuran kecil */
    height: 30px; /* Ukuran kecil */
}

.instagram {
    position: fixed;
    bottom: 10px;
    left: 50px; /* Jarak dari kiri disesuaikan */
    background-image: url('https://upload.wikimedia.org/wikipedia/commons/a/a5/Instagram_icon.png');
    background-size: cover;
    border-radius: 50%;
    width: 30px; /* Ukuran kecil */
    height: 30px; /* Ukuran kecil */
}

.telegram {
    position: fixed;
    bottom: 10px;
    left: 90px; /* Jarak dari kiri disesuaikan */
    background-image: url('https://telegra.ph/file/d00d6fc6e399068d1223e.jpg');
    background-size: cover;
    border-radius: 50%;
    width: 30px; /* Ukuran kecil */
    height: 30px; /* Ukuran kecil */
}
    .button:hover {
        opacity: 0.8;
    }
</style>
</head>
<body>
<div class="content">
    <h1 style="text-align: center; color: #2c3e50;">Detail Pembayaran Kamu</h1>
    <p>
        Hai ${pushname},<br><br>
        Yuhuu, deposit ${formatmoney(price_sender)}, udah berhasil & udah masuk ke akun kamu<br><br>
        Detail Pembelian :<br>
        ≽ Referensi : ${ref_sender}<br>
        ≽ Metode : ${method}<br>
        ≽ Jumlah : ${formatmoney(price_sender)}<br>
        ≽ Biaya : ${formatmoney(fee_sender)}<br>
        ≽ Total : ${formatmoney(total_sender)}<br><br>
        Kamu Ada kendala/masalah?:jangan ragu ya untuk menghubungi kami <a href="https://wa.me/${owner}" style="color: #3498db; text-decoration: none;">WhatsApp</a>.<br><br>
       Makasih banget ya udah percaya sama zan :)<br><br>
       Cheers,<br>
       © ＰＴ ＺＡＮＮＰＡＹ ＩＮＤＯＮＥＳＩＡ
    </p>
    <div class="button-container">
        <a href="https://wa.me/${owner}" class="button">
            <div class="icon whatsapp"></div>
        </a>
        <a href="https://instagram.com/zannstore_real" class="button">
            <div class="icon instagram"></div>
        </a>
        <a href="https://t.me/CsZannstore" class="button">
            <div class="icon telegram"></div>
        </a>
    </div>
    <div class="footer" style="text-align: center; color: #ccc;">
        <p>Powered by Anantha</p>
    </div>
</div>

</body>
</html>`
                };

                // Kirim email
                transporter.sendMail(mailOptions, function (error, info) {
                    if (error) {
                        console.log('Error sending email:', error);
                    } else {
                        console.log('Email sent:', info.response);
                    }
                });
            }
            
            /* FUCTION TRANSAKSI DIGIFLAZZ GAGAL 1 */
            function sendEmailTrxCancel(sender, pushname, referdf, product_name, user_no, parsedHarga, pesany) {
                const transporter = nodemailer.createTransport({
                    service: 'gmail',
                    auth: {
            user: `${global.emailNotif}`,
            pass: `${pwNotif}`
        }
    });

    // Siapkan email yang akan dikirim
    let mailOptions = {
    from: `${global.emailNotif}`,
    to: `${cek("email", m.sender)}`,
    subject: `Yahh invoice ${cek("reff", m.sender)} aku batalin dulu ya!`,
    html: `
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detail Transaksi Kamu</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f5f5f5;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .container {
            max-width: 600px;
            background-color: #fff;
            border-radius: 10px;
            padding: 30px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
        }
        h1 {
            color: #333;
            text-align: center;
        }
        p {
            color: #666;
            line-height: 1.6;
            text-align: center;
        }
        .button-container {
            display: flex;
            justify-content: center;
            margin-top: 30px;
        }
        .button {
            text-decoration: none;
            color: #fff;
            background-color: #3498db;
            padding: 15px 30px;
            border-radius: 5px;
            font-weight: bold;
            transition: background-color 0.3s ease;
        }
        .button:hover {
            background-color: #2980b9;
        }
        .footer {
            margin-top: 30px;
            text-align: center;
            color: #ccc;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Detail Pembayaran Anda</h1>
        <p>
            Hai ${pushname},<br><br>
            Maaf ya aku engga bisa lanjutin pesanan kamu! invoice ${referdf} aku udh batalin karena ${pesany}, saldo kamu udah zan kembalikan ke akun kamu.<br><br>
            Detail Pembelian :<br>
             Trxid : ${referdf}<br>
             Status : Failed<br>
             Layanan : ${product_name}<br>
             Tujuan : ${user_no}<br>
             Harga : ${formatmoney(parsedHarga)}<br>
             Waktu : ${moment.tz(`Asia/${global.Wilayah}`).format('HH:mm:ss')} | ${moment.tz(`Asia/${global.Wilayah}`).format('DD/MM/YY')}<br><br>
            Jangan ragu untuk menghubungi kami jika Anda memiliki pertanyaan atau butuh bantuan lebih lanjut melalui <a href="https://wa.me/${owner}" style="color: #3498db; text-decoration: none;">WhatsApp</a>.<br><br>
            Makasih banget ya udah percaya sama zan :)<br><br>
            Cheers,<br>
            © ＰＴ ＺＡＮＮＰＡＹ ＩＮＤＯＮＥＳＩＡ
        </p>
        <div class="button-container">
            <a href="https://wa.me/${owner}" class="button">WhatsApp</a>
            <a href="https://instagram.com/zannstore_real" class="button">Instagram</a>
            <a href="https://t.me/CsZannstore" class="button">Telegram</a>
        </div>
        <div class="footer">
            <p>Powered by Anantha</p>
        </div>
    </div>
</body>
</html>`
                };

                // Kirim email
                transporter.sendMail(mailOptions, function (error, info) {
                    if (error) {
                        console.log('Error sending email:', error);
                    } else {
                        console.log('Email sent:', info.response);
                    }
                });
            }
            /* FUCTION GAGAL DIGI 2 */
            function sendEmailTrxCancele(sender, pushname, referdf, product_name, user_no, parsedHarga, pesanyu) {
                const transporter = nodemailer.createTransport({
                    service: 'gmail',
                    auth: {
            user: `${global.emailNotif}`,
            pass: `${pwNotif}`
        }
    });

    // Siapkan email yang akan dikirim
    let mailOptions = {
    from: `${global.emailNotif}`,
    to: `${cek("email", m.sender)}`,
     subject: `Yahh invoice ${cek("reff", m.sender)} aku batalin dulu ya!`,
    html: `
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detail Transaksi Kamu</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f5f5f5;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .container {
            max-width: 600px;
            background-color: #fff;
            border-radius: 10px;
            padding: 30px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
        }
        h1 {
            color: #333;
            text-align: center;
        }
        p {
            color: #666;
            line-height: 1.6;
            text-align: center;
        }
        .button-container {
            display: flex;
            justify-content: center;
            margin-top: 30px;
        }
        .button {
            text-decoration: none;
            color: #fff;
            background-color: #3498db;
            padding: 15px 30px;
            border-radius: 5px;
            font-weight: bold;
            transition: background-color 0.3s ease;
        }
        .button:hover {
            background-color: #2980b9;
        }
        .footer {
            margin-top: 30px;
            text-align: center;
            color: #ccc;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Detail Pembayaran Anda</h1>
        <p>
            Hai ${pushname},<br><br>
            Maaf ya aku engga bisa lanjutin pesanan kamu! invoice ${referdf} aku udh batalin karena ${pesanyu}, saldo kamu udah zan kembalikan ke akun kamu.<br><br>
            Detail Pembelian :<br>
             Trxid : ${referdf}<br>
             Status : Failed<br>
             Layanan : ${product_name}<br>
             Tujuan : ${user_no}<br>
             Harga : ${formatmoney(parsedHarga)}<br>
             Waktu : ${moment.tz(`Asia/${global.Wilayah}`).format('HH:mm:ss')} | ${moment.tz(`Asia/${global.Wilayah}`).format('DD/MM/YY')}<br><br>
            Jangan ragu untuk menghubungi kami jika Anda memiliki pertanyaan atau butuh bantuan lebih lanjut melalui <a href="https://wa.me/${owner}" style="color: #3498db; text-decoration: none;">WhatsApp</a>.<br><br>
            Makasih banget ya udah percaya sama zan :)<br><br>
            Cheers,<br>
            © ＰＴ ＺＡＮＮＰＡＹ ＩＮＤＯＮＥＳＩＡ
        </p>
        <div class="button-container">
            <a href="https://wa.me/${owner}" class="button">WhatsApp</a>
            <a href="https://instagram.com/zannstore_real" class="button">Instagram</a>
            <a href="https://t.me/CsZannstore" class="button">Telegram</a>
        </div>
        <div class="footer">
            <p>Powered by Anantha</p>
        </div>
    </div>
</body>
</html>`
                };

                // Kirim email
                transporter.sendMail(mailOptions, function (error, info) {
                    if (error) {
                        console.log('Error sending email:', error);
                    } else {
                        console.log('Email sent:', info.response);
                    }
                });
            }
             /* FUCTION SUKSES DIGI*/
            function sendEmailTrxSuks(sender, pushname, snket, referdf, product_name, user_no, parsedHarga) {
                const transporter = nodemailer.createTransport({
                    service: 'gmail',
                    auth: {
            user: `${global.emailNotif}`,
            pass: `${pwNotif}`
        }
    });

    // Siapkan email yang akan dikirim
    let mailOptions = {
    from: `${global.emailNotif}`,
    to: `${cek("email", m.sender)}`,
    subject: `Yeayy! pesanan ${cek("reff", m.sender)} udah berhasil lho.`,
    html: `
<!DOCTYPE html>
<html>
<head>
<title>Transaksi Kamu</title>
<style>
    body {
        font-family: Arial, sans-serif;
        background-color: #f2f2f2;
        margin: 0;
        padding: 0;
    }
    .content {
        max-width: 400px;
        margin: 50px auto;
        background-color: #fff;
        border-radius: 10px;
        padding: 30px;
        box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
    }
    h1 {
        text-align: center;
        color: #333;
        margin-bottom: 10px;
    }
    p {
        color: #666;
        line-height: 1.6;
        margin-bottom: 10px;
    }
    .transaction-details {
        background-color: #f2f2f2;
        border-radius: 5px;
        padding: 15px;
        margin-bottom: 20px;
    }
    .transaction-details h2 {
        color: #333;
        margin-bottom: 10px;
    }
    .button-container {
        text-align: center;
    }
    .button {
        display: inline-block;
        width: 100px;
        padding: 10px;
        border: none;
        border-radius: 5px;
        background-color: #3498db;
        color: #fff;
        text-decoration: none;
        margin: 0 5px;
        transition: background-color 0.3s ease;
    }
    .button:hover {
        background-color: #2980b9;
    }
    .powered-by {
        text-align: center;
        color: #999;
        font-size: 12px;
    }
</style>
</head>
<body>
<div class="content">
    <h1>Transaksi Kamu</h1>
    <div class="transaction-details">
        <h2>Detail Pembelian :</h2>
        <p><strong>Trxid :</strong> ${referdf}</p>
        <p><strong>Status :</strong> Success</p>
        <p><strong>Layanan :</strong> ${product_name}</p>
        <p><strong>Tujuan :</strong> ${user_no}</p>
        <p><strong>Harga :</strong> ${formatmoney(parsedHarga)}</p>
        <p><strong>Waktu :</strong> ${moment.tz(`Asia/${global.Wilayah}`).format('HH:mm:ss')} | ${moment.tz(`Asia/${global.Wilayah}`).format('DD/MM/YY')}</p>
        <p><strong>SN/Token/Kode :</strong> ${snket}</p>
    </div>
    <p>Pesanan udah beres ya!, makasi juga ya udah order di ${footer}</p>
    <div class="powered-by">Powered by ${ownername}</div>
</div>
</body>
</html>
`
                };

                // Kirim email
                transporter.sendMail(mailOptions, function (error, info) {
                    if (error) {
                        console.log('Error sending email:', error);
                    } else {
                        console.log('Berhasil :', info.response);
                    }
                });
            }
            /* FUCTION EXPIRED DEPOSIT */
            function sendExpDepo(sender) {
                const transporter = nodemailer.createTransport({
                    service: 'gmail',
                    auth: {
            user: `${global.emailNotif}`,
            pass: `${pwNotif}`
        }
    });

    // Siapkan email yang akan dikirim
    let mailOptions = {
    from: `${global.emailNotif}`,
    to: `${cek("email", m.sender)}`,
    subject: `Aduhh invoice ${cek("deposit", sender)} udah engga berlaku`,
    html: `
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Invalid Invoice</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .container {
            max-width: 400px;
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
            overflow: hidden;
        }
        .header {
            background-color: #e74c3c;
            color: #fff;
            padding: 20px;
            text-align: center;
            border-bottom: 2px solid #c0392b;
        }
        .content {
            padding: 20px;
            text-align: center;
            line-height: 1.6;
        }
        .button-container {
            text-align: center;
            padding: 20px 0;
        }
        .button {
            text-decoration: none;
            padding: 10px 20px;
            border-radius: 5px;
            background-color: #3498db;
            color: #fff;
            font-weight: bold;
            transition: background-color 0.3s ease;
            margin: 0 10px;
            display: inline-block;
        }
        .button:hover {
            background-color: #2980b9;
        }
        .icon {
            width: 20px;
            height: 20px;
            display: inline-block;
            background-size: cover;
            margin-right: 5px;
            vertical-align: middle;
        }
        .whatsapp { background-image: url('https://telegra.ph/file/501bd6f9e379a0799c562.jpg'); }
        .instagram { background-image: url('https://upload.wikimedia.org/wikipedia/commons/a/a5/Instagram_icon.png'); }
        .telegram { background-image: url('https://telegra.ph/file/d00d6fc6e399068d1223e.jpg'); }
        .footer {
            text-align: center;
            padding: 10px 0;
            background-color: #f5f5f5;
            border-top: 1px solid #ddd;
        }
        .footer p {
            font-size: 12px;
            color: #888;
            margin: 0;
        }
    </style>
</head>
<body>

<div class="container">
    <div class="header">
        <h2>Invalid Invoice</h2>
    </div>
    <div class="content">
        <p>Yoo ${pushname},</p>
        <p>Yahh... Invoice ${cek("deposit", sender)} udah engga berlaku, kamu sih engga bayar tepat waktu hehe candaa. dari pada kesel buat lagi yuk! kan bisa lagi</p>
    </div>
    <div class="button-container">
        <a href="https://wa.me/${owner}" class="button"><span class="icon whatsapp"></span> WhatsApp</a>
        <a href="https://instagram.com/zannstore_real" class="button"><span class="icon instagram"></span> Instagram</a>
        <a href="https://t.me/CsZannstore" class="button"><span class="icon telegram"></span> Telegram</a>
    </div>
    <div class="footer">
        <p>Powered by Anantha</p>
    </div>
</div>

</body>
</html>
`
                };

                // Kirim email
                transporter.sendMail(mailOptions, function (error, info) {
                    if (error) {
                        console.log('Error sending email:', error);
                    } else {
                        console.log('Berhasil! Tiket : ', info.response);
                    }
                });
            }
            
            function sendExpTrx(sender) {
                const transporter = nodemailer.createTransport({
                    service: 'gmail',
                    auth: {
            user: `${global.emailNotif}`,
            pass: `${pwNotif}`
        }
    });

    // Siapkan email yang akan dikirim
    let mailOptions = {
    from: `${global.emailNotif}`,
    to: `${cek("email", m.sender)}`,
    subject: `Aduhh invoice ${cek("reff", sender)} udah engga berlaku`,
    html: `
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Biling Gagal, Sob!</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .container {
            max-width: 400px;
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
            overflow: hidden;
        }
        .header {
            background-color: #e74c3c;
            color: #fff;
            padding: 20px;
            text-align: center;
            border-bottom: 2px solid #c0392b;
        }
        .content {
            padding: 20px;
            text-align: center;
            line-height: 1.6;
        }
        .button-container {
            text-align: center;
            padding: 20px 0;
        }
        .button {
            text-decoration: none;
            padding: 10px 20px;
            border-radius: 5px;
            background-color: #3498db;
            color: #fff;
            font-weight: bold;
            transition: background-color 0.3s ease;
            margin: 0 10px;
            display: inline-block;
        }
        .button:hover {
            background-color: #2980b9;
        }
        .icon {
            width: 20px;
            height: 20px;
            display: inline-block;
            background-size: cover;
            margin-right: 5px;
            vertical-align: middle;
        }
        .footer {
            text-align: center;
            padding: 10px 0;
            background-color: #f5f5f5;
            border-top: 1px solid #ddd;
        }
        .footer p {
            font-size: 12px;
            color: #888;
            margin: 0;
        }
    </style>
</head>
<body>

<div class="container">
    <div class="header">
        <h2>Expired Invoice</h2>
    </div>
    <div class="content">
        <p>Yo ${pushname},</p>
        <p>Waduh... Invoice ${cek("reff", sender)} udah expired, nih! km sih lupa bayar, santai! Relax aja, ntar bikin lagi aja ya!</p>
    </div>
    <div class="button-container">
        <!-- Tombol tautan dihapus -->
    </div>
    <div class="footer">
        <p>Powered by Anantha</p>
    </div>
</div>

</body>
</html>
`
                };

                // Kirim email
                transporter.sendMail(mailOptions, function (error, info) {
                    if (error) {
                        console.log('Error sending email:', error);
                    } else {
                        console.log('Berhasil! Tiket : ', info.response);
                    }
                });
            }
            
/* PAYDISINI PENDING */
function sendEmailPending(sender, pushname, ref_sender, method, price_sender, fee_sender, total_sender, url) {
                const transporter = nodemailer.createTransport({
                    service: 'gmail',
                   auth: {
            user: `${global.emailNotif}`,
            pass: `${pwNotif}`
        }
    });

    // Siapkan email yang akan dikirim
    let mailOptions = {
    from: `${global.emailNotif}`,
    to: `${cek("email", m.sender)}`,
    subject: `Yeyy, Invoice ${ref_sender} udah aku buatin, jangan lupa dibayar ya!`,
    html: `
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Invoice Payment Reminder</title>
<style>
    body {
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        background-color: #f9f9f9;
        margin: 0;
        padding: 0;
    }
    .container {
        max-width: 600px;
        margin: 50px auto;
        background-color: #ffffff;
        border-radius: 10px;
        overflow: hidden;
        box-shadow: 0px 0px 20px rgba(0, 0, 0, 0.1);
    }
    .header {
        background-color: #2ecc71;
        color: #ffffff;
        padding: 20px;
        text-align: center;
        border-bottom: 2px solid #27ae60;
    }
    .content {
        padding: 20px;
    }
    .content p {
        margin-bottom: 20px;
        line-height: 1.6;
        color: #444444;
    }
    .button-container {
        text-align: left;
        margin-top: 30px;
        position: fixed;
        bottom: 10px;
        left: 10px;
    }
    .button {
        display: inline-block;
        text-decoration: none;
        padding: 10px 20px;
        background-color: #2ecc71;
        color: #ffffff;
        border-radius: 5px;
        transition: background-color 0.3s ease;
        margin-top: 20px;
        border: none;
        cursor: pointer;
    }
    .button:hover {
        background-color: #27ae60;
    }
    .icon {
        width: 20px;
        height: 20px;
        display: inline-block;
        margin-right: 10px;
    }
.whatsapp {
    background-image: url('https://telegra.ph/file/501bd6f9e379a0799c562.jpg');
    background-size: cover;
    border-radius: 50%;
    width: 5px; /* Ukuran kecil */
    height: 5px; /* Ukuran kecil */
}

.instagram {
    background-image: url('https://upload.wikimedia.org/wikipedia/commons/a/a5/Instagram_icon.png');
    background-size: cover;
    border-radius: 50%;
    width: 5px; /* Ukuran kecil */
    height: 5px; /* Ukuran kecil */
}

.telegram {
    background-image: url('https://telegra.ph/file/d00d6fc6e399068d1223e.jpg');
    background-size: cover;
    border-radius: 50%;
    width: 5px; /* Ukuran kecil */
    height: 5px; /* Ukuran kecil */
}
    .powered-by {
        font-size: 12px;
        color: #888888; /* Warna abu-abu */
        text-align: right;
        margin-top: 20px;
    }
</style>
</head>
<body>

<div class="container">
    <div class="header">
        <h2>Invoice Payment Reminder</h2>
    </div>
    <div class="content">
        <p>Yoo ${pushname},</p>
        <p>hehe zan mau ngasih sesuatu nih! mau tau? ada deh hehe candaa.. aku mau ngasih invoice yang perlu dibayar, jangan telat ya bayar nya</p>
        <ul>
            <li><strong>Referensi :</strong> ${ref_sender}</li>
            <li><strong>Metode :</strong> ${method}</li>
            <li><strong>Jumlah :</strong> ${formatmoney(price_sender)}</li>
            <li><strong>Biaya :</strong> ${formatmoney(fee_sender)}</li>
            <li><strong>Total :</strong> ${formatmoney(total_sender)}</li>
        </ul>
        <p>Silahkan klik tombol di bawah untuk melakukan pembayaran sekarang:</p>
        <a href="${url}" class="button">Bayar Sekarang</a>
        <p>Jika kamu memiliki pertanyaan, jangan ragu untuk menghubungi kami melalui WhatsApp, Instagram, atau Telegram:</p>
    </div>
    <div class="button-container">
        <a href="https://wa.me/${owner}" class="button">
            <div class="icon whatsapp"></div>WhatsApp</a>
        <a href="https://instagram.com/zannstore_real" class="button">
            <div class="icon instagram"></div>Instagram</a>
        <a href="https://t.me/CsZannstore" class="button">
            <div class="icon telegram"></div>Telegram</a>
    </div>
<div style="text-align: center; margin-top: 20px;">
    <p style="font-size: 12px; color: #888;">Powered by Anantha</p>
</div>
</body>
</html>
`
                };

                // Kirim email
                transporter.sendMail(mailOptions, function (error, info) {
                    if (error) {
                        console.log('Error sending email:', error);
                    } else {
                        console.log('Email sent:', info.response);
                    }
                });
            }
            /* FUCTION DIGIFLAZZ*/
                    function sendInvPending(sender, jumlahHarga, potonganHarga, totalPembayaran) {
                const transporter = nodemailer.createTransport({
                    service: 'gmail',
                    auth: {
            user: `${global.emailNotif}`,
            pass: `${pwNotif}`
        }
    });

    // Siapkan email yang akan dikirim
    let mailOptions = {
    from: `${global.emailNotif}`,
    to: `${cek("email", m.sender)}`,
    subject: `Yeyy! invoice ${cek("reff", sender)} aku udh buatin, jangan lupa dibayar ya biar cepat diproses`,
    html: `
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TRANSAKSI KAMU</title>
    <style>
        body {
            font-family: 'Roboto', sans-serif;
            background-color: #f2f2f2;
            margin: 0;
            padding: 0;
        }
        .content {
            max-width: 600px;
            margin: 50px auto;
            background-color: #fff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
        }
        .title {
            color: #2ecc71;
            margin-bottom: 20px;
        }
        .order-details {
            margin-bottom: 20px;
        }
        .button-container {
            display: flex;
            justify-content: center;
        }
        .button {
            margin: 0 10px;
            width: 50px;
            height: 50px;
            border-radius: 50%;
            overflow: hidden;
            transition: all 0.3s ease;
        }
        .button:hover {
            transform: scale(1.1);
        }
        .icon {
            width: 100%;
            height: 100%;
            background-size: cover;
            background-position: center;
        }
        .footer {
            margin-top: 20px;
            text-align: center;
            color: #888;
            font-size: 14px;
        }
    </style>
</head>
<body>

<div class="content">
    <h2 class="title">TRANSAKSI KAMU</h2>
    <div class="order-details">
        <p>
            Yoo ${pushname},<br><br>
            Pesanan dengan trxid ${cek("reff", sender)} udah dibuatin ya<br><br>
            Order Detail :<br>
            ≽ ID Trx : ${cek("reff",m.sender)}<br>
            ≽ Product : ${cek("product_name", m.sender)}<br>
            ≽ Tujuan : ${cek("tujuan", m.sender)}<br>
            ≽ Note : ${cek("desc_prabayar",m.sender)}<br>
            ≽ Harga : ${formatmoney(jumlahHarga)}<br>
            ≽ Diskon : ${formatmoney(potonganHarga)}<br>
            ≽ Total : ${formatmoney(totalPembayaran)}<br>
            Pesanan sudah zan buat nih! jangan lupa untuk menyelesaikan pembayaran ya biar lebih cepat diproses<br><br>
            Kalo kamu ada yang ditanya atau dibantu, langsung aja <a href="https://wa.me/${owner}" style="color: #3498db; text-decoration: none;">WhatsApp</a>.<br><br>
            Makasih banget ya udah percaya sama zan :)<br><br>
            Cheers,<br>
            © ＰＴ ＺＡＮＮＰＡＹ ＩＮＤＯＮＥＳＩＡ
        </p>
    </div>
    <div class="button-container">
        <a href="https://wa.me/${owner}" class="button">
            <div class="icon" style="background-image: url('https://telegra.ph/file/501bd6f9e379a0799c562.jpg');"></div>
        </a>
        <a href="https://instagram.com/zannstore_real" class="button">
            <div class="icon" style="background-image: url('https://upload.wikimedia.org/wikipedia/commons/a/a5/Instagram_icon.png');"></div>
        </a>
        <a href="https://t.me/CsZannstore" class="button">
            <div class="icon" style="background-image: url('https://telegra.ph/file/d00d6fc6e399068d1223e.jpg');"></div>
        </a>
    </div>
    <div class="footer">
        <p>Powered by Anantha</p>
    </div>
</div>

</body>
</html>
`
                };

                // Kirim email
                transporter.sendMail(mailOptions, function (error, info) {
                    if (error) {
                        console.log('Error sending email:', error);
                    } else {
                        console.log('Email sent:', info.response);
                    }
                });
            }
const time = moment().tz(`Asia/${global.Wilayah}`).format('HH:mm:ss');
let ucapanWaktu1;

if (time < "03:00:00" || time >= "23:59:00") {
  ucapanWaktu1 = 'Malam';
} else if (time < "10:00:00") {
  ucapanWaktu1 = 'Pagi';
} else if (time < "15:00:00") {
  ucapanWaktu1 = 'Siang';
} else if (time < "18:00:00") {
  ucapanWaktu1 = 'Sore';
} else {
  ucapanWaktu1 = 'Malam';
} 

const fdocc = {
  key: {
    participant: '0@s.whatsapp.net',
    ...(m.chat ? {
      remoteJid: `status@broadcast`
    } : {})
  },
  message: {
    documentMessage: {
      title: `Halo ${pushname}! Selamat ${ucapanWaktu1}, Saldo Anda saat ini ${formatmoney(cek("saldo", m.sender))}.`,
      jpegThumbnail: m,
    }
  }
};
let d = JSON.parse(fs.readFileSync('./SETTING/DB/admin.json'))    
function simpan(path, buff) {
    fs.writeFileSync(path, buff)
    return path
}

const nebal = (angka) => {
return Math.floor(angka)
}

function toRupiah(angka) {
  var angkaStr = angka.toString();
  var angkaTanpaKoma = angkaStr.split('.')[0];
  var angkaRev = angkaTanpaKoma.toString().split('').reverse().join('');
  var rupiah = '';
  for (var i = 0; i < angkaRev.length; i++) {
    if (i % 3 == 0) rupiah += angkaRev.substr(i, 3) + '.';
  }
  return '' + rupiah.split('', rupiah.length - 1).reverse().join('');
}
function pickrandoms(length) {
  var symbols = `ABCDEFGHIJKLMNOPQRSTUVWXYZ${dengan_nol}`;
  var symbolLength = symbols.length;
  var randomString = '';
  for (var i = 0; i < length; i++) {
    randomString += symbols.charAt(Math.floor(Math.random() * symbolLength));
  }
  return randomString;
}

let beritatf = "ZN" + pickrandoms(4);
let koderefe = "ZPAY" + pickrandoms(6);

if (m.sender.startsWith('212')) return AnanthaGanz.updateBlockStatus(m.sender, 'block')
if (m.key.remoteJid == 'status@broadcast') return AnanthaGanz.sendReadReceipt(from, m.sender, [m.key.id])

function pickrandom() {
  const symbols = `ABCDEFGHIJKLMNOPQRSTUVWXYZ`;
  let randomSymbol = '';
  for (let i = 0; i < 2; i++) {
    randomSymbol += symbols.charAt(Math.floor(Math.random() * symbols.length));
  }
  
  
  const symbols1 = `${dengan_nol}`;
  let randomSymbol1 = '';
  for (let i = 0; i < 3; i++) {
    randomSymbol1 += symbols1.charAt(Math.floor(Math.random() * symbols1.length));
  }
randomSymbol1 += '26'; // Menambahkan angka 26 ke string acak
  const currentDate = new Date();
  const year = String(currentDate.getFullYear()).slice(-2); // Mengambil 2 digit terakhir dari tahun
  const month = ('0' + (currentDate.getMonth() + 1)).slice(-2); // Menambahkan leading zero jika perlu
  const day = ('0' + currentDate.getDate()).slice(-2); // Menambahkan leading zero jika perlu
  return 'ZN' + day + month + year + randomSymbol + randomSymbol1;
}

let koderef = pickrandom();

const admModalPath = './SETTING/DB/admin.json';

 switch (command) {
 /* IP V4 Digunakan Untuk Bertransaksi Via Api */
 case 'syarat':
    {
        AnanthaGanz.sendPoll(m.chat, `
        *Syarat & Ketentuan Layanan*

  *1. Umum:*
  
> Dengan mendaftar & menggunakan layanan *${footer}*, Anda secara otomatis menyetujui semua ketentuan layanan kami. Kami berhak mengubah ketentuan layanan ini tanpa pemberitahuan terlebih dahulu. Anda diharapkan membaca semua ketentuan layanan kami sebelum melakukan transaksi. Penolakan: *${footer}* tidak akan bertanggung jawab jika Anda mengalami kerugian dalam bisnis Anda. Kewajiban: *${footer}* tidak bertanggung jawab jika Anda mengalami kesalahan nomor tujuan saat memesan produk kami.

   *2. Layanan:*
   
> *${footer}* hanya digunakan untuk layanan pembelian tiket penerbangan. *${footer}* akan memberikan garansi ketika terjadi kendala saat pemesanan, "kecuali kesalahan nomor tujuan". *${footer}* tidak menerima permintaan pembatalan/pengembalian dana setelah pesanan masuk ke sistem kami. Kami memberikan pengembalian dana yang sesuai jika pesanan tidak dapat diselesaikan.

   *3. Pengguna/Akun:*
   
> *${footer}* berhak menghapus/blacklist akun Anda tanpa pemberian refund dari pihak kami apabila Anda melakukan hal di bawah ini:
> - Melakukan kecurangan dalam bertransaksi di *${footer}*
> - Melakukan penipuan dalam bentuk apapun di *${footer}*

   *4. Transaksi:*
   
> Apabila terdapat pengguna melakukan transaksi secara tidak resmi/kecurangan:
> *${footer}* berhak membawa ke jalur hukum. Pengguna wajib mempertanggungjawabkan kesalahannya.

   *5. Pembayaran:*
   
> *${footer}* hanya menerima pembayaran melalui transfer bank dan kartu kredit. Kami tidak menerima pembayaran tunai/utang. Apabila memaksa, kami akan melakukan blacklist terhadap pengguna tersebut.

 *Terakhir Update:* 10/15/22 | 07:05:40

*Hubungi Kami:*
 Silakan hubungi Customer Care kami melalui cara berikut:

> *WhatsApp:* wa.me/${owner}
> *Email:* call.zannstore@gmail.com
> *Telegram:* t.me/CsZannstore

${toko}

Silahkan pilih "Saya Setuju" jika Anda menyetujui syarat dan ketentuan layanan kami.
        `, ["Saya Setuju", "Tidak Setuju"])
    }
    break
    case 'ipv4':
case 'getip': {
    if (m.isGroup) {
        return m.reply(mess.private);
    }
    if (!isOwner) {
        return m.reply(mess.owner);
    }

    try {
        const headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
        };

        const requestOptions = {
            method: 'GET',
            headers: headers,
            redirect: 'follow'
        };

        const ip_panel = await fetch(`https://api.myip.com`, requestOptions);
        const res = await ip_panel.json();

        // Memeriksa apakah alamat IP adalah IPv4
        const ipv4Regex = /^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/;
        const ipv4 = res.ip.match(ipv4Regex);

        if (ipv4) {
            const replyMessage = `*📮INFO SERVER*\n\n*IP :* ${ipv4}\n*Country :* ${res.country}`;
            m.reply(replyMessage);
        } else {
            m.reply('Gagal mengambil informasi IP IPv4. Silakan coba lagi nanti.');
        }
    } catch (error) {
        console.error('Error fetching IP:', error);
        m.reply('Gagal mengambil informasi IP. Silakan coba lagi nanti.');
    }
}
break;
/* End IP V4 */
case 'manfaat':{
AnanthaGanz.sendPoll(m.chat, `*Keuntungan Upgrade ke Premium:*

1. Akses penuh ke semua fitur premium seperti Ceknickname, topuser, dan lainnya.
2. Potongan harga 10% setiap pembelian minimal Rp. 20.000 hingga maksimal pembelian Rp. 1.000.000
3. Nikmati fitur transfer antar pengguna untuk kemudahan transaksi.
4. Dapatkan langsung saldo Rp. 5.000 saat upgrade ke premium 

Jangan lewatkan kesempatan ini! Upgrade sekarang hanya dengan Rp. 35.000.`, ['Upgrade aja deh','Hubungi Admin'])
}
break


case 'upgrade': {
let axios = require('axios');
  let FormData = require('form-data');
  let md5 = require('md5');
if(cek("syarat", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, 'Oops, Kamu Belum Menyetujui Syarat Ketentuan dari kami. Mohon setujuin dulu, agar dapat mengakses fitur dari kami.', ['Saya Setuju','Syarat nya apa aja']);
if(cek("verfiyemail", m.sender) == true) return reply(`Oops, Silahkan Daftarkan Email anda\nContoh : .setemail xxxxx@gmail.com`)
if(cek("level", m.sender) == "Premium") return reply("Oops, Kamu Sudah Melakukan Pembayaran sebelumnya");
    const nomor = sender.split("@")[0];
    const metodePembayaran = args[0]; // Metode pembayaran yang dipilih oleh pengguna
       if(fs.existsSync(`./SETTING/DB/TRANSACTION/Api/Deposit/${cek("deposit", m.sender)}.json`)) return AnanthaGanz.sendPoll(m.chat, `Oops, Kamu Sedang Memiliki Invoice ${cek("deposit", m.sender)}, apakah kamu ingin cancel?`, ['Cancel Aja','Hubungi Admin']);
    const ref_id = "ZUP" + randomPay
    const jumlah = 35000 * 1
    let metode;
    if (!metodePembayaran) {
        return AnanthaGanz.sendPoll(m.chat, 'Metode Pembayaran Untuk Upgrade Akun Hanya :', ['Upgrade QRIS','Upgrade DANA','Upgrade LINKAJA','Upgrade SHOPEEPAY','Upgrade Mandiri','Upgrade BNI','Upgrade BRI','Upgrade Alfamart','Upgrade Indomaret']);
    } else {
        switch (metodePembayaran.toLowerCase()) {
            case 'qris':
                metode = '17';
                break;
            case 'dana':
                metode = '13';
                break;
            case 'linkaja':
                metode = '14';
                break;
                case 'shopeepay':
                metode = '16';
                break;
            case 'mandiri':
                metode = '5';
                break;
            case 'bca':
                metode = '1';
                break;
            case 'bri':
                metode = '2';
                break;
            case 'bni':
                metode = '4';
                break;
            case 'alfamart':
                metode = '18';
                break;
            case 'indomaret':
                metode = '19';
                break;
            default:
                return AnanthaGanz.sendPoll(m.chat, 'Metode Pembayaran Untuk Upgrade Akun Hanya :', ['Upgrade QRIS','Upgrade DANA','Upgrade LINKAJA','Upgrade SHOPEEPAY','Upgrade Mandiri','Upgrade BNI','Upgrade BRI','Upgrade Alfamart','Upgrade Indomaret']);
        }
    }
  async function makePayment() {
    try {
      let keynya = global.key;
      let kodeunick = ref_id;
      let paymetcod = metode;
      let aomut = jumlah * 1;
      let exp = 10800;
      let create = keynya + kodeunick + paymetcod + aomut + exp + 'NewTransaction'
      let signature = md5(create);
      let no_waletsend = `${sender.split('@')[0]}`;
      no_waletsend = no_waletsend.replace('62', '0');
      // Membuat data form untuk permintaan pembayaran
      var paymentData = new FormData();
      paymentData.append('key', keynya);
      paymentData.append('request', 'new');
      paymentData.append('unique_code', kodeunick);
      paymentData.append('service', paymetcod);
      paymentData.append('amount', aomut);
      paymentData.append('note', `Premium Members ${ref_id}`);
      paymentData.append('valid_time', exp);
      paymentData.append('customer_email', cek("email", m.sender));
      paymentData.append('ewallet_phone', no_waletsend);
      paymentData.append('type_fee', '1');
      paymentData.append('signature', signature); // Menggunakan signature yang telah dihitung
      // Konfigurasi untuk permintaan pembayaran
      var paymentConfig = {
        method: 'post',
        url: 'https://paydisini.co.id/api/',
        headers: { 
          ...paymentData.getHeaders()
        },
        data: paymentData
      };
      // Mengirim permintaan pembayaran
      let paymentResponse = await axios(paymentConfig);
      let paymentDataResponse = paymentResponse.data.data;
          let obj = { id: m.sender, ref: `${paymentDataResponse.unique_code}`, method : `${paymentDataResponse.service_name}`, diterima: `${paymentDataResponse.balance}`, total: `${paymentDataResponse.amount}`, fee: `${paymentDataResponse.fee}`, url: `${paymentDataResponse.checkout_url}` }
          sett("deposit", m.sender, `${paymentDataResponse.unique_code}`)
fs.writeFileSync(`./SETTING/DB/TRANSACTION/Api/Deposit/${paymentDataResponse.unique_code}.json`, JSON.stringify(obj))
     await loading()
    var ccapt = `Pembayaran Otomatis 

> Metode : ${paymentDataResponse.service_name}
> Referensi : ${paymentDataResponse.unique_code}
> Kadaluarsa : ${getExpirationTime()} menit
> Tagihan : ${formatmoney(paymentDataResponse.balance)}
> Fee : ${formatmoney(paymentDataResponse.fee)}
> Total Pembayaran : ${formatmoney(paymentDataResponse.amount)}

Tap "Bayar Sekarang" untuk Melakukan Pembayaran`;

AnanthaGanz.sendPoll(m.chat, ccapt, ['Bayar Sekarang','Cancel Pembayaran']);
const deppo = JSON.parse(fs.readFileSync(`./SETTING/DB/TRANSACTION/Api/Deposit/${cek("deposit", m.sender)}.json`))
setTimeout(() => {
               let method = `${checkIdDepo(m.sender, deppo) ? checkIdDepo(m.sender, deppo) : deppo.method}`
              let member = `${checkIdDepo(m.sender, deppo) ? checkIdDepo(m.sender, deppo) : deppo.id}`
                let price_sender = `${checkIdDepo(m.sender, deppo) ? checkIdDepo(m.sender, deppo) : deppo.diterima}` * 1
               let fee_sender = `${checkIdDepo(m.sender, deppo) ? checkIdDepo(m.sender, deppo) : deppo.fee}` * 1
               let ref_sender = `${checkIdDepo(m.sender, deppo) ? checkIdDepo(m.sender, deppo) : deppo.ref}` 
               let total_sender = `${checkIdDepo(m.sender, deppo) ? checkIdDepo(m.sender, deppo) : deppo.total}` * 1
               let url = `${checkIdDepo(m.sender, deppo) ? checkIdDepo(m.sender, deppo) : deppo.url}`
               sendEmailPending(sender, pushname, ref_sender, method, price_sender, fee_sender, total_sender, url);
               }, 2500);
let unick = paymentDataResponse.unique_code
function getExpirationTime() {
    const currentTime = new Date().getTime();
    const expirationTime = currentTime + (30 * 60 * 1000); // 30 menit kedepan
    const timeRemaining = Math.ceil((expirationTime - currentTime) / 60000); // Konversi ke menit dan dibulatkan ke atas
    return timeRemaining;
}
      // Memantau status pembayaran
      let dataStatus = paymentDataResponse.status;
      const startTime = new Date().getTime();
      while (dataStatus !== "Success") {
        await sleep(1000);
       let create3 = keynya + unick + 'StatusTransaction'
      let signature3 = md5(create3);
        var checkStatusData = new FormData();
        checkStatusData.append('key', keynya);
        checkStatusData.append('request', 'status');
        checkStatusData.append('unique_code', kodeunick);
        checkStatusData.append('signature', signature3); 
        // Konfigurasi untuk memeriksa status pembayaran
        var checkStatusConfig = {
          method: 'post',
          url: 'https://paydisini.co.id/api/',
          headers: { 
            ...checkStatusData.getHeaders()
          },
          data: checkStatusData
        };
        // Mengirim permintaan untuk memeriksa status pembayaran
        let statusResponse = await axios(checkStatusConfig);
        let statusDataResponse = statusResponse.data.data;
        dataStatus = statusDataResponse.status;
        console.log(dataStatus);
        // Memeriksa waktu timeout
        const currentTime = new Date().getTime();
           const elapsedTime = (currentTime - startTime) / (1000 * 60 * 30);
             if (elapsedTime >= 1) {
              m.reply(`Aduh, tiket ${cek("deposit", m.sender)} udah gak bisa dipake lagi nih. Yuk, coba lagi lain waktu! 😕`);
              cancelPay();
          break;
        }
        // Jika pembayaran berhasil
        if (dataStatus === "Success") {
          const deppo = JSON.parse(fs.readFileSync(`./SETTING/DB/TRANSACTION/Api/Deposit/${cek("deposit", m.sender)}.json`))
               let method = `${checkIdDepo(m.sender, deppo) ? checkIdDepo(m.sender, deppo) : deppo.method}`
              let member = `${checkIdDepo(m.sender, deppo) ? checkIdDepo(m.sender, deppo) : deppo.id}`
                let price_sender = `${checkIdDepo(m.sender, deppo) ? checkIdDepo(m.sender, deppo) : deppo.diterima}` * 1
               let fee_sender = `${checkIdDepo(m.sender, deppo) ? checkIdDepo(m.sender, deppo) : deppo.fee}` * 1
               let ref_sender = `${checkIdDepo(m.sender, deppo) ? checkIdDepo(m.sender, deppo) : deppo.ref}` 
               let total_sender = `${checkIdDepo(m.sender, deppo) ? checkIdDepo(m.sender, deppo) : deppo.total}` * 1
               sendEmailDepo(sender, pushname, ref_sender, method, price_sender, fee_sender, total_sender);
             AnanthaGanz.sendMessage(nomor+"@s.whatsapp.net", { text : "Sip, pembayaran berhasil!!, status premium Anda sudah aktif, selamat menikmati"})
             setTimeout(() => {
             let notif = `Hai *${ownername}*,
Ada transaksi yang telah dibayar!

Member : ${dengan_nol}
Kode Unik : ${ref_sender}
Metode Pembayaran : ${method}
Jumlah Deposit : ${formatmoney(price_sender)}
Biaya Admin : ${formatmoney(fee_sender)}
Total Deposit : ${formatmoney(total_sender)}
Waktu : ${moment.tz(`Asia/${global.Wilayah}`).format('HH:mm:ss')} | ${moment.tz(`Asia/${global.Wilayah}`).format('DD/MM/YY')}

Detail transaksi dapat dilihat pada website https://paydisini.co.id/Riwayat-Transaksi/?status=&unique_code=${ref_sender}
`
AnanthaGanz.sendMessage(`${owner}@s.whatsapp.net`,{text: notif },  { quoted: m })
   }, 2000); // 2000 milliseconds (3 seconds)
                // Tambahkan pengguna ke fitur premium setelah pembayaran berhasil
                let keuntunganup = 5000 * 1 // SETT KEUNTUNGAN UP
               sett("level", nomor + "@s.whatsapp.net", "Premium");
               sett("+saldo", nomor + "@s.whatsapp.net", keuntunganup) 
                setTimeout(() => { 
                fs.unlinkSync(`./SETTING/DB/TRANSACTION/Api/Deposit/${cek("deposit", m.sender)}.json`);
                }, 4000);
                setTimeout(() => {
                sett("deposit", m.sender, "")
                }, 6000);
                 } else if (dataStatus === "Canceled") {
               console.log(`Berhasil! Ref ${cek("deposit", m.sender)} Dihapus`)
          break;
        }
      }
    } catch (error) {
      console.log(error);
    }
  }
  // Memanggil fungsi untuk melakukan pembayaran
  makePayment();
}
break;
/*

*/
case 'delprem': {
    let siapa = args[0];
    // Pastikan argumen nomor telepon diberikan
    if (!siapa) {
        return reply(`Format yang benar: ${prefix}delprem <nomor_telepon>`);
    }
    // Cek apakah nomor tersebut sudah menjadi anggota premium
   if(cek("level", siapa + "@s.whatsapp.net") == "Basic") return reply(`Oops, User Tersebut tidak didalam premium`)

    // Hapus nomor telepon dari array premium
        sett("level", siapa + "@s.whatsapp.net", "Basic");
    
    // Kirim balasan berhasil
    reply(`Berhasil menghapus nomor ${siapa} dari daftar premium.`);
}
break;
case 'addprem': {
    let siapa = args[0];

    // Pastikan argumen nomor telepon diberikan
    if (!siapa) {
        return reply(`Format yang benar: ${prefix}addprem <nomor_telepon>`);
    }

    // Cek apakah nomor tersebut sudah menjadi anggota premium
   if(cek("level", siapa + "@s.whatsapp.net") == "Premium") return reply(`Oops, User Tersebut Telah Premium`)

    // Tambahkan nomor telepon ke dalam array premium
    sett("level", siapa + "@s.whatsapp.net", "Premium");
    // Kirim balasan berhasil
    reply(`Berhasil menambahkan nomor ${siapa} ke dalam daftar premium.`);
}
break;
case 'transfer': {
if(cek("level", m.sender) == "Basic") return reply(`Oops, Fitur Ini Khusus Untuk Akun Premium! Silahkan Upgrade akun anda`)
if(cek("syarat", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, 'Oops, Kamu Belum Menyetujui Syarat Ketentuan dari kami. Mohon setujuin dulu, agar dapat mengakses fitur dari kami.', ['Saya Setuju','Syarat nya apa aja']);
if(cek("verfiyemail", m.sender) == true) return reply(`Oops, Silahkan Daftarkan Email anda\nContoh : .setemail xxxxx@gmail.com`)
    let members = require("./SETTING/DB/user.json");
    let siapa = q.split(" ")[0];
    let brp = parseInt(q.split(" ")[1]);
    let wanet = siapa + "@s.whatsapp.net";
    let refftf = koderefe
    if (!siapa || !brp || isNaN(brp)) {
        reply("Format yang benar: .transfer 6285174667722 20000");
        return;
    }

    if (wanet === m.sender) {
        reply("Oops, mau nyoba transfer ke akun sendiri ya? hehe engga bisa yaa");
        return;
    }

    if (brp < 1 || brp > 100000000) {
        reply("Jumlah transfer harus minimal 1 dan maksimal 100 juta.");
        return;
    }

    let receiverData = members.find(member => member.id === wanet);
    if (!receiverData) {
        reply("Oops, Akun Itu Kayaknya Engga terdaftar di database kami pastiin bener yaa");
        return;
    }

    let senderBalance = cek("saldo", m.sender);
    if (brp > senderBalance) {
        reply(`Oops, Kamu belum bisa transfer ke ${siapa}! Karena Saldo kamu engga cukup isi dulu yukk`);
        return;
    }

    sett("-saldo", m.sender, brp);
    sett("+saldo", wanet, brp);
    reply(`Sip, Transfer Berhasil!. Ref: ${refftf}/${formatmoney(brp)}`);
    AnanthaGanz.sendMessage(wanet, { text: `Yuhuuu kamu telah menerima saldo dari pengguna ${dengan_nol}. Ref: ${refftf}/${formatmoney(brp)}` });
}
break;
/* Case Yang Tersedia */
case 'menu': {
    if (cek("verfiyemail", m.sender) == true) return reply(`Oops, Silahkan Daftarkan Email anda\nContoh : .setemail xxxxx@gmail.com`);
    if (cek("cekVerify", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, `Oops, Silahkan Verifikasi Email : ${cek("email", m.sender)}`, ['Verifikasicode','Hubungi Admin']);
    if (cek("syarat", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, 'Oops, Kamu Belum Menyetujui Syarat Ketentuan dari kami. Mohon setujuin dulu, agar dapat mengakses fitur dari kami.', ['Saya Setuju','Syarat nya apa aja']);
    const menuOptions = ['Shop', 'Account/Dashboard'];
    AnanthaGanz.sendPoll(m.chat, `Hey ${pushname}, ada beberapa menu yang bisa kamu coba.\n\nPilih salah satu ya:`, menuOptions);
}
break;

// Menangani respons setelah pengguna menyetujui syarat dan ketentuan
case 'tidak':
case 'saya': {
let send = `${sender.split('@')[0]}`
    // Melakukan pengecekan lagi apakah pengguna sudah menyetujui syarat dan ketentuan
    sett("syarat", m.sender, false);
  reply("Oke Sip, Kamu Telah Menyetujui Syarat Ketentuan dari kami, selamat menikmati fitur kami")
    // Jika pengguna sudah menyetujui syarat dan ketentuan, tampilkan menu
    setTimeout(() => {
    const menuOptions = ['Shop', 'Account/Dashboard'];
    AnanthaGanz.sendPoll(m.chat, `Hey ${pushname}, ada beberapa menu yang bisa kamu coba.\n\nPilih salah satu ya:`, menuOptions);
    }, 2000);
}
break;
            case 'account/dashboard':{
            if (cek("verfiyemail", m.sender) == true) return reply(`Oops, Silahkan Daftarkan Email anda\nContoh : .setemail xxxxx@gmail.com`);
    if (cek("cekVerify", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, `Oops, Silahkan Verifikasi Email : ${cek("email", m.sender)}`, ['Verifikasicode','Hubungi Admin']);
if(cek("syarat", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, 'Oops, Kamu Belum Menyetujui Syarat Ketentuan dari kami. Mohon setujuin dulu, agar dapat mengakses fitur dari kami.', ['Saya Setuju','Syarat nya apa aja']);
            AnanthaGanz.sendPoll(m.chat, `Hey ${pushname}, Kamu sedang berada di menu acount kamu, pilih dulu yuk yang km mau:\n\nDi Klik Aja ya`, ['Info Akun Ku','Stalking Akun Game, E - Wallet & Lainnya'])
            }
            break
            case 'stalking':{
            if (cek("verfiyemail", m.sender) == true) return reply(`Oops, Silahkan Daftarkan Email anda\nContoh : .setemail xxxxx@gmail.com`);
    if (cek("cekVerify", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, `Oops, Silahkan Verifikasi Email : ${cek("email", m.sender)}`, ['Verifikasicode','Hubungi Admin']);
          if(cek("syarat", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, 'Oops, Kamu Belum Menyetujui Syarat Ketentuan dari kami. Mohon setujuin dulu, agar dapat mengakses fitur dari kami.', ['Saya Setuju','Syarat nya apa aja']);
if(cek("level", m.sender) == "Basic") return reply(`Oops, Fitur Ini Khusus Untuk Akun Premium! Silahkan Upgrade akun anda`)
            AnanthaGanz.sendPoll(m.chat, `Hey ${pushname}, Dipilih Dulu yuk mau stalking apa! 📱\n\nSeperti Biasa Cukup Tap" aja`, ['Games','E-Wallets','Banks','CekPLN'])
            }
            break
            case 'games':{
            if (cek("verfiyemail", m.sender) == true) return reply(`Oops, Silahkan Daftarkan Email anda\nContoh : .setemail xxxxx@gmail.com`);
    if (cek("cekVerify", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, `Oops, Silahkan Verifikasi Email : ${cek("email", m.sender)}`, ['Verifikasicode','Hubungi Admin']);
     if(cek("syarat", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, 'Oops, Kamu Belum Menyetujui Syarat Ketentuan dari kami. Mohon setujuin dulu, agar dapat mengakses fitur dari kami.', ['Saya Setuju','Syarat nya apa aja']);
if(cek("level", m.sender) == "Basic") return reply(`Oops, Fitur Ini Khusus Untuk Akun Premium! Silahkan Upgrade akun anda`)
reply(`Heyyo, ${pushname} Selamat datang di layanan ceknickname Games by ${footer}\n\nVARIAN GAMES :\n\n> .cekml <mobilelengends>\n> .cekff <freefire>\n> .cekhsr <honkaistarrail>\n> .cekgi <genshinimpact>\n> .cekhi3 <honkaiimpact3>\n> .cekcod <callofduty>\n> .cekaov <arenaofvalor>\n> .cekau2m <au2mobile>\n> .cekblackcloverm <blackclovermobile>\n> .cekdragon-raja <dragonraja>\n> .cekgarena-undawn <garenaundawn>\n> .ceklife-after <lifeafter>\n> .cekpb <pointblank>\n> .ceksausageman <sausageman>\n> .cekvalo <valorant>\n\nSilahkan Balas chat ini jika ingin ceknickname\n*Contoh :* .cekml\n\n${toko}`)
            
            }
            break
             case 'banks':{
             if (cek("verfiyemail", m.sender) == true) return reply(`Oops, Silahkan Daftarkan Email anda\nContoh : .setemail xxxxx@gmail.com`);
    if (cek("cekVerify", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, `Oops, Silahkan Verifikasi Email : ${cek("email", m.sender)}`, ['Verifikasicode','Hubungi Admin']);
                  if(cek("syarat", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, 'Oops, Kamu Belum Menyetujui Syarat Ketentuan dari kami. Mohon setujuin dulu, agar dapat mengakses fitur dari kami.', ['Saya Setuju','Syarat nya apa aja']);
if(cek("level", m.sender) == "Basic") return reply(`Oops, Fitur Ini Khusus Untuk Akun Premium! Silahkan Upgrade akun anda`)
            AnanthaGanz.sendPoll(m.chat, `Pilih duluu yukk`, ['Listbank','Cekbankid'])
            }
            break
               case 'e-wallets':{
             if (cek("verfiyemail", m.sender) == true) return reply(`Oops, Silahkan Daftarkan Email anda\nContoh : .setemail xxxxx@gmail.com`);
    if (cek("cekVerify", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, `Oops, Silahkan Verifikasi Email : ${cek("email", m.sender)}`, ['Verifikasicode','Hubungi Admin']);
                  if(cek("syarat", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, 'Oops, Kamu Belum Menyetujui Syarat Ketentuan dari kami. Mohon setujuin dulu, agar dapat mengakses fitur dari kami.', ['Saya Setuju','Syarat nya apa aja']);
if(cek("level", m.sender) == "Basic") return reply(`Oops, Fitur Ini Khusus Untuk Akun Premium! Silahkan Upgrade akun anda`)
reply(`Heyyo, ${pushname} Selamat datang di layanan ceknickname EWallet by ${footer}\n\nVARIAN E Wallet :\n\n> .cekdana-wallet <dana>\n> .cekovo-wallet <ovo>\n> .cekgopay-wallet <gopay>\n> .ceklinkaja-wallet <linkaja>\n> .cekshopeepay-wallet <shopeepay>\nSilahkan Balas chat ini jika ingin ceknickname\n*Contoh :* .cekdana-wallet\n\n${toko}`)
            
            }
            break
             case 'shop': {
             if (cek("verfiyemail", m.sender) == true) return reply(`Oops, Silahkan Daftarkan Email anda\nContoh : .setemail xxxxx@gmail.com`);
    if (cek("cekVerify", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, `Oops, Silahkan Verifikasi Email : ${cek("email", m.sender)}`, ['Verifikasicode','Hubungi Admin']);
                  if(cek("syarat", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, 'Oops, Kamu Belum Menyetujui Syarat Ketentuan dari kami. Mohon setujuin dulu, agar dapat mengakses fitur dari kami.', ['Saya Setuju','Syarat nya apa aja']);
    AnanthaGanz.sendPoll(m.chat, `Selamat datang di market place kami, dipilih dulu yuk cuman di klik aja kok\n\nTransaksi aman dan cepat di ${footer}.`, ['Prabayar (Pulsa,Data,Games,dll)','Pascabayar (Indihome,Pdam,dll)'])
}
break
            case 'adminmenu': {
    if (!isOwner) return m.reply(mess.owner);
    if(cek("syarat", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, 'Oops, Kamu Belum Menyetujui Syarat Ketentuan dari kami. Mohon setujuin dulu, agar dapat mengakses fitur dari kami.', ['Saya Setuju','Syarat nya apa aja']);
if(cek("verfiyemail", m.sender) == true) return reply(`Oops, Silahkan Daftarkan Email anda\nContoh : .setemail xxxxx@gmail.com`)
                AnanthaGanz.sendPoll(m.chat, `ADMIN MENU VERSI 2.1`, ['Intergrasi','IPV4','AllMember'])
            }
            break
            case 'allmember': {
              if (!isOwner) return m.reply(mess.owner);
              if (cek("verfiyemail", m.sender) == true) return reply(`Oops, Silahkan Daftarkan Email anda\nContoh : .setemail xxxxx@gmail.com`);
    if (cek("cekVerify", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, `Oops, Silahkan Verifikasi Email : ${cek("email", m.sender)}`, ['Verifikasicode','Hubungi Admin']);
    if(cek("syarat", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, 'Oops, Kamu Belum Menyetujui Syarat Ketentuan dari kami. Mohon setujuin dulu, agar dapat mengakses fitur dari kami.', ['Saya Setuju','Syarat nya apa aja']);
if(cek("verfiyemail", m.sender) == true) return reply(`Oops, Silahkan Daftarkan Email anda\nContoh : .setemail xxxxx@gmail.com`)
                AnanthaGanz.sendPoll(m.chat, `FITUR SHOW MEMBER`, ['ListMember','Cekriwayattrx','Cekmember','Accdepo','Minsaldo'])
            }
            break
            case 'digiflazz': {
              if (!isOwner) return m.reply(mess.owner);
    if(cek("syarat", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, 'Oops, Kamu Belum Menyetujui Syarat Ketentuan dari kami. Mohon setujuin dulu, agar dapat mengakses fitur dari kami.', ['Saya Setuju','Syarat nya apa aja']);
if(cek("verfiyemail", m.sender) == true) return reply(`Oops, Silahkan Daftarkan Email anda\nContoh : .setemail xxxxx@gmail.com`)
                AnanthaGanz.sendPoll(m.chat, `FITUR VENDOR PPOB DIGIFLAZZ`, ['Balance Digiflazz','Get_seller','Get_prabayar','Get_pascabayar','Margin Harga','Addharga','Editnama Produk','Editharga Produk','Rekap Transaksi','Cek'])
            }
            break
            case 'intergrasi': {
              if (!isOwner) return m.reply(mess.owner);
    if(cek("syarat", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, 'Oops, Kamu Belum Menyetujui Syarat Ketentuan dari kami. Mohon setujuin dulu, agar dapat mengakses fitur dari kami.', ['Saya Setuju','Syarat nya apa aja']);
if(cek("verfiyemail", m.sender) == true) return reply(`Oops, Silahkan Daftarkan Email anda\nContoh : .setemail xxxxx@gmail.com`)
                AnanthaGanz.sendPoll(m.chat, `BOT INI TERINTEGRASI DENGAN 2 VENDOR YAITU :`, ['Digiflazz [PPOB]','Infopaydisini [PG]'])
            }
            break
            /* End Case Custom */
            
            /* Fitur Database Rekap & Lain */
            case "toplayanan": {
            if(cek("syarat", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, 'Oops, Kamu Belum Menyetujui Syarat Ketentuan dari kami. Mohon setujuin dulu, agar dapat mengakses fitur dari kami.', ['Saya Setuju','Syarat nya apa aja']);
if(cek("verfiyemail", m.sender) == true) return reply(`Oops, Silahkan Daftarkan Email anda\nContoh : .setemail xxxxx@gmail.com`)
if(cek("level", m.sender) == "Basic") return reply(`Oops, Fitur Ini Khusus Untuk Akun Premium! Silahkan Upgrade akun anda`)
    
    const filePath = './SETTING/DB/trxuser.json';

    try {
        const fileData = fs.readFileSync(filePath, 'utf8');
        const allTransactions = JSON.parse(fileData);

        if (Array.isArray(allTransactions) && allTransactions.length > 0) {
            const productDetails = allTransactions.reduce((acc, transaction) => {
                const productName = transaction.produk;

                if (!acc[productName]) {
                    acc[productName] = {
                        count: 0,
                        totalHarga: 0
                    };
                }

                acc[productName].count += 1;
                acc[productName].totalHarga += transaction.harga; // Dengan asumsi nama properti adalah 'Harga'

                return acc;
            }, {});

            const sortedProducts = Object.keys(productDetails).sort((a, b) => productDetails[b].count - productDetails[a].count);
            const topProducts = sortedProducts.slice(0, 10);

            const topProductsList = topProducts.map((product, index) => `ℝ𝕒𝕥𝕚𝕟𝕘 ${index + 1}\n> 𝐏𝐫𝐨𝐝𝐮𝐜𝐭 𝐧𝐚𝐦𝐞 : ${product}\n> 𝐎𝐫𝐝𝐞𝐫 𝐐𝐮𝐚𝐧𝐭𝐢𝐭𝐲 : ${productDetails[product].count}\n> 𝐓𝐨𝐭𝐚𝐥 𝐂𝐚𝐬𝐡 𝐎𝐮𝐭 : ${formatmoney(productDetails[product].totalHarga)}\n`).join('\n');
            
            // Hitung harga total di semua customer_kode
            const totalPrice = Object.values(productDetails).reduce((total, product) => total + product.totalHarga, 0);
             const currentDate = new Date();
        const monthNames = [
    'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December'
];
        const currentMonth = monthNames[currentDate.getMonth()];
        const currentYear = currentDate.getFullYear();
            reply(` *𝕋𝕠𝕡 𝟙𝟘 ℙ𝕣𝕠𝕕𝕦𝕔𝕥𝕤 𝔹𝕪 𝕆𝕣𝕕𝕖𝕣* \n\n
𝚃𝚑𝚒𝚜 𝙼𝚘𝚗𝚝𝚑 : ${currentMonth} ${currentYear}\n
-----------------------------------------
${topProductsList}
-----------------------------------------
𝗧𝗵𝗼𝘀𝗲 𝗮𝗿𝗲 𝗼𝘂𝗿 𝟭𝟬 𝗯𝗲𝘀𝘁 𝘀𝗲𝗹𝗹𝗶𝗻𝗴 𝗽𝗿𝗼𝗱𝘂𝗰𝘁𝘀`);
        } else {
            reply("Oops, belum ada data produk terlaris.");
        }
    } catch (error) {
        console.error('Error reading/parsing the JSON file:', error);
reply("Oops, terjadi kesalahan. Mohon hubungi admin untuk bantuan lebih lanjut.");
    }
    break;
}

function isValidEmailFormat(email) {
    return email.includes('@');
}
case 'setemail': {
    // Cek apakah pengguna sudah memiliki email yang terverifikasi
    if (cek("verfiyemail", m.sender) == false) 
        return reply(`Oops, Email hanya dapat diganti 1, jika ada kendala di email silahkan hubungi admin`);
    if (!cek("cekVerify", m.sender) == true) 
        return reply(`Oops, Bukan Email anda lalu klik tombol verifikasi!`);
    // Split pesan untuk mendapatkan email
    let email = text.split(" ")[0];
    // Memastikan alamat email memiliki "@" dan format yang benar
    if (!email.includes('@') || !isValidEmailFormat(email)) {
        return reply(`Oops, Email yang kamu input tidak valid`);
    }
    // Baca file JSON
    const filePath = './SETTING/DB/user.json';
    try {
        const fileData = fs.readFileSync(filePath, 'utf8');
        const allUserData = JSON.parse(fileData);

        // Periksa apakah email sudah ada dalam data pengguna
        let emailAlreadyExists = false;
        for (const userData of allUserData) {
            // Jika email sudah ada, tandai bahwa email sudah terdaftar
            if (userData.email === email) {
                emailAlreadyExists = true;
                break;
            }
        }

        // Jika email sudah terdaftar, kirim pesan bahwa email telah digunakan
        if (emailAlreadyExists) {
            return reply(`Oops, Email Telah Digunakan Oleh User Lain`);
        }
    function generateRandomCodev(length) {
    let characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    let code = '';
    for (let i = 0; i < length; i++) {
        code += characters.charAt(Math.floor(Math.random() * characters.length));
    }
    return code;
}
let code = dengan_nol + "_" + generateRandomCodev(20);
    // Generate random confirmation code
    sendConfirmationEmail(email, code)
    // Simpan email bersama dengan pengguna
    sett("email", m.sender, email);
    sett("verfiyemail", m.sender, false);
    reply("Sip, Silahkan Periksa Email anda, jika tidak menerima kode silahkan cek folder spam");
    } catch (error) {
        console.error("Error:", error);
        return reply("Oops, Terjadi kesalahan saat memperbarui email.");
    }
    break;
}
case 'verifikasicode':{
 if (cek("cekVerify", m.sender) == false) 
        return reply(`Oops, Kamu sudah terverifikasi`);
function generateRandomCodev(length) {
    let characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    let code = '';
    for (let i = 0; i < length; i++) {
        code += characters.charAt(Math.floor(Math.random() * characters.length));
    }
    return code;
}
let code = dengan_nol + "_" + generateRandomCodev(20);
let email = cek("email", m.sender)
    // Generate random confirmation code
    sendConfirmationEmail(email, code)

    // Simpan email bersama dengan pengguna
    reply(`Berhasil Silahkan Cek Email ${cek("email", m.sender)}`)
    }
    break
case 'registrasi': {
    // Memeriksa apakah pengguna telah memasukkan kode konfirmasi
    let userVerificationCode = text.split(" ")[0];
    let savedVerificationCode = cek("verificationCode", m.sender);
    console.log("User Verification Code:", userVerificationCode);
    console.log("Saved Verification Code:", savedVerificationCode);
    // Memeriksa apakah kode konfirmasi yang dimasukkan oleh pengguna sama dengan yang disimpan
    if (userVerificationCode !== savedVerificationCode) {
        return reply("Oops, kode yang anda input tidak valid");
    }
    // Lanjutkan proses pendaftaran jika kode konfirmasi valid
    // Simpan informasi pendaftaran ke dalam database atau penyimpanan sementara
    // Misalnya, Anda dapat menyimpan email dan kode konfirmasi yang telah diverifikasi
    // serta informasi pengguna lainnya.
    let userEmail = cek("email", m.sender);
    // Lanjutkan dengan proses pendaftaran, misalnya:
    // registrasi(userEmail, otherUserData);

    // Tandai email sebagai terverifikasi
    sendEmail();
    sett("cekVerify", m.sender, false);
    sett("verificationCode", m.sender, "");
    reply("Oke sip, email kamu udah terverifikasi");
    break;
}
case 'minbalance': {
  // Memeriksa apakah pengguna adalah pemilik bot
  if (!isOwner) return reply(mess.owner)
  // Memeriksa apakah pesan berisi data yang diperlukan xx
  if (!text) return reply(`Oops, Kamu salah input!\n\nContoh : ${prefix}minbalance 62851xxxx|20000`)
  // Memecah pesan menjadi ID dan saldo
  let id = text.split("|")[0]
  let saldo = text.split("|")[1] * 1
  // Memastikan saldo dimasukkan dengan benar
  if (!saldo) return reply(`Oops, Kamu salah input!\n\nContoh : ${prefix}minbalance 62851xxxx|20000`)
  // Mengurangkan saldo dari akun yang ditentukan
  sett("-saldo", id + "@s.whatsapp.net", saldo) 
  // Mendapatkan saldo terbaru dari akun yang terpengaruh
  let updatedSaldo = cek("saldo", id+"@s.whatsapp.net")
  // Memperbarui saldo agar dibulatkan
  updatedSaldo = Math.round(updatedSaldo)
  // Memberikan konfirmasi bahwa saldo berhasil dikurangkan
  reply(`Sip, Saldo ${formatmoney(saldo)} Pada User ${id} Telah Dikurangi Saldo Akun Terbaru User Tersebut ${formatmoney(updatedSaldo)}`)
  // Mengirim pesan notifikasi ke akun yang terpengaruh
  setTimeout(function(){
  AnanthaGanz.sendMessage(id+ "@s.whatsapp.net",{text: `Yoo, Ada Update Saldo Terbaru dari admin!! Saldo Anda telah dikurangi sebesar ${formatmoney(saldo)} Saldo Akun Anda Sekarang ${formatmoney(updatedSaldo)}`})
  }, 3000)
  
  // Mengatur ulang data terkait deposit
  sett("deposit", m.sender, "")
  sett("reff_deposit", m.sender, "")
  sett("tanggal_deposit", m.sender, "")
}
break
case 'accdepo': {
    if (!isOwner) return m.reply(mess.owner);
    let id = text.split(" ")[0];
    let sndr = id + "@s.whatsapp.net";
    const checkIdDepo1 = (userId, deppo) => {
        let status = false;
        Object.keys(deppo).forEach((i) => {
            if (deppo[i].id === userId) {
                status = true;
            }
        });
        return status;
    };
    const filePath = `./SETTING/DB/TRANSACTION/Api/Deposit/${cek("deposit", sndr)}.json`;
    if (!fs.existsSync(filePath)) {
        return reply(`Oops, User ${id} tidak melakukan request deposit`);
    }
    const deppo = JSON.parse(fs.readFileSync(filePath));
    let ref_sender = checkIdDepo1(sndr, deppo) ? checkIdDepo1(sndr, deppo) : deppo.ref;
    let saldo = (checkIdDepo1(sndr, deppo) ? checkIdDepo1(sndr, deppo) : deppo.total) * 1;
    
    if (!id || !saldo) {
        return reply(`*FITUR ADDSALDO MANUAL* 
Silakan Gunakan Dengan Cara :
*${prefix}accdepo no_wa*
Contoh :
*${prefix}accdepo no_wa`);
    }
    sett("+saldo", sndr, saldo);
    reply(`Deposit sudah diproses.\nID : ${id}\nPenambahan : ${formatmoney(saldo)}\nTotal Saldo : *${formatmoney(cek("saldo", sndr))}*\n*Catatan :* ${ref_sender}`);
    setTimeout(function() {
        AnanthaGanz.sendMessage(sndr, {
            text: `*NOTIFICATION UPDATE SALDO*\nPenambahan Saldo Dari Admin\n*Catatan :* ${ref_sender}\n*Penambahan :* ${formatmoney(saldo)}\n*Saldo Total :* ${formatmoney(cek("saldo", sndr))}`
        });
    }, 0);
    const depoFilePath = './SETTING/DB/TRANSACTION/depouser.json';
    const depoUser = JSON.parse(fs.readFileSync(depoFilePath, 'utf8'));
    const newDepo = {
        buyer: sndr,
        status: "PAID",
        jam: moment.tz(`Asia/${global.Wilayah}`).format('HH:mm:ss'),
        waktu: moment.tz(`Asia/${global.Wilayah}`).format('DD/MM/YY'),
        no_pembayaran: ref_sender,
        method: `MANUAL`,
        jumlah: saldo.toString(),
        fee: `0`,
        total: saldo.toString(),
    };
    
    depoUser.push(newDepo);
    fs.writeFileSync(depoFilePath, JSON.stringify(depoUser, null, 2), 'utf8');
    setTimeout(() => {
        sett("deposit", "", "");
        sett("desc_prabayar", "", "");
        sett("status", sndr, true);
        sett("desc_prabayar", "", "");
        fs.unlinkSync(filePath);
    }, 3000);
}
break;
case 'topuser': {
if(cek("syarat", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, 'Oops, Kamu Belum Menyetujui Syarat Ketentuan dari kami. Mohon setujuin dulu, agar dapat mengakses fitur dari kami.', ['Saya Setuju','Syarat nya apa aja']);
if(cek("verfiyemail", m.sender) == true) return reply(`Oops, Silahkan Daftarkan Email anda\nContoh : .setemail xxxxx@gmail.com`)
if(cek("level", m.sender) == "Basic") return reply(`Oops, Fitur Ini Khusus Untuk Akun Premium! Silahkan Upgrade akun anda`)
    const filePath = './SETTING/DB/trxuser.json';

    try {
        // Baca file JSON
        const fileData = fs.readFileSync(filePath, 'utf8');
        const allUserData = JSON.parse(fileData);

        if (allUserData.length === 0) {
            return reply("Oops! belum ada data leaderboard");
        }

        // Buat peta untuk menyimpan informasi pengguna
        const userMap = new Map();

        // Ulangi semua data transaksi untuk menghitung total transaksi setiap pengguna
        allUserData.forEach(data => {
            const user = data.buyer.split('@')[0]; // Ambil nomor pengguna tanpa @s.whatsapp.net

            // Perbarui total transaksi dan jumlah order pengguna
            if (userMap.has(user)) {
                const userInfo = userMap.get(user);
                userInfo.totalTransactions += 1;
                userInfo.totalOrders += parseFloat(data.harga);
            } else {
                userMap.set(user, {
                    totalTransactions: 1,
                    totalOrders: parseFloat(data.harga)
                });
            }
        });

        // Urutkan pengguna berdasarkan total transaksi dalam urutan menurun
        const sortedUserList = Array.from(userMap).sort((a, b) => b[1].totalTransactions - a[1].totalTransactions).slice(0, 10);

        // Format daftar pengguna
        const formattedUserList = sortedUserList.map(([user, userData], index) => {
          let censoredNumber = user.replace(/^62/, '0');
    censoredNumber = `${censoredNumber.substring(0, 5)}*****${censoredNumber.substring(censoredNumber.length - 4)}`;
            
            return `𝚄𝚜𝚎𝚛𝚜 ${index + 1}\n> 𝐈𝐃 : ${censoredNumber}\n> 𝐓𝐨𝐭𝐚𝐥 𝐓𝐫𝐚𝐧𝐬𝐚𝐜𝐭𝐢𝐨𝐧𝐬 : ${userData.totalTransactions}\n> 𝐓𝐨𝐭𝐚𝐥 𝐂𝐚𝐬𝐡 𝐎𝐮𝐭 : ${formatmoney(userData.totalOrders)}\n`;
        });

        const currentDate = new Date();
        const monthNames = [
    'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December'
];
        const currentMonth = monthNames[currentDate.getMonth()];
        const currentYear = currentDate.getFullYear();
        const replyMessage = `
 *Top 10 Pengguna Yang Paling Aktif* \n\n
Bulan : ${currentMonth} ${currentYear}\n
-----------------------------------------
${formattedUserList.join('\n')}
-----------------------------------------
*${toko}*
`;

        reply(replyMessage);
    } catch (error) {
        console.error('Error reading the transaction history file:', error);
        reply("Oops, terjadi kesalahan. Mohon hubungi admin untuk bantuan lebih lanjut.");
    }
    break;
}
case 'topdeposit': {
if(cek("syarat", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, 'Oops, Kamu Belum Menyetujui Syarat Ketentuan dari kami. Mohon setujuin dulu, agar dapat mengakses fitur dari kami.', ['Saya Setuju','Syarat nya apa aja']);
if(cek("verfiyemail", m.sender) == true) return reply(`Oops, Silahkan Daftarkan Email anda\nContoh : .setemail xxxxx@gmail.com`)
if(cek("level", m.sender) == "Basic") return reply(`Oops, Fitur Ini Khusus Untuk Akun Premium! Silahkan Upgrade akun anda`)
    const filePath = './SETTING/DB/TRANSACTION/depouser.json';

    try {
        // Baca file JSON
        const fileData = fs.readFileSync(filePath, 'utf8');
        const allUserData = JSON.parse(fileData);

        if (allUserData.length === 0) {
          return reply("Oops! belum ada data leaderboard");
        }

        // Buat peta untuk menyimpan informasi pengguna
        const userMap = new Map();

        // Ulangi semua data transaksi untuk menghitung total deposit setiap pengguna
        allUserData.forEach(data => {
            const user = data.buyer.split('@')[0]; // Ambil nomor pengguna tanpa @s.whatsapp.net
            const amount = parseFloat(data.jumlah); // Ambil jumlah deposit

            // Perbarui total deposit dan jumlah deposit pengguna
            if (userMap.has(user)) {
                const userData = userMap.get(user);
                userData.totalDeposits += amount;
                userData.numTransactions++;
            } else {
                userMap.set(user, {
                    totalDeposits: amount,
                    numTransactions: 1
                });
            }
        });

        // Urutkan pengguna berdasarkan total deposit dalam urutan menurun
        const sortedUserList = Array.from(userMap).sort((a, b) => b[1].totalDeposits - a[1].totalDeposits).slice(0, 10);

        // Format daftar pengguna
    const formattedUserList = sortedUserList.map(([user, userData], index) => {
    let censoredNumber = user.replace(/^62/, '0');
    censoredNumber = `${censoredNumber.substring(0, 5)}*****${censoredNumber.substring(censoredNumber.length - 4)}`;
    // Rest of your code
            
            return `𝚄𝚜𝚎𝚛𝚜 ${index + 1}\n> 𝐈𝐃 : ${censoredNumber}\n> 𝐓𝐨𝐭𝐚𝐥 𝐓𝐫𝐚𝐧𝐬𝐚𝐜𝐭𝐢𝐨𝐧𝐬 : ${formatmoney(userData.totalDeposits)}\n> 𝐓𝐨𝐭𝐚𝐥 𝐂𝐚𝐬𝐡 𝐈𝐧 : ${userData.numTransactions}\n`;
        });

        const currentDate = new Date();
        const monthNames = [
    'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December'
];
        const currentMonth = monthNames[currentDate.getMonth()];
        const currentYear = currentDate.getFullYear();
        const replyMessage = `
 *𝕋𝕠𝕡 𝟙𝟘 𝕌𝕤𝕖𝕣𝕤 𝕨𝕚𝕥𝕙 𝕥𝕙𝕖 𝕄𝕠𝕤𝕥 𝔻𝕖𝕡𝕠𝕤𝕚𝕥𝕤* \n\n
𝚃𝚑𝚒𝚜 𝙼𝚘𝚗𝚝𝚑 : ${currentMonth} ${currentYear}\n
-----------------------------------------
${formattedUserList.join('\n')}
-----------------------------------------
𝗖𝗵𝗲𝗲𝗿𝘀 𝘁𝗼 𝗴𝗲𝘁𝘁𝗶𝗻𝗴 𝗶𝗻𝘁𝗼 𝘁𝗵𝗲 𝘁𝗼𝗽!
`;

        reply(replyMessage);
    } catch (error) {
        console.error('Error reading the transaction history file:', error);
        reply("Oops, terjadi kesalahan. Mohon hubungi admin untuk bantuan lebih lanjut.");
    }
    break;
}
case 'detail.':{
if(cek("syarat", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, 'Oops, Kamu Belum Menyetujui Syarat Ketentuan dari kami. Mohon setujuin dulu, agar dapat mengakses fitur dari kami.', ['Saya Setuju','Syarat nya apa aja']);
if(cek("verfiyemail", m.sender) == true) return reply(`Oops, Silahkan Daftarkan Email anda\nContoh : .setemail xxxxx@gmail.com`)
if(cek("level", m.sender) == "Basic") return reply(`Oops, Fitur Ini Khusus Untuk Akun Premium! Silahkan Upgrade akun anda`)
reply(`*Masukan SKU CODE* Contoh: ${prefix}detail ML5`);
}
break
case 'detail': {    
    if(cek("syarat", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, 'Oops, Kamu Belum Menyetujui Syarat Ketentuan dari kami. Mohon setujuin dulu, agar dapat mengakses fitur dari kami.', ['Saya Setuju','Syarat nya apa aja']);
    if(cek("verfiyemail", m.sender) == true) return reply(`Oops, Silahkan Daftarkan Email anda\nContoh : .setemail xxxxx@gmail.com`)
    if(cek("level", m.sender) == "Basic") return reply(`Oops, Fitur Ini Khusus Untuk Akun Premium! Silahkan Upgrade akun anda`)
    let code_nya = q.split(" ")[0];
    if (!code_nya) return reply(`*Masukan SKU CODE* Contoh: ${prefix}detail ML5`);
    let data16a = JSON.parse(fs.readFileSync('./SETTING/DB/datadigiflaz.json'));
    let listProduct16z = "𝗗𝗘𝗧𝗔𝗜𝗟 𝗣𝗥𝗢𝗗𝗨𝗖𝗧\n\n";
    let found = false;
    
    for (let i of data16a) {
        if (i.buyer_sku_code == code_nya) {  
            found = true;
            let stock_display = i.stock === 0 ? "∞" : i.stock;
            let status = i.seller_product_status ? "Ready" : "Sold Out";
            let multiStatus = i.multi ? "Ya" : "Tidak";
            let cutOffTime = `${i.start_cut_off} - ${i.end_cut_off}`;
            listProduct16z += `› 𝗡𝗮𝗺𝗮 𝗣𝗿𝗼𝗱𝘂𝗸 : ${i.product_name}
› 𝗕𝗿𝗮𝗻𝗱𝘀 : ${i.brand}
› 𝗞𝗮𝘁𝗲𝗴𝗼𝗿𝗶 : ${i.category}
› 𝗧𝘆𝗽𝗲 : ${i.type}
› 𝗞𝗼𝗱𝗲 : ${i.buyer_sku_code}
› 𝗛𝗮𝗿𝗴𝗮 : ${formatmoney(i.price)}
› 𝗦𝘁𝗼𝗰𝗸 : ${stock_display}
› 𝗣𝗿𝗼𝗱𝘂𝗸 𝗦𝘁𝗮𝘁𝘂𝘀 : ${status}
› 𝗠𝘂𝗹𝘁𝗶 𝗢𝗿𝗱𝗲𝗿 : ${multiStatus}
› 𝗝𝗮𝗺 𝗖𝘂𝘁 𝗢𝗳𝗳 : ${cutOffTime}
› 𝗗𝗲𝘀𝗸𝗿𝗶𝗽𝘀𝗶 : ${i.desc}

${toko}`;
        }
    }
    
    if (!found) {
        return reply(`Produk dengan kode ${code_nya} tidak ditemukan.`);
    }
    
    reply(`${listProduct16z}`);
}
break;
  
// Fungsi untuk mengonversi waktu ke WIB
function convertToWIB(time) {
    let [hours] = time.split(":");
    let wibHours = parseInt(hours) - 1; // Kurangi 1 jam untuk konversi ke WIB
    if (wibHours < 0) {
        wibHours += 24;
    }
    let formattedTime = `${wibHours.toString().padStart(2, "0")}:00`;
    return formattedTime;
}
case 'cek': {	
if(cek("verfiyemail", m.sender) == true) return reply(`Oops, Silahkan Daftarkan Email anda\nContoh : .setemail xxxxx@gmail.com`)
    if (!isOwner) return m.reply(mess.owner);	
    if (m.isGroup) return m.reply(mess.private);	
    let code_buat_cek = q.split(" ")[0];
    if (!code_buat_cek) return reply(`*Masukan SKU CODE*\n*Contoh:* ${prefix}cek ML5`);
    let listProduct16 = "𝗗𝗘𝗧𝗔𝗜𝗟 𝗣𝗥𝗢𝗗𝗨𝗖𝗧\n";
    let found = false;
    
    for (let i of d) {
        let stock_display = i.stock === 0 ? "∞" : i.stock;
        if (i.buyer_sku_code == code_buat_cek) { 
            found = true;
            let multiStatus = i.multi ? "Ya" : "Tidak";
            let sellerProductStatus = i.seller_product_status ? "Ready" : "Sold Out";
            let cutOffStartTime = convertToWita(i.start_cut_off);
            let cutOffEndTime = convertToWita(i.end_cut_off);
            let cutOffTime = `${cutOffStartTime} - ${cutOffEndTime} WITA`;
            listProduct16 += `
› 𝗡𝗮𝗺𝗮 𝗣𝗿𝗼𝗱𝘂𝗸 : ${i.product_name}\n› 𝗕𝗿𝗮𝗻𝗱𝘀 : ${i.brand}\n› 𝗞𝗮𝘁𝗲𝗴𝗼𝗿𝗶 : ${i.category}\n› 𝗧𝘆𝗽𝗲 : ${i.type}\n› 𝗞𝗼𝗱𝗲 : ${i.buyer_sku_code}\n› 𝗛𝗮𝗿𝗴𝗮 : ${formatmoney(i.price)}\n› 𝗦𝘁𝗼𝗰𝗸 : ${stock_display}\n› 𝗠𝘂𝗹𝘁𝗶 : ${multiStatus}\n› *Nama Seller :* ${i.seller_name}\n› 𝗦𝘁𝗮𝘁𝘂𝘀 𝗣𝗿𝗼𝗱𝘂𝗸 𝗦𝗲𝗹𝗹𝗲𝗿 : ${sellerProductStatus}\n› 𝗝𝗮𝗺 𝗖𝘂𝘁 𝗢𝗳𝗳 : ${cutOffTime}\n› 𝗗𝗲𝘀𝗸𝗿𝗶𝗽𝘀𝗶 : ${i.desc}\n\n${toko}`;
        }
    };
    
    if (!found) {
        return reply(`Produk dengan kode ${code_buat_cek} tidak ditemukan.`);
    }
    
    reply(`${listProduct16}`);
}
break;

// Fungsi untuk mengonversi waktu ke WITA
function convertToWita(time) {
    let [hours, minutes] = time.split(":");
    let witaHours = parseInt(hours) + 1; // Tambah 1 jam untuk konversi ke WITA
    if (witaHours >= 24) {
        witaHours -= 24;
    }
    let formattedTime = `${witaHours.toString().padStart(2, "0")}:${minutes.padStart(2, "0")}`;
    return formattedTime;
}
case 'nonaktif.':{
if(cek("syarat", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, 'Oops, Kamu Belum Menyetujui Syarat Ketentuan dari kami. Mohon setujuin dulu, agar dapat mengakses fitur dari kami.', ['Saya Setuju','Syarat nya apa aja']);
if(cek("verfiyemail", m.sender) == true) return reply(`Oops, Silahkan Daftarkan Email anda\nContoh : .setemail xxxxx@gmail.com`)
if(cek("level", m.sender) == "Basic") return reply(`Oops, Fitur Ini Khusus Untuk Akun Premium! Silahkan Upgrade akun anda`)
let options = ['Nonaktif Games', 'Nonaktif Voucher', 'Nonaktif Pulsa', 'Nonaktif Data','Nonaktif E-Money'];

    // Kirim polling dengan opsi sesuai dengan kategori yang diminta
    AnanthaGanz.sendPoll(m.chat, `Pilih menu`, options)
    }
    break
case 'nonaktif':{	
if(cek("syarat", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, 'Oops, Kamu Belum Menyetujui Syarat Ketentuan dari kami. Mohon setujuin dulu, agar dapat mengakses fitur dari kami.', ['Saya Setuju','Syarat nya apa aja']);
if(cek("verfiyemail", m.sender) == true) return reply(`Oops, Silahkan Daftarkan Email anda\nContoh : .setemail xxxxx@gmail.com`)
if(cek("level", m.sender) == "Basic") return reply(`Oops, Fitur Ini Khusus Untuk Akun Premium! Silahkan Upgrade akun anda`)
    let category = q.split(" ")[0];
    if (!category) return reply(`*Masukkan Kategori*\n- Games\n- Pulsa\n- Data\n- PLN\n- Voucher\n\n*Contoh:* ${prefix}nonaktif Games`);
    
    let listProduct = "*BERIKUT DETAIL PRODUK NONAKTIF*\n";
    let found = false;
    
    for (let product of d) {
        if (product.category === category && !product.seller_product_status) {
            found = true;
            listProduct += `> Nama Produk: ${product.product_name}\n`;
            listProduct += `  Kode Produk: ${product.buyer_sku_code}\n`;
            listProduct += `  Status Produk: ${product.seller_product_status ? 'Aktif' : 'Nonaktif'}\n\n`;
        }
    }
    
    if (!found) {
        return reply(`Tidak ada produk nonaktif dalam kategori ${category}.`);
    }
    
    reply(`${listProduct}`);
    break;
}


case 'editharga': {
    // Memeriksa apakah pengguna adalah pemilik bot
    if (!isOwner) return reply(mess.owner);
    if(cek("verfiyemail", m.sender) == true) return reply(`Oops, Silahkan Daftarkan Email anda\nContoh : .setemail xxxxx@gmail.com`)
    // Memisahkan argumen dari pesan
    const args = text.split(' ');

    // Memeriksa apakah jumlah argumen sesuai
    if (args.length !== 2) {
        reply(`Contoh: ${prefix}editharga <buyer_sku_code> <new_price>`);
        return;
    }
    
    // Mendapatkan kode SKU pembeli dan nilai harga baru dari argumen
    const buyerSkuCode = args[0];
    const newPriceInput = args[1]; 
    
    // Mendapatkan data customer_kode dari file JSON
    let jsonData;
    try {
        jsonData = JSON.parse(fs.readFileSync('./SETTING/DB/datadigiflaz.json', 'utf8'));
    } catch (error) {
        reply("Error reading 'datadigiflaz.json': " + error.message);
        return;
    }
    
    let updated = false;
    let productName = '';
    let oldPrice = 0;
    let newPrice = 0;
    
    // Iterasi untuk mencari customer_kode dengan kode SKU yang sesuai
    for (let product of jsonData) {
        if (product.buyer_sku_code === buyerSkuCode) {
            // Menyimpan nama customer_kode dan harga lama
            productName = product.product_name;
            oldPrice = product.price;
            
            // Menggunakan nilai harga baru yang langsung diinput
            newPrice = parseFloat(newPriceInput);

            // Memperbarui harga customer_kode
            product.price = newPrice;
            updated = true;
            break;
        }
    }
    
    // Menulis kembali data customer_kode ke file JSON jika ada pembaruan
    if (updated) {
        fs.writeFileSync('./SETTING/DB/datadigiflaz.json', JSON.stringify(jsonData, null, 2), 'utf8');
        
        let hargadulu = oldPrice * 1
        let hargabaru = newPrice * 1
        // Memberikan balasan dengan informasi tentang customer_kode yang diperbarui
        reply(`Produk ${productName} berhasil diperbarui.\nHarga awal: ${formatmoney(hargadulu)}\nHarga baru: ${formatmoney(hargabaru)}`);
    } else {
        reply(`Gagal, Produk dengan KODE SKU ${buyerSkuCode} tidak ditemukan`);
    }
    break;
}
    
    
            case 'rekap': {
    if (!isOwner) return reply(mess.owner);
if (cek("verfiyemail", m.sender) == true) return reply(`Oops, Silahkan Daftarkan Email anda\nContoh : .setemail xxxxx@gmail.com`);
    if (cek("cekVerify", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, `Oops, Silahkan Verifikasi Email : ${cek("email", m.sender)}`, ['Verifikasicode','Hubungi Admin']);
    if(cek("syarat", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, 'Oops, Kamu Belum Menyetujui Syarat Ketentuan dari kami. Mohon setujuin dulu, agar dapat mengakses fitur dari kami.', ['Saya Setuju','Syarat nya apa aja']);
    const filePath = './SETTING/DB/trxuser.json';

    try {
        // Read the JSON file
        const fileData = fs.readFileSync(filePath, 'utf8');
        const allUserData = JSON.parse(fileData);

        if (allUserData.length === 0) {
            return reply("Gagal, Tidak Ditemukan Data Transaksi");
        }

        // Buat Peta Untuk Menyimpan Informasi Pembeli
        const buyerMap = new Map();

        // Inisialisasi variabel untuk totalHarga keseluruhan, totalHargaModal, totalProfit, totalTransaksi
        let overallTotalHarga = 0;
        let overallTotalHargaModal = 0;
        let overallTotalProfit = 0;
        let overallTotalTransactions = 0;

        // Ulangi seluruh riwayat transaksi untuk menghitung totalHarga, totalHargaModal, totalProfit, dan mengumpulkan detail
        allUserData.forEach(data => {
            // Ekstrak pembeli tanpa @s.whatsapp.net
            const buyerWithoutSuffix = data.buyer.split('@')[0];

            // Perbarui total keseluruhan
            overallTotalHarga += parseFloat(data.harga);
            overallTotalTransactions += 1;

            // Hitung totalHargaModal sebagai penjumlahan harga_modal untuk setiap transaksi
            const hargaModal = parseFloat(data.harga_modal);
            overallTotalHargaModal += isNaN(hargaModal) ? 0 : hargaModal;

            // Hitung keuntungan untuk setiap transaksi
            const profit = parseFloat(data.harga) - (isNaN(hargaModal) ? 0 : hargaModal);
            overallTotalProfit += profit;

            // Periksa apakah pembeli sudah ada di peta
            if (buyerMap.has(buyerWithoutSuffix)) {
                // Perbarui total transaksi pembeli yang ada, total harga, total harga modal, dan total keuntungan
                const buyerInfo = buyerMap.get(buyerWithoutSuffix);
                buyerInfo.totalTransactions += 1;
                buyerInfo.totalHarga += parseFloat(data.harga);
                buyerInfo.totalHargaModal += isNaN(hargaModal) ? 0 : hargaModal;
                buyerInfo.totalProfit += profit;
            } else {
                // Tambahkan pembeli baru ke peta
                buyerMap.set(buyerWithoutSuffix, {
                    totalTransactions: 1,
                    totalHarga: parseFloat(data.harga),
                    totalHargaModal: isNaN(hargaModal) ? 0 : hargaModal,
                    totalProfit: profit,
                });
            }
        });

        // Urutkan daftar pembeli berdasarkan totalProfit dalam urutan menurun
        const sortedBuyerList = Array.from(buyerMap).sort((a, b) => b[1].totalProfit - a[1].totalProfit);

        // Format totalHarga keseluruhan, totalHargaModal, totalProfit, dan totalTransaksi sebagai mata uang
        // Menggunakan Intl.NumberFormat untuk pemformatan mata uang


// Menggunakan fungsi formatMoney untuk pemformatan nilai
const formattedOverallTotalHarga = formatmoney(overallTotalHarga);
const formattedOverallTotalHargaModal = formatmoney(overallTotalHargaModal);
const formattedOverallTotalProfit = formatmoney(overallTotalProfit);

// ...

const buyerList = sortedBuyerList.map(([buyer, info]) => {
    const formattedTotalHarga = formatmoney(info.totalHarga);
    const formattedTotalHargaModal = formatmoney(info.totalHargaModal);
    const formattedTotalProfit = formatmoney(info.totalProfit);
const buyert = buyer.split('@')[0].replace('62', '0');
    return `𝗨𝘀𝗲𝗿 : ${buyert}\n> Total Pembelian : ${info.totalTransactions}\n> Omset : ${formattedTotalHarga}\n> Modal : ${formattedTotalHargaModal}\n> Profit : ${formattedTotalProfit}\n`;
});

const replyMessage = `𝗥𝗘𝗞𝗔𝗣 𝗢𝗥𝗗𝗘𝗥𝗦\n\n\`\`\`𝗧𝗼𝘁𝗮𝗹 𝗢𝗿𝗱𝗲𝗿𝘀 : ${overallTotalTransactions}\n𝗢𝗺𝘀𝗲𝘁 : ${formattedOverallTotalHarga}\n𝗠𝗼𝗱𝗮𝗹 : ${formattedOverallTotalHargaModal}\n𝗣𝗿𝗼𝗳𝗶𝘁 : ${formattedOverallTotalProfit} \n====================\`\`\`\n\n${buyerList.join('\n')}`;

reply(replyMessage);
    } catch (error) {
        console.error('Error reading the transaction history file:', error);
        reply("Gagal, Tidak dapat membaca data");
    }
    break;
}       
function isWithinDateRange(dateString, dateFrom, dateTo) {
    const date = moment(dateString, 'DD/MM/YY', true);
    return date.isBetween(moment(dateFrom, 'DD/MM/YY'), moment(dateTo, 'DD/MM/YY'), null, '[]');
} 


case 'info':
if (cek("verfiyemail", m.sender) == true) return reply(`Oops, Silahkan Daftarkan Email anda\nContoh : .setemail xxxxx@gmail.com`);
    if (cek("cekVerify", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, `Oops, Silahkan Verifikasi Email : ${cek("email", m.sender)}`, ['Verifikasicode','Hubungi Admin']);
    if(cek("syarat", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, 'Oops, Kamu Belum Menyetujui Syarat Ketentuan dari kami. Mohon setujuin dulu, agar dapat mengakses fitur dari kami.', ['Saya Setuju','Syarat nya apa aja']);
    const trxFilePath = './SETTING/DB/trxuser.json';
    const depFilePath = './SETTING/DB/TRANSACTION/depouser.json';

    try {
        // Baca file JSON riwayat transaksi
        const trxFileData = fs.readFileSync(trxFilePath, 'utf8');
        const allTrxUserData = JSON.parse(trxFileData);

        // Filter data untuk m.sender tertentu
        const trxUserData = allTrxUserData.filter(data => data.buyer === m.sender);

        // Hitung total transaksi
        const totalTransactions = trxUserData.length;
        
        // Baca file JSON riwayat deposit
        const depFileData = fs.readFileSync(depFilePath, 'utf8');
        const allDepUserData = JSON.parse(depFileData);

        // Filter data untuk m.sender tertentu
        const depUserData = allDepUserData.filter(data => data.buyer === m.sender);

        // Hitung total deposit
        const totalDeposits = depUserData.length;
      
        // Format pesan info
        let infoMessage = `𝗜𝗻𝗳𝗼𝗿𝗺𝗮𝘀𝗶 𝗔𝗸𝘂𝗻 𝗔𝗸𝘂𝗻\n\n`;
        infoMessage += `> Nama : ${pushname}\n`;
        infoMessage += `> Saldo : ${formatmoney(cek("saldo", m.sender))}\n`;
        infoMessage += `> UID : ${sender.replace("@s.whatsapp.net", "")}\n`;
        infoMessage += `> Email : ${cek("email", m.sender)}\n`;
        infoMessage += `> Tingkat : ${cek("level", m.sender)}\n`;
        infoMessage += `> Transaksi : ${totalTransactions}\n`;
        infoMessage += `> Deposit : ${totalDeposits}\n`;

        // Kirim pesan info dan daftar opsi
        AnanthaGanz.sendPoll(m.chat, infoMessage, ['Deposit','Riwayattrx','Riwayatdeposit','Detail. Product [Premium]','Transfer Sesama Pengguna [Premium]','Topuser [Premium]','Topdeposit [Premium]','Toplayanan [Premium]','Nonaktif. [Premium]','Upgrade Ke Premium','Manfaat Premium','hapus_akun']);
    } catch (error) {
        console.error('Error reading transaction history files:', error);
        reply("Gagal, Terjadi kesalahan saat mengambil riwayat transaksi Anda.");
    }
    break;
    case 'riwayattrx': {
if (cek("verfiyemail", m.sender) == true) return reply(`Oops, Silahkan Daftarkan Email anda\nContoh : .setemail xxxxx@gmail.com`);
    if (cek("cekVerify", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, `Oops, Silahkan Verifikasi Email : ${cek("email", m.sender)}`, ['Verifikasicode','Hubungi Admin']);
    if(cek("syarat", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, 'Oops, Kamu Belum Menyetujui Syarat Ketentuan dari kami. Mohon setujuin dulu, agar dapat mengakses fitur dari kami.', ['Saya Setuju','Syarat nya apa aja']);
    const filePath = './SETTING/DB/trxuser.json';
    try {
        // Baca file JSON
        const fileData = fs.readFileSync(filePath, 'utf8');
        const allUserData = JSON.parse(fileData);

        // Filter data untuk m.sender tertentu
        const userData = allUserData.filter(data => data.buyer === m.sender);

        if (userData.length === 0) {
            return reply("Kamu belum memiliki riwayat transaksi yang sukses.");
        }

        // Inisialisasi variabel untuk total harga dan total transaksi
        let totalHarga = 0;
        let totalTransactions = userData.length;

        // Ulangi riwayat transaksi pengguna untuk menghitung totalHarga
        userData.forEach(data => {
            totalHarga += parseFloat(data.harga);
        });

        // Ulangi riwayat transaksi pengguna untuk membuat historyText
        const historyText = userData.map((data, index) => {
          
            let totale = data.harga * 1

            return `
  Trx - ${index + 1}:
> Produk : ${data.produk}
> ID Trx : ${data.ref_id}
> Tujuan : ${data.tujuan}
> Harga : ${formatmoney(totale)}
> Status : Succes
> Waktu : ${data.jam} | ${data.waktu}
> Catatan : ${data.invoice}
`;
        });

let totalw = totalHarga * 1
        // Cantumkan total harga dan total transaksi di reply
        const replyMessage = `
*Riwayat Transaksi Kamu* 

Total Pesanan : ${totalTransactions}
Total Harga Pesanan : ${formatmoney(totalw)}

${historyText.join('\n')}
`;

        reply(replyMessage);
    } catch (error) {
        console.error('Error reading the transaction history file:', error);
        reply("Gagal, Ada Masalah Ketika Membaca data, silahkan hubungi Admin");
    }
    break;
}
    case 'riwayatdeposit': {
if (cek("verfiyemail", m.sender) == true) return reply(`Oops, Silahkan Daftarkan Email anda\nContoh : .setemail xxxxx@gmail.com`);
    if (cek("cekVerify", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, `Oops, Silahkan Verifikasi Email : ${cek("email", m.sender)}`, ['Verifikasicode','Hubungi Admin']);
    if(cek("syarat", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, 'Oops, Kamu Belum Menyetujui Syarat Ketentuan dari kami. Mohon setujuin dulu, agar dapat mengakses fitur dari kami.', ['Saya Setuju','Syarat nya apa aja']);
    const filePath = './SETTING/DB/TRANSACTION/depouser.json';
    try {
        // Baca file JSON
        const fileData = fs.readFileSync(filePath, 'utf8');
        const allUserData = JSON.parse(fileData);

        // Filter data untuk m.sender tertentu
        const userData = allUserData.filter(data => data.buyer === m.sender);

        if (userData.length === 0) {
            return reply("Kamu belum memiliki riwayat deposit.");
        }

        // Inisialisasi variabel untuk total harga dan total transaksi
        let totalHarga = 0;
        let totalTransactions = userData.length;

        // Ulangi riwayat transaksi pengguna untuk menghitung totalHarga
        userData.forEach(data => {
            totalHarga += parseFloat(data.total);
        });

        // Ulangi riwayat transaksi pengguna untuk membuat historyText
        const historyText = userData.map((data, index) => {
            // Format harga sebagai angka dengan simbol mata uang
            let fee = data.fee * 1
            let total = data.total * 1
            let jumlah = data.jumlah * 1
            return `
 Deposit - ${index + 1} : 
> Metode : ${data.method}
> Referensi : ${data.no_pembayaran}
> Jumlah : ${formatmoney(jumlah)}
> Biaya Admin : ${formatmoney(fee)} 
> Total : ${formatmoney(total)}
> Waktu : ${data.jam} | ${data.waktu}
> Status : ${data.status}
`;
});
       let totalw = totalHarga * 1
        // Cantumkan total harga dan total transaksi di reply
        const replyMessage = `
  *RIWAYAT DEPOSIT KAMU* 

Total Deposit : ${totalTransactions}
Total Nominal : ${formatmoney(totalw)}

${historyText.join('\n')}
`;

        reply(replyMessage);
    } catch (error) {
        console.error('Error reading the transaction history file:', error);
        reply("Gagal, Ada Masalah Ketika Membaca data, silahkan hubungi Admin");
    }
    break;
}
case 'riwayat': {
if(cek("syarat", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, 'Oops, Kamu Belum Menyetujui Syarat Ketentuan dari kami. Mohon setujuin dulu, agar dapat mengakses fitur dari kami.', ['Saya Setuju','Syarat nya apa aja']);
if(cek("verfiyemail", m.sender) == true) return reply(`Oops, Silahkan Daftarkan Email anda\nContoh : .setemail xxxxx@gmail.com`)
    const filePath = './SETTING/DB/trxuser.json';
    let tanggalFrom = text.split(" ")[0];
    let tanggalTo = text.split(" ")[1];

    // Periksa apakah kedua input tanggal disediakan
    if (!tanggalFrom || !tanggalTo) {
        return reply(`Gagal, Masukan Tanggal Awal & Akhir.\nContoh: ${prefix}riwayat 10/11/23 11/11/23`);
    }

    try {
        // Baca file JSON
        const fileData = fs.readFileSync(filePath, 'utf8');
        const allUserData = JSON.parse(fileData);

        // Filter data untuk m.sender tertentu dan dalam rentang tanggal
        const userData = allUserData.filter(data =>
            data.buyer === m.sender &&
            isWithinDateRange(data.waktu, tanggalFrom, tanggalTo)
        );

        if (userData.length === 0) {
            return reply(`Gagal, Tidak Ada Transaksi Yang Tercatat Pada Tanggal : ${tanggalFrom} - ${tanggalTo}`);
        }

        // Inisialisasi variabel untuk total harga dan total transaksi
        let totalHarga = 0;
        let totalTransactions = userData.length;

        // Ulangi riwayat transaksi pengguna untuk menghitung totalHarga
        userData.forEach(data => {
            totalHarga += parseFloat(data.harga);
        });

        // Ulangi riwayat transaksi pengguna untuk membuat historyText
        const historyText = userData.map((data, index) => {
            // Format Harga sebagai angka dengan simbol mata uang
            const formattedHarga = new Intl.NumberFormat('id-ID', {
                style: 'currency',
                currency: 'IDR'
            }).format(data.harga);

            return `🛒 𝗢𝗿𝗱𝗲𝗿𝘀 𝗞𝗲 ${index + 1} : 
› 𝗡𝗮𝗺𝗮 𝗣𝗿𝗼𝗱𝘂𝗸 : ${data.customer_kode}
› 𝗧𝗿𝘅𝗶𝗱 : ${data.ref_id}
› 𝗧𝘂𝗷𝘂𝗮𝗻 : ${data.tujuan}
› 𝗛𝗮𝗿𝗴𝗮 : ${formattedHarga}
› 𝗪𝗮𝗸𝘁𝘂 : ${data.jam} | ${data.waktu}
› 𝗦𝗻/𝗞𝗲𝘁 : ${data.invoice}\n`;
        });

        // Format total Harga sebagai mata uang
        const formattedTotalHarga = new Intl.NumberFormat('id-ID', {
            style: 'currency',
            currency: 'IDR'
        }).format(totalHarga);

        // Cantumkan total Harga dan total transaksi di reply
        const replyMessage = ` 𝗥𝗜𝗪𝗔𝗬𝗔𝗧 𝗢𝗥𝗗𝗘𝗥𝗦 

𝗧𝗼𝘁𝗮𝗹 𝗢𝗿𝗱𝗲𝗿𝘀 : ${totalTransactions}
𝗝𝘂𝗺𝗹𝗮𝗵 𝗢𝗿𝗱𝗲𝗿𝘀 : ${formattedTotalHarga}

${historyText.join('\n')}`;

        reply(replyMessage);
    } catch (error) {
        console.error('Error reading the transaction history file:', error);
         reply("Gagal, Ada Masalah Ketika Membaca data, silahkan hubungi Admin");
    }
    break;
}


case 'hubungi': {
if(cek("syarat", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, 'Oops, Kamu Belum Menyetujui Syarat Ketentuan dari kami. Mohon setujuin dulu, agar dapat mengakses fitur dari kami.', ['Saya Setuju','Syarat nya apa aja']);
if(cek("verfiyemail", m.sender) == true) return reply(`Oops, Silahkan Daftarkan Email anda\nContoh : .setemail xxxxx@gmail.com`)
    reply(`Hai Kak ${pushname}, Jika ada yang perlu ditanyakan atau ada kendala, jangan ragu untuk menghubungi tim Customer Service kami ya! 😉\n\nKamu bisa langsung chat dengan kami di WhatsApp melalui link berikut: (wa.me/${owner}?text=Halo)`);
    break;
}


  case 'reset': {
    if (!isOwner) return reply(mess.owner);

    const filesToReset = [
        './SETTING/DB/datadigiflaz.json',
        './SETTING/DB/admin.json',
        './SETTING/DB/pasca.json'
    ];

    try {
        // Menghapus isi teks dari setiap file
        filesToReset.forEach(file => fs.writeFileSync(file, '[]', 'utf8'));
        reply("Sip, Berhasil Menghapus");
    } catch (error) {
        console.error('Error resetting data:', error);
        reply('An error occurred while resetting data.');
    }

    break;
}
/* DIGIFLAZZ & LIST PRODUK */
case 'order':{
if (cek("verfiyemail", m.sender) == true) return reply(`Oops, Silahkan Daftarkan Email anda\nContoh : .setemail xxxxx@gmail.com`);
    if (cek("cekVerify", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, `Oops, Silahkan Verifikasi Email : ${cek("email", m.sender)}`, ['Verifikasicode','Hubungi Admin']);
if(cek("syarat", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, 'Oops, Kamu Belum Menyetujui Syarat Ketentuan dari kami. Mohon setujuin dulu, agar dapat mengakses fitur dari kami.', ['Saya Setuju','Syarat nya apa aja']);
if(cek("status", m.sender) == false) return AnanthaGanz.sendPoll(m.chat, `Oops, invoice ${cek("reff", m.sender)} masih tersedia!`, ['Batal Aja','Hubungi Admin']); 
let order_contoh = `*Tips Orders :*
${prefix}order <sku_kode> <tujuan/id/zone>
Contoh: ${prefix}order BY5 0851xxxxx

*NOTE :*
Perlu Diingat!! Silahkan Cek Dulu *Nomor Tujuan* kamu pastiin udh bener ya
`
let create_reff = koderef
let TimePesanan = `${moment.tz(`Asia/${global.Wilayah}`).format('HH:mm:ss')} | ${moment.tz(`Asia/${global.Wilayah}`).format('DD/MM/YY')}`
let customer_kode = text.split(" ")[0]
let customer_no = text.split(" ")[1]
if (!customer_kode) return reply(order_contoh);
if (!customer_no) return reply(order_contoh);

let hargaProduk = 0;
const MINIMAL_PEMBELIAN = 20000;
const MAXIMAL_PEMBELIAN = 1000000;
let potongan = 0; // Deklarasi variabel potongan di luar loop

for (let i of r) {
    if (i.buyer_sku_code == customer_kode) {
        let pricee = i.price * 1;
        let nama_produkk = i.product_name;
        let product_buyer = i.buyer_product_status;
        let product_seller = i.seller_product_status;
        let descc = i.desc;

        // Pastikan pembelian berada dalam rentang minimal dan maksimal
        if (pricee >= MINIMAL_PEMBELIAN && pricee <= MAXIMAL_PEMBELIAN) {
            if (cek("level", m.sender) == "Premium") { // Pastikan level pengguna adalah "Basic"
                let diskonPersen = "0.0005" // Diskon 10% untuk pengguna basic
                potongan = pricee * diskonPersen; // Hitung potongan harga berdasarkan persentase
                pricee -= potongan; // Kurangi potongan harga dari harga produk
            }
        }

        hargaProduk = pricee; // Simpan harga produk setelah diskon

        sett("price", m.sender, hargaProduk);
        sett("product_name", m.sender, nama_produkk);
        sett("status", m.sender, false);
        sett("tujuan", m.sender, customer_no);
        sett("buyer_sku_code", m.sender, customer_kode);
        sett("desc_prabayar", m.sender, descc);
        sett("reff", m.sender, create_reff);
    }
}

let harga = cek("price", m.sender) * 1; // Mendapatkan harga produk dari database
let potonganHarga = potongan * 1; // Menggunakan potongan harga yang telah dihitung sebelumnya
let jumlahHarga = harga + potonganHarga * 1 // Menambahkan harga produk dengan potongan harga
let totalPembayaran = jumlahHarga - potonganHarga * 1 // Menghitung total pembayaran setelah potongan harga
let zanncash = cek("saldo",m.sender) * 1
let cash = `${formatmoney(zanncash)}`
await loading()
    if (/^(PLN|PLNP)/.test(customer_kode)) {
    let axios = require('axios');
const url = `https://${global.APIcek}/api/pln-token/?target=${customer_no}&api_key=${global.KEYcek}`
axios.get(url)
  .then(response => {
  console.log(response.data);
  let invoice = `
> ---------------------------------------
> |    CONFIRM ORDER            
> ---------------------------------------
> | Layanan : ${cek("product_name", m.sender)}     
> | Tujuan : ${cek("tujuan", m.sender)}              
> | NickName : ${response.data.data.nama_pelanggan}
> ---------------------------------------
> | *ID Trx :* ${cek("reff",m.sender)}
> | *Catatan :* ${cek("desc_prabayar",m.sender)}
> ---------------------------------------
> | *Harga :* ${formatmoney(jumlahHarga)}
> | *Diskon :* ${formatmoney(potonganHarga)}
> | *Total :* ${formatmoney(totalPembayaran)}
> ---------------------------------------`;

    if (cek("product_name", m.sender) == "") return reply(`Gagal, kode_sku *${customer_kode}* engga ada, pastikan udah bener ya`);
    AnanthaGanz.sendPoll(m.chat, invoice, [`ZANNCASH [${cash}]`,`METODE LAIN`,`BATAL AJA`])
  })
  .catch(error => {
    console.error(error.response.data);
    let invoice = `
> ---------------------------------------
> |    CONFIRM ORDER
> ---------------------------------------
> | Layanan : ${cek("product_name", m.sender)}
> | Tujuan : ${cek("tujuan", m.sender)}
> | NickName : ga ketemu, bro
> ---------------------------------------
> | *ID Trx :* ${cek("reff",m.sender)}
> | *Catatan :* ${cek("desc_prabayar",m.sender)}
> ---------------------------------------
> | *Harga :* ${formatmoney(jumlahHarga)}
> | *Diskon :* ${formatmoney(potonganHarga)}
> | *Total :* ${formatmoney(totalPembayaran)}
> ---------------------------------------`;
    if (cek("product_name", m.sender) == "") return reply(`Gagal, kode_sku *${customer_kode}* engga ada, pastikan udah bener ya`);
    AnanthaGanz.sendPoll(m.chat, invoice, [`ZANNCASH [${cash}]`,`METODE LAIN`,`BATAL AJA`])
  });
} else if (customer_kode.startsWith('AUMD')) {
let axios = require('axios');
const url = `https://${global.APIcek}/api/au2m/?target=${customer_no}&api_key=${global.KEYcek}`
axios.get(url)
  .then(response => {
  console.log(response.data);
  let invoice = `
> ---------------------------------------
> |    CONFIRM ORDER            
> ---------------------------------------
> | Layanan : ${cek("product_name", m.sender)}     
> | Tujuan : ${cek("tujuan", m.sender)}              
> | NickName : ${response.data.data.nickname}     
> ---------------------------------------
> | *ID Trx :* ${cek("reff",m.sender)}
> | *Catatan :* ${cek("desc_prabayar",m.sender)}
> ---------------------------------------
> | *Harga :* ${formatmoney(jumlahHarga)}
> | *Diskon :* ${formatmoney(potonganHarga)}
> | *Total :* ${formatmoney(totalPembayaran)}
> ---------------------------------------`;

    if (cek("product_name", m.sender) == "") return reply(`Gagal, kode_sku *${customer_kode}* engga ada, pastikan udah bener ya`);
    AnanthaGanz.sendPoll(m.chat, invoice, [`ZANNCASH [${cash}]`,`METODE LAIN`,`BATAL AJA`])
  })
  .catch(error => {
    console.error(error.response.data);
    let invoice = `
> ---------------------------------------
> |    CONFIRM ORDER
> ---------------------------------------
> | Layanan : ${cek("product_name", m.sender)}
> | Tujuan : ${cek("tujuan", m.sender)}
> | NickName : ga ketemu, bro
> ---------------------------------------
> | *ID Trx :* ${cek("reff",m.sender)}
> | *Catatan :* ${cek("desc_prabayar",m.sender)}
> ---------------------------------------
> | *Harga :* ${formatmoney(jumlahHarga)}
> | *Diskon :* ${formatmoney(potonganHarga)}
> | *Total :* ${formatmoney(totalPembayaran)}
> ---------------------------------------`;
    if (cek("product_name", m.sender) == "") return reply(`Gagal, kode_sku *${customer_kode}* engga ada, pastikan udah bener ya`);
    AnanthaGanz.sendPoll(m.chat, invoice, [`ZANNCASH [${cash}]`,`METODE LAIN`,`BATAL AJA`])
  });
  } else if (customer_kode.startsWith('ML')) {
 let axios = require('axios');
const url = `https://${global.APIcek}/api/mobile-legends2/?target=${customer_no}&api_key=${global.KEYcek}`
axios.get(url)
  .then(response => {
  console.log(response.data);
  let invoice = `
> ---------------------------------------
> |    CONFIRM ORDER            
> ---------------------------------------
> | Layanan : ${cek("product_name", m.sender)}     
> | Tujuan : ${cek("tujuan", m.sender)}              
> | NickName : ${response.data.data.nickname}     
> ---------------------------------------
> | *ID Trx :* ${cek("reff",m.sender)}
> | *Catatan :* ${cek("desc_prabayar",m.sender)}
> ---------------------------------------
> | *Harga :* ${formatmoney(jumlahHarga)}
> | *Diskon :* ${formatmoney(potonganHarga)}
> | *Total :* ${formatmoney(totalPembayaran)}
> ---------------------------------------`;

    if (cek("product_name", m.sender) == "") return reply(`Gagal, kode_sku *${customer_kode}* engga ada, pastikan udah bener ya`);
    AnanthaGanz.sendPoll(m.chat, invoice, [`ZANNCASH [${cash}]`,`METODE LAIN`,`BATAL AJA`])
  })
  .catch(error => {
    console.error(error.response.data);
    let invoice = `
> ---------------------------------------
> |    CONFIRM ORDER
> ---------------------------------------
> | Layanan : ${cek("product_name", m.sender)}
> | Tujuan : ${cek("tujuan", m.sender)}
> | NickName : ga ketemu, bro
> ---------------------------------------
> | *ID Trx :* ${cek("reff",m.sender)}
> | *Catatan :* ${cek("desc_prabayar",m.sender)}
> ---------------------------------------
> | *Harga :* ${formatmoney(jumlahHarga)}
> | *Diskon :* ${formatmoney(potonganHarga)}
> | *Total :* ${formatmoney(totalPembayaran)}
> ---------------------------------------`;
    if (cek("product_name", m.sender) == "") return reply(`Gagal, kode_sku *${customer_kode}* engga ada, pastikan udah bener ya`);
    AnanthaGanz.sendPoll(m.chat, invoice, [`ZANNCASH [${cash}]`,`METODE LAIN`,`BATAL AJA`])
  });
} else if (customer_kode.startsWith('F')) {
let axios = require('axios');
const url = `https://${global.APIcek}/api/free-fire/?target=${customer_no}&api_key=${global.KEYcek}`
axios.get(url)
  .then(response => {
  console.log(response.data);
  let invoice = `
> ---------------------------------------
> |    CONFIRM ORDER            
> ---------------------------------------
> | Layanan : ${cek("product_name", m.sender)}     
> | Tujuan : ${cek("tujuan", m.sender)}              
> | NickName : ${response.data.data.nickname}     
> ---------------------------------------
> | *ID Trx :* ${cek("reff",m.sender)}
> | *Catatan :* ${cek("desc_prabayar",m.sender)}
> ---------------------------------------
> | *Harga :* ${formatmoney(jumlahHarga)}
> | *Diskon :* ${formatmoney(potonganHarga)}
> | *Total :* ${formatmoney(totalPembayaran)}
> ---------------------------------------`;

    if (cek("product_name", m.sender) == "") return reply(`Gagal, kode_sku *${customer_kode}* engga ada, pastikan udah bener ya`);
    AnanthaGanz.sendPoll(m.chat, invoice, [`ZANNCASH [${cash}]`,`METODE LAIN`,`BATAL AJA`])
  })
  .catch(error => {
    console.error(error.response.data);
    let invoice = `
> ---------------------------------------
> |    CONFIRM ORDER
> ---------------------------------------
> | Layanan : ${cek("product_name", m.sender)}
> | Tujuan : ${cek("tujuan", m.sender)}
> | NickName : ga ketemu, bro
> ---------------------------------------
> | *ID Trx :* ${cek("reff",m.sender)}
> | *Catatan :* ${cek("desc_prabayar",m.sender)}
> ---------------------------------------
> | *Harga :* ${formatmoney(jumlahHarga)}
> | *Diskon :* ${formatmoney(potonganHarga)}
> | *Total :* ${formatmoney(totalPembayaran)}
> ---------------------------------------`;
    if (cek("product_name", m.sender) == "") return reply(`Gagal, kode_sku *${customer_kode}* engga ada, pastikan udah bener ya`);
    AnanthaGanz.sendPoll(m.chat, invoice, [`ZANNCASH [${cash}]`,`METODE LAIN`,`BATAL AJA`])
  });
} else if (/^(DN|D)/.test(customer_kode)) {
let axios = require('axios');
const url = `https://${global.APIcek}/api/dana-ewallet/?target=${customer_no}&api_key=${global.KEYcek}`
axios.get(url)
  .then(response => {
  console.log(response.data);
  let invoice = `
> ---------------------------------------
> |    CONFIRM ORDER            
> ---------------------------------------
> | Layanan : ${cek("product_name", m.sender)}     
> | Tujuan : ${cek("tujuan", m.sender)}              
> | NickName : ${response.data.data.nickname}     
> ---------------------------------------
> | *ID Trx :* ${cek("reff",m.sender)}
> | *Catatan :* ${cek("desc_prabayar",m.sender)}
> ---------------------------------------
> | *Harga :* ${formatmoney(jumlahHarga)}
> | *Diskon :* ${formatmoney(potonganHarga)}
> | *Total :* ${formatmoney(totalPembayaran)}
> ---------------------------------------`;

    if (cek("product_name", m.sender) == "") return reply(`Gagal, kode_sku *${customer_kode}* engga ada, pastikan udah bener ya`);
    AnanthaGanz.sendPoll(m.chat, invoice, [`ZANNCASH [${cash}]`,`METODE LAIN`,`BATAL AJA`])
  })
  .catch(error => {
    console.error(error.response.data);
    let invoice = `
> ---------------------------------------
> |    CONFIRM ORDER
> ---------------------------------------
> | Layanan : ${cek("product_name", m.sender)}
> | Tujuan : ${cek("tujuan", m.sender)}
> | NickName : ga ketemu, bro
> ---------------------------------------
> | *ID Trx :* ${cek("reff",m.sender)}
> | *Catatan :* ${cek("desc_prabayar",m.sender)}
> ---------------------------------------
> | *Harga :* ${formatmoney(jumlahHarga)}
> | *Diskon :* ${formatmoney(potonganHarga)}
> | *Total :* ${formatmoney(totalPembayaran)}
> ---------------------------------------`;
    if (cek("product_name", m.sender) == "") return reply(`Gagal, kode_sku *${customer_kode}* engga ada, pastikan udah bener ya`);
    AnanthaGanz.sendPoll(m.chat, invoice, [`ZANNCASH [${cash}]`,`METODE LAIN`,`BATAL AJA`])
  });
  } else if (customer_kode.startsWith('SPY')) {
let axios = require('axios');
const url = `https://${global.APIcek}/api/shopee-pay-ewallet/?target=${customer_no}&api_key=${global.KEYcek}`
axios.get(url)
  .then(response => {
  console.log(response.data);
  let invoice = `
> ---------------------------------------
> |    CONFIRM ORDER            
> ---------------------------------------
> | Layanan : ${cek("product_name", m.sender)}     
> | Tujuan : ${cek("tujuan", m.sender)}              
> | NickName : ${response.data.data.nickname}     
> ---------------------------------------
> | *ID Trx :* ${cek("reff",m.sender)}
> | *Catatan :* ${cek("desc_prabayar",m.sender)}
> ---------------------------------------
> | *Harga :* ${formatmoney(jumlahHarga)}
> | *Diskon :* ${formatmoney(potonganHarga)}
> | *Total :* ${formatmoney(totalPembayaran)}
> ---------------------------------------`;

    if (cek("product_name", m.sender) == "") return reply(`Gagal, kode_sku *${customer_kode}* engga ada, pastikan udah bener ya`);
    AnanthaGanz.sendPoll(m.chat, invoice, [`ZANNCASH [${cash}]`,`METODE LAIN`,`BATAL AJA`])
  })
  .catch(error => {
    console.error(error.response.data);
    let invoice = `
> ---------------------------------------
> |    CONFIRM ORDER
> ---------------------------------------
> | Layanan : ${cek("product_name", m.sender)}
> | Tujuan : ${cek("tujuan", m.sender)}
> | NickName : ga ketemu, bro
> ---------------------------------------
> | *ID Trx :* ${cek("reff",m.sender)}
> | *Catatan :* ${cek("desc_prabayar",m.sender)}
> ---------------------------------------
> | *Harga :* ${formatmoney(jumlahHarga)}
> | *Diskon :* ${formatmoney(potonganHarga)}
> | *Total :* ${formatmoney(totalPembayaran)}
> ---------------------------------------`;
    if (cek("product_name", m.sender) == "") return reply(`Gagal, kode_sku *${customer_kode}* engga ada, pastikan udah bener ya`);
    AnanthaGanz.sendPoll(m.chat, invoice, [`ZANNCASH [${cash}]`,`METODE LAIN`,`BATAL AJA`])
  });
} else if (/^(OVB|OV)/.test(customer_kode)) {
let axios = require('axios');
const url = `https://${global.APIcek}/api/ovo-ewallet/?target=${customer_no}&api_key=${global.KEYcek}`
axios.get(url)
  .then(response => {
  console.log(response.data);
  let invoice = `
> ---------------------------------------
> |    CONFIRM ORDER            
> ---------------------------------------
> | Layanan : ${cek("product_name", m.sender)}     
> | Tujuan : ${cek("tujuan", m.sender)}              
> | NickName : ${response.data.data.nickname}     
> ---------------------------------------
> | *ID Trx :* ${cek("reff",m.sender)}
> | *Catatan :* ${cek("desc_prabayar",m.sender)}
> ---------------------------------------
> | *Harga :* ${formatmoney(jumlahHarga)}
> | *Diskon :* ${formatmoney(potonganHarga)}
> | *Total :* ${formatmoney(totalPembayaran)}
> ---------------------------------------`;

    if (cek("product_name", m.sender) == "") return reply(`Gagal, kode_sku *${customer_kode}* engga ada, pastikan udah bener ya`);
    AnanthaGanz.sendPoll(m.chat, invoice, [`ZANNCASH [${cash}]`,`METODE LAIN`,`BATAL AJA`])
  })
  .catch(error => {
    console.error(error.response.data);
    let invoice = `
> ---------------------------------------
> |    CONFIRM ORDER
> ---------------------------------------
> | Layanan : ${cek("product_name", m.sender)}
> | Tujuan : ${cek("tujuan", m.sender)}
> | NickName : ga ketemu, bro
> ---------------------------------------
> | *ID Trx :* ${cek("reff",m.sender)}
> | *Catatan :* ${cek("desc_prabayar",m.sender)}
> ---------------------------------------
> | *Harga :* ${formatmoney(jumlahHarga)}
> | *Diskon :* ${formatmoney(potonganHarga)}
> | *Total :* ${formatmoney(totalPembayaran)}
> ---------------------------------------`;
    if (cek("product_name", m.sender) == "") return reply(`Gagal, kode_sku *${customer_kode}* engga ada, pastikan udah bener ya`);
    AnanthaGanz.sendPoll(m.chat, invoice, [`ZANNCASH [${cash}]`,`METODE LAIN`,`BATAL AJA`])
  });
} else if (customer_kode.startsWith('GP')) {
let axios = require('axios');
const url = `https://${global.APIcek}/api/gopay-ewallet/?target=${customer_no}&api_key=${global.KEYcek}`
axios.get(url)
  .then(response => {
  console.log(response.data);
  let invoice = `
> ---------------------------------------
> |    CONFIRM ORDER            
> ---------------------------------------
> | Layanan : ${cek("product_name", m.sender)}     
> | Tujuan : ${cek("tujuan", m.sender)}              
> | NickName : ${response.data.data.nickname}     
> ---------------------------------------
> | *ID Trx :* ${cek("reff",m.sender)}
> | *Catatan :* ${cek("desc_prabayar",m.sender)}
> ---------------------------------------
> | *Harga :* ${formatmoney(jumlahHarga)}
> | *Diskon :* ${formatmoney(potonganHarga)}
> | *Total :* ${formatmoney(totalPembayaran)}
> ---------------------------------------`;

    if (cek("product_name", m.sender) == "") return reply(`Gagal, kode_sku *${customer_kode}* engga ada, pastikan udah bener ya`);
    AnanthaGanz.sendPoll(m.chat, invoice, [`ZANNCASH [${cash}]`,`METODE LAIN`,`BATAL AJA`])
  })
  .catch(error => {
    console.error(error.response.data);
    let invoice = `
> ---------------------------------------
> |    CONFIRM ORDER
> ---------------------------------------
> | Layanan : ${cek("product_name", m.sender)}
> | Tujuan : ${cek("tujuan", m.sender)}
> | NickName : ga ketemu, bro
> ---------------------------------------
> | *ID Trx :* ${cek("reff",m.sender)}
> | *Catatan :* ${cek("desc_prabayar",m.sender)}
> ---------------------------------------
> | *Harga :* ${formatmoney(jumlahHarga)}
> | *Diskon :* ${formatmoney(potonganHarga)}
> | *Total :* ${formatmoney(totalPembayaran)}
> ---------------------------------------`;
    if (cek("product_name", m.sender) == "") return reply(`Gagal, kode_sku *${customer_kode}* engga ada, pastikan udah bener ya`);
    AnanthaGanz.sendPoll(m.chat, invoice, [`ZANNCASH [${cash}]`,`METODE LAIN`,`BATAL AJA`])
  });
  } else if (customer_kode.startsWith('LINK')) {
let axios = require('axios');
const url = `https://${global.APIcek}/api/link-aja-ewallet/?target=${customer_no}&api_key=${global.KEYcek}`
axios.get(url)
  .then(response => {
  console.log(response.data);
  let invoice = `
> ---------------------------------------
> |    CONFIRM ORDER            
> ---------------------------------------
> | Layanan : ${cek("product_name", m.sender)}     
> | Tujuan : ${cek("tujuan", m.sender)}              
> | NickName : ${response.data.data.nickname}     
> ---------------------------------------
> | *ID Trx :* ${cek("reff",m.sender)}
> | *Catatan :* ${cek("desc_prabayar",m.sender)}
> ---------------------------------------
> | *Harga :* ${formatmoney(jumlahHarga)}
> | *Diskon :* ${formatmoney(potonganHarga)}
> | *Total :* ${formatmoney(totalPembayaran)}
> ---------------------------------------`;

    if (cek("product_name", m.sender) == "") return reply(`Gagal, kode_sku *${customer_kode}* engga ada, pastikan udah bener ya`);
    AnanthaGanz.sendPoll(m.chat, invoice, [`ZANNCASH [${cash}]`,`METODE LAIN`,`BATAL AJA`])
  })
  .catch(error => {
    console.error(error.response.data);
    let invoice = `
> ---------------------------------------
> |    CONFIRM ORDER
> ---------------------------------------
> | Layanan : ${cek("product_name", m.sender)}
> | Tujuan : ${cek("tujuan", m.sender)}
> | NickName : ga ketemu, bro
> ---------------------------------------
> | *ID Trx :* ${cek("reff",m.sender)}
> | *Catatan :* ${cek("desc_prabayar",m.sender)}
> ---------------------------------------
> | *Harga :* ${formatmoney(jumlahHarga)}
> | *Diskon :* ${formatmoney(potonganHarga)}
> | *Total :* ${formatmoney(totalPembayaran)}
> ---------------------------------------`;
    if (cek("product_name", m.sender) == "") return reply(`Gagal, kode_sku *${customer_kode}* engga ada, pastikan udah bener ya`);
    AnanthaGanz.sendPoll(m.chat, invoice, [`ZANNCASH [${cash}]`,`METODE LAIN`,`BATAL AJA`])
  });
 } else if (customer_kode === customer_kode) {
  let invoice = `
> ---------------------------------------
> |    CONFIRM ORDER            
> ---------------------------------------
> | Layanan : ${cek("product_name", m.sender)} 
> | Tujuan : ${cek("tujuan", m.sender)}    
> ---------------------------------------
> | *ID Trx :* ${cek("reff",m.sender)}
> | *Note :* ${cek("desc_prabayar",m.sender)}
> ---------------------------------------
> | *Harga :* ${formatmoney(jumlahHarga)}
> | *Diskon :* ${formatmoney(potonganHarga)}
> | *Total :* ${formatmoney(totalPembayaran)}
> ---------------------------------------`;
setTimeout(() => {
sendInvPending(sender, jumlahHarga, potonganHarga, totalPembayaran);
}, 3000);
if(cek("product_name", m.sender) == "") return reply(`Eits, gagal nih, kode SKU *${customer_kode}* ga valid nih. Cek lagi ya, bro. ❌`);
AnanthaGanz.sendPoll(m.chat, invoice, [`ZANNCASH [${cash}]`,`METODE LAIN`,`BATAL AJA`])
} 
}
break
case 'metode': {
    if (cek("verfiyemail", m.sender) == true) return reply(`Oops, Silahkan Daftarkan Email anda\nContoh : .setemail xxxxx@gmail.com`);
    if (cek("cekVerify", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, `Oops, Silahkan Verifikasi Email : ${cek("email", m.sender)}`, ['Verifikasicode','Hubungi Admin']);
    if (cek("syarat", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, 'Oops, Kamu Belum Menyetujui Syarat Ketentuan dari kami. Mohon setujuin dulu, agar dapat mengakses fitur dari kami.', ['Saya Setuju','Syarat nya apa aja']);
    AnanthaGanz.sendPoll(m.chat, `Pilih dulu yuk metode pembayaran untuk invoice ini : ${cek("reff", m.sender)}`, ["EWALLETPAY","RETAILPAY","PULSAPAY"]);
}
break;
case 'ewalletpay': {
    if (cek("verfiyemail", m.sender) == true) return reply(`Oops, Silahkan Daftarkan Email anda\nContoh : .setemail xxxxx@gmail.com`);
    if (cek("cekVerify", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, `Oops, Silahkan Verifikasi Email : ${cek("email", m.sender)}`, ['Verifikasicode','Hubungi Admin']);
    if (cek("syarat", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, 'Oops, Kamu Belum Menyetujui Syarat Ketentuan dari kami. Mohon setujuin dulu, agar dapat mengakses fitur dari kami.', ['Saya Setuju','Syarat nya apa aja']);
    AnanthaGanz.sendPoll(m.chat, `Pilih lagi yuk metode pembayaran untuk invoice ini : ${cek("reff", m.sender)}`, ["QRISPAY","OVOPAY","DANAPAY","SHOPEEPAYPAY","LINKAJAPAY","GOPAYPAY"]);
}
break;
case 'pulsapay': {
    if (cek("verfiyemail", m.sender) == true) return reply(`Oops, Silahkan Daftarkan Email anda\nContoh : .setemail xxxxx@gmail.com`);
    if (cek("cekVerify", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, `Oops, Silahkan Verifikasi Email : ${cek("email", m.sender)}`, ['Verifikasicode','Hubungi Admin']);
    if (cek("syarat", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, 'Oops, Kamu Belum Menyetujui Syarat Ketentuan dari kami. Mohon setujuin dulu, agar dapat mengakses fitur dari kami.', ['Saya Setuju','Syarat nya apa aja']);
    AnanthaGanz.sendPoll(m.chat, `Pilih lagi yuk metode pembayaran untuk invoice ini : ${cek("reff", m.sender)}`, ["TELKOMSELPAY","THREEPAY","AXISPAY","XLPAY"]);
}
break;
case 'retailpay': {
    if (cek("verfiyemail", m.sender) == true) return reply(`Oops, Silahkan Daftarkan Email anda\nContoh : .setemail xxxxx@gmail.com`);
    if (cek("cekVerify", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, `Oops, Silahkan Verifikasi Email : ${cek("email", m.sender)}`, ['Verifikasicode','Hubungi Admin']);
    if (cek("syarat", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, 'Oops, Kamu Belum Menyetujui Syarat Ketentuan dari kami. Mohon setujuin dulu, agar dapat mengakses fitur dari kami.', ['Saya Setuju','Syarat nya apa aja']);
    AnanthaGanz.sendPoll(m.chat, `Pilih lagi yuk metode pembayaran untuk invoice ini : ${cek("reff", m.sender)}`, ["ALFAMARTPAY","INDOMARETPAY"]);
}
break;
case 'sgif':
case 'stikerin':
case 's':
case 'sticker':
case 'stiker': {
if(cek("syarat", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, 'Oops, Kamu Belum Menyetujui Syarat Ketentuan dari kami. Mohon setujuin dulu, agar dapat mengakses fitur dari kami.', ['Saya Setuju','Syarat nya apa aja']);
if(cek("verfiyemail", m.sender) == true) return reply(`Oops, Silahkan Daftarkan Email anda\nContoh : .setemail xxxxx@gmail.com`)
    if (!quoted) return reply(`Reply Foto/Video Dengan Caption ${prefix + command}\n\nDurasi Video Max 1-9 Detik`);
    const isImage = /image/.test(mime);
    const isVideo = /video/.test(mime);

    if (isImage || isVideo) {
        const maxDuration = isVideo ? 11 : 9;
        if ((quoted.msg || quoted).seconds > maxDuration) return reply(`Reply Foto/Video Dengan Caption ${prefix + command}\n\nDurasi Video Max 1-${maxDuration - 1} Detik`);

        const media = await quoted.download();
        const encmedia = isImage ? await AnanthaGanz.sendImageAsSticker(m.chat, media, m, { packname, author: dengan_nol }) : await AnanthaGanz.sendVideoAsSticker(m.chat, media, m, { packname, author: dengan_nol });
        await fs.unlinkSync(encmedia);
    } else {
        AnanthaGanz.sendMessage(from, { text: `Reply Foto/Video Dengan Caption ${prefix + command}\n\nDurasi Video Max 1-9 Detik`}, { quoted: m });
    }
    break;
}
         case 'tesst':{
         loading();
         }
         break
case 'cancel': {
    if (cek("syarat", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, 'Oops, Kamu Belum Menyetujui Syarat Ketentuan dari kami. Mohon setujuin dulu, agar dapat mengakses fitur dari kami.', ['Saya Setuju','Syarat nya apa aja']);
    if (cek("verfiyemail", m.sender) == true) return reply(`Oops, Silahkan Daftarkan Email anda\nContoh : .setemail xxxxx@gmail.com`)
    
    if (!fs.existsSync(`./SETTING/DB/TRANSACTION/Api/Deposit/${cek("deposit", m.sender)}.json`)) {
        return reply(`Waduh, kayaknya gak ada invoice yang lagi berlangsung nih.`);
    } else {
cancelPay();
m.reply(`Yaudah, invoice ${cek("deposit", m.sender)} udah dibatalin kok`);
    }
    break;
}

case 'batal': {
if(cek("syarat", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, 'Oops, Kamu Belum Menyetujui Syarat Ketentuan dari kami. Mohon setujuin dulu, agar dapat mengakses fitur dari kami.', ['Saya Setuju','Syarat nya apa aja']);
if(cek("verfiyemail", m.sender) == true) return reply(`Oops, Silahkan Daftarkan Email anda\nContoh : .setemail xxxxx@gmail.com`)
    if (cek("status", m.sender) === true) {
        return reply(`Oops! Sepertinya kamu belum memiliki pesanan. Ayo, buat pesanan sekarang!`);
    } else {
        setTimeout(() => {
            sett("status", m.sender, true);
            sett("product_name", m.sender, "");
            sett("price", m.sender, 0);
            sett("tujuan", m.sender, "");
            sett("desc", m.sender, 0);
            sett("desc_prabayar", m.sender, "");
            sett("reff", m.sender, "");
            sett("buyer_sku_code", m.sender, "");
            sett("layanan", m.sender, "");
        }, 1200);
        let batal = `Yaudah, invoice ${cek("reff", m.sender)} udah dibatalin kok`;
        m.reply(batal);
        sendExpTrx(sender)
    }
    break;
}
case 'bebasnominal':
if(cek("syarat", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, 'Oops, Kamu Belum Menyetujui Syarat Ketentuan dari kami. Mohon setujuin dulu, agar dapat mengakses fitur dari kami.', ['Saya Setuju','Syarat nya apa aja']);
if(cek("verfiyemail", m.sender) == true) return reply(`Oops, Silahkan Daftarkan Email anda\nContoh : .setemail xxxxx@gmail.com`)
  if(cek("level", m.sender) == "Basic") return reply(`Oops, Fitur Ini Khusus Untuk Akun Premium! Silahkan Upgrade akun anda`)
    if(cek("status", m.sender) == false) return AnanthaGanz.sendPoll(m.chat, `Oops, invoice ${cek("reff", m.sender)} masih tersedia!`, ['Batal Aja','Hubungi Admin']); 
    var axios = require('axios')
    const [sku_wallet, no_wallet, jumlah_wallet] = q.split("|");
    const minimal = 10000;
    const max = 500000;
    const potongan = 50;

    if (!sku_wallet || !no_wallet || !jumlah_wallet) {
        return reply(`*E-MONEY BEBAS NOMINAL*

Silakan gunakan dengan format :
*.bebasnominal sku_kode|no_wallet|nominal*

Contoh :
*.bebasnominal DNB|085174667722|20000*`);
    }

    const jumlah_payment = parseInt(jumlah_wallet);
    if (isNaN(jumlah_payment)) {
        return reply("Jumlah payment tidak valid.");
    }
    if (jumlah_payment < minimal) {
        return m.reply(`Jumlah minimal E-Wallet Bebas Nominal adalah ${formatmoney(minimal)}.`);
    }
    if (jumlah_payment > max) {
        return m.reply(`Jumlah maksimal E-Wallet Bebas Nominal adalah ${formatmoney(max)}.`);
    }

    const ref_wallet = koderef;
    let layanan_wallet = "";

    for (let i of JSON.parse(fs.readFileSync('./SETTING/DB/pasca.json'))) {
        if (i.buyer_sku_code == sku_wallet) {
            layanan_wallet = i.product_name;
            sett("desc", m.sender, layanan_wallet);
            break;
        }
    }

    const signature = crypto.createHash('md5')
        .update(digiuser + digiapi + ref_wallet)
        .digest('hex');

    var config = {
        method: 'POST',
        url: 'https://api.digiflazz.com/v1/transaction',
        data: {
            "commands": "inq-pasca",
            "username": String(digiuser),
            "buyer_sku_code": sku_wallet,
            "customer_no": no_wallet,
            "ref_id": ref_wallet,
            "amount": jumlah_payment,
            "sign": signature
        }
    };

    axios(config)
        .then(async response => {
            const uangg = response.data.data.selling_price !== undefined ? response.data.data.selling_price * 1 : 0;
            const admint = uangg - jumlah_payment * 1;
            const potonganAmount = potongan * 1;
            const totalHarga = uangg - potonganAmount;

            let bankCode;
            if (sku_wallet.startsWith('DNB')) bankCode = 'DANA';
            else if (sku_wallet.startsWith('OVB')) bankCode = 'OVO';
            else if (sku_wallet.startsWith('GPB')) bankCode = 'GOPAY';
            else if (sku_wallet.startsWith('SPB')) bankCode = 'SHOPEEPAY';

            if (bankCode) {
                const apiUrl = `https://${global.apiNick}/getEwalletAccount?bankCode=${bankCode}&accountNumber=${no_wallet}`;
                var config = { headers: { 'Content-Type': 'application/json' } };

                axios.get(apiUrl, config)
                    .then(async res => {
                        const responseData = res.data;
                        const accountname = responseData.data ? responseData.data.accountname : "tidak ditemukan";

                        const invoice = `
> ---------------------------------------
> |   DETAIL PESANAN                           
> ---------------------------------------
> | *Nama Pelanggan:* ${accountname}                  
> | *Id Pelanggan:* ${no_wallet}   
> | *Layanan:* ${layanan_wallet}           
> ---------------------------------------
> | *Catatan:* Topup Bebas Nominal 
> ---------------------------------------
> | *Tagihan :* ${formatmoney(jumlah_payment)}
> | *Admin :* ${formatmoney(admint)}
> | *Total :* ${formatmoney(uangg)}
> ---------------------------------------
> | *Potongan :* ${formatmoney(potonganAmount)}
> | *Total :* ${formatmoney(totalHarga)}
> ---------------------------------------
`;
                        AnanthaGanz.sendPoll(m.chat, invoice, ['Paybebasnominal', 'Batal']);
                        setTimeout(() => {
                            sett("price", m.sender, `${totalHarga}`)
                            sett("product_name", m.sender, `${jumlah_payment}`)
                            sett("status", m.sender, false)
                            sett("tujuan", m.sender, `${no_wallet}`)
                            sett("buyer_sku_code", m.sender, `${sku_wallet}`)
                            sett("desc", m.sender, `${layanan_wallet}`)
                            sett("reff", m.sender, `${ref_wallet}`)
                            
                        }, 3000);
                    })
                    .catch(error => console.error('Error:', error));
            } else {
                return reply("Nama tidak ditemukan");
            }
        })
        .catch(error => {
            if (error.response && error.response.data.data.message == "SKU tidak di temukan atau Non-Aktif") {
                setTimeout(() => {
                    AnanthaGanz.sendMessage(from, { text: `Gagal, periksa SKU KODE, pastikan sudah sesuai.` })
                }, 2000);
            }
        });
break;
case 'paybebasnominal': {
if(cek("syarat", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, 'Oops, Kamu Belum Menyetujui Syarat Ketentuan dari kami. Mohon setujuin dulu, agar dapat mengakses fitur dari kami.', ['Saya Setuju','Syarat nya apa aja']);
if(cek("verfiyemail", m.sender) == true) return reply(`Oops, Silahkan Daftarkan Email anda\nContoh : .setemail xxxxx@gmail.com`)
 if(cek("level", m.sender) == "Basic") return reply(`Oops, Fitur Ini Khusus Untuk Akun Premium! Silahkan Upgrade akun anda`)
    const crypto = require("crypto");
    const axios = require("axios");
    const ru = sender.split('@')[0];
    const total_wallet = cek("price", m.sender) * 1;
    if (cek("reff", m.sender) == "") 
        return reply(`Oops, kamu belum memiliki invoice! buat dulu yukk`)
    if (total_wallet > cek("saldo", m.sender)) 
        return reply(`Gagal, saldo kamu tidak cukup untuk proses pesanan.`);
    sett("-saldo", `${ru}@s.whatsapp.net`, total_wallet);    
    const ref_pasca = cek("reff", m.sender);
    const signature = crypto.createHash('md5')
        .update(digiuser + digiapi + ref_pasca)
        .digest('hex');

    const config = {
        method: 'POST',  
        url: 'https://api.digiflazz.com/v1/transaction',
        data: {
            "commands": "pay-pasca",
            "username": digiuser,
            "buyer_sku_code": cek("buyer_sku_code", m.sender),
            "customer_no": cek("tujuan", m.sender),
            "ref_id": ref_pasca,
            "amount": total_wallet,
            "sign": signature
        }
    };

    axios(config)
        .then(async res => {
        await loading()
                if (res.data.data.status == "Gagal") {
                    AnanthaGanz.sendMessage(`${owner}@s.whatsapp.net`, { 
                        text : `Gagal, ${res.data.data.message}`
                    });
                    AnanthaGanz.sendMessage(`${owner}@s.whatsapp.net`, {text:`*KESALAHAN SISTEM*

> Layanan : ${cek("desc", m.sender)}
> Message : ${response.data.data.message} 
> Customer : ${dengan_nol}`}, {Quoted: m})
                } else if (res.data.data.status == "Sukses") {
                    setTimeout(() => {
                    AnanthaGanz.sendPoll(cek("id", m.sender), `*RINCIAN PEMESANAN*

> Status : Success
> ID Trx : ${res.data.data.ref_id}
> Layanan : ${cek("desc", m.sender)}
> Tujuan : ${cek("tujuan", m.sender)}
> Harga : ${formatmoney(total_wallet)}
> Waktu : ${moment.tz(`Asia/${global.Wilayah}`).format('HH:mm:ss')} | ${moment.tz(`Asia/${global.Wilayah}`).format('DD/MM/YY')}
> SN/Token : ${res.data.data.sn}

Oke Sip, pesanan kamu udah berhasil! Makasih udah belanja di *${footer}*`, [`Bebasnominal ${cek("buyer_sku_code", m.sender)}|${cek("tujuan", m.sender)}|${cek("product_name", m.sender)} [Untuk Order Ulang]`,`Hubungi Admin`])
                    }, 3000);
                    let totalPendapatan = total_wallet - cek("productname", m.sender) * 1
                    let lastSaldo = res.data.data.buyer_last_saldo * 1
    let digiSaldo = `${formatmoney(lastSaldo)}` 
                    AnanthaGanz.sendMessage(`${owner}@s.whatsapp.net`, {
                text: `*LAPORAN PENDAPATAN*

> Customer : ${dengan_nol}
> Layanan : ${cek("desc", m.sender)}
> Tujuan : ${cek("tujuan", m.sender)}
> ID Trx : ${res.data.data.ref_id}
> Harga Pokok : ${formatmoney(total_wallet)}
> Harga Modal : ${formatmoney(cek("productname", m.sender))}
> Total Komisi : ${formatmoney(totalPendapatan)}
> Saldo Akhir Vendor : ${digiSaldo}
> Tanggal Penjualan : ${moment.tz(`Asia/${global.Wilayah}`).format('HH:mm:ss')} | ${moment.tz(`Asia/${global.Wilayah}`).format('DD/MM/YY')}`
            }, {Quoted: m});
                    let fileRekap = JSON.stringify(response.data.data);
      fs.writeFileSync(`./SETTING/DB/TRANSACTION/Api/Prabayar/Sukses/${koderefe}.json`, fileRekap);
                    const trxFilePath = './SETTING/DB/trxuser.json';
                    const trxUserData = JSON.parse(fs.readFileSync(trxFilePath, 'utf8'));
                    const newTransaction = {
                        buyer: m.sender,
                        status: res.data.data.message,
                        no_pembayaran: `INV${randomPay}`,
                        ref_id: res.data.data.ref_id,
                        jam: moment.tz('Asia/Makassar').format('HH:mm:ss'),
                        waktu: moment.tz('Asia/Makassar').format('DD/MM/YY'),
                        produk: `${cek("desc", m.sender)}`,
                        harga: total_wallet,
                        harga_modal: res.data.data.price,
                        tujuan: `${cek("tujuan", m.sender)}`,
                        invoice: res.data.data.sn,
                    };
                    trxUserData.push(newTransaction);
                    fs.writeFileSync(trxFilePath, JSON.stringify(trxUserData, null, 2), 'utf8');
                }
            
        })
        .catch(error => {
            if (error.response) {
                sett("+saldo", `${ru}@s.whatsapp.net`, total_wallet);
                AnanthaGanz.sendMessage(`${ru}@s.whatsapp.net`,{ 
                    text :`Gagal, ${String(error.response.data.data.message)}`
                });
            }      
        });

    setTimeout(() => {
        sett("product_name", m.sender, "");
        sett("price", m.sender, 0);
        sett("tujuan", m.sender, "");
        sett("deskripsi", m.sender, "");
        sett("reff", m.sender, "");
        sett("buyer_sku_code", m.sender, "");
        sett("status", m.sender, true);
    }, 15000);
} 
break
case 'zanncash': {
if (cek("verfiyemail", m.sender) == true) return reply(`Oops, Silahkan Daftarkan Email anda\nContoh : .setemail xxxxx@gmail.com`);
    if (cek("cekVerify", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, `Oops, Silahkan Verifikasi Email : ${cek("email", m.sender)}`, ['Verifikasicode','Hubungi Admin']);
if(cek("syarat", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, 'Oops, Kamu Belum Menyetujui Syarat Ketentuan dari kami. Mohon setujuin dulu, agar dapat mengakses fitur dari kami.', ['Saya Setuju','Syarat nya apa aja']);
if (cek("status", m.sender) == true) return reply(`Oops, kamu belum memiliki invoice! buat dulu yukk`)
let axios = require('axios');
let md5 = require('md5');
let kode_buyer = `${cek("buyer_sku_code", m.sender)}` 
for(let i of r){     
if(i.buyer_sku_code == kode_buyer){ 
if (i.price > cek("saldo", m.sender)) return reply(`Oops, saldo tidak mencukupi untuk melakukan transaksi`)
let tujuan = `${cek("tujuan", m.sender)}` 
let harga = `${cek("price", m.sender)}` * 1
sett("-saldo", m.sender, harga)
let referdf = `${cek("reff", m.sender)}` 
let product_name = `${cek("product_name", m.sender)}`
let user_no = `${tujuan}`
let harga_produk = `${harga}`
let kode_produk= `${kode_buyer}`
const signature = crypto.createHash('md5')
.update(digiuser + digiapi + referdf)
.digest('hex');

var config = {
    method: 'POST',
    url: `https://${global.digiFlazz}/v1/transaction`,
    headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json'
    },
    data: JSON.stringify({
        "username": digiuser,
        "buyer_sku_code": kode_buyer,
        "customer_no": user_no,
        "ref_id": referdf,
        "sign": signature
    })
};
  const parsedHarga = parseFloat(harga);  
axios(config)
.then(async res => {
AnanthaGanz.sendMessage(cek("id", m.sender), {text:`*RINCIAN PEMESANAN*

> Status : Process
> ID Trx : ${referdf}
> Layanan : ${product_name}
> Tujuan : ${user_no}
> Harga : ${formatmoney(parsedHarga)}
> Waktu : ${moment.tz(`Asia/${global.Wilayah}`).format('HH:mm:ss')} | ${moment.tz(`Asia/${global.Wilayah}`).format('DD/MM/YY')}

Weett, pesanan kamu sedang dalam proses`}, {Quoted: m})
let status = res.data.data.status;  
    console.log(status)        
while (status !== 'Sukses') {
await sleep(1000); 
const response = await axios(config);
status = response.data.data.status; 
if (status == "Gagal") {
sett("+saldo", cek("id", m.sender), harga) 
AnanthaGanz.sendPoll(cek("id", m.sender), `*RINCIAN PESANAN*

> Status : Failed
> ID Trx : ${referdf}
> Layanan : ${product_name}
> Tujuan : ${user_no}
> Harga : ${formatmoney(parsedHarga)}
> Waktu : ${moment.tz(`Asia/${global.Wilayah}`).format('HH:mm:ss')} | ${moment.tz(`Asia/${global.Wilayah}`).format('DD/MM/YY')}

yahh, pesanan kamu udah nggak bisa diproses. Mau Coba Lagi?`, [`Order ${cek("buyer_sku_code", m.sender)} ${cek("tujuan", m.sender)} [Untuk Order Ulang]`,`Hubungi Admin`])
let pesany = response.data.data.message
setTimeout(() => {
sendEmailTrxCancel(sender, pushname, referdf, product_name, user_no, parsedHarga, pesany);
}, 2500);
AnanthaGanz.sendMessage(`${owner}@s.whatsapp.net`, {text:`*KESALAHAN SISTEM*

> Layanan : ${product_name} 
> Message : ${response.data.data.message} 
> Customer : ${dengan_nol}`}, {Quoted: m})
setTimeout(() => {
sett("product_name", m.sender, "")
sett("price", m.sender, 0)
sett("tujuan", m.sender, "")  
sett("desc_prabayar", m.sender, "")  
sett("reff", m.sender, "") 
sett("buyer_sku_code", m.sender, "")  
sett("status", m.sender, true)
}, 8000);
              break;
              }
if (status === "Sukses") {
    AnanthaGanz.sendPoll(cek("id", m.sender), `*RINCIAN PEMESANAN*

> Status : Success
> ID Trx : ${referdf}
> Layanan : ${product_name}
> Tujuan : ${user_no}
> Harga : ${formatmoney(parsedHarga)}
> Waktu : ${moment.tz(`Asia/${global.Wilayah}`).format('HH:mm:ss')} | ${moment.tz(`Asia/${global.Wilayah}`).format('DD/MM/YY')}
> SN/Token : ${response.data.data.sn}

Oke Sip, pesanan kamu udah berhasil! Makasih udah belanja di *${footer}*`, [`Order ${cek("buyer_sku_code", m.sender)} ${cek("tujuan", m.sender)} [Untuk Order Ulang]`,`Print ${referdf}`])
let snket = response.data.data.sn
setTimeout(() => {
sendEmailTrxSuks(sender, pushname, snket, referdf, product_name, user_no, parsedHarga);
}, 2500);
const productDetails = d.find(i => i.product_name === product_name);
let fileRekap = JSON.stringify(response.data.data);
      fs.writeFileSync(`./SETTING/DB/TRANSACTION/Api/Prabayar/Sukses/${referdf}.json`, fileRekap);
if (productDetails) {
    const productInfo = `
Nama: ${productDetails.product_name}\nHarga: ${formatmoney(productDetails.price)}
`;
}
    const hargaModal = productDetails ? productDetails.price : null;
    const parsedModal = parseFloat(hargaModal);
    let lastSaldo = response.data.data.buyer_last_saldo * 1
    let digiSaldo = `${formatmoney(lastSaldo)}` 
    let totalPendapatan = parsedHarga - hargaModal * 1
AnanthaGanz.sendMessage(`${owner}@s.whatsapp.net`, {
                text: `*LAPORAN PENDAPATAN*

> Customer : ${dengan_nol}
> Layanan : ${product_name}
> Tujuan : ${user_no}
> ID Trx : ${referdf}
> Harga Pokok : ${formatmoney(parsedHarga)}
> Harga Modal : ${formatmoney(hargaModal)}
> Total Komisi : ${formatmoney(totalPendapatan)}
> Saldo Akhir Vendor : ${digiSaldo}
> Tanggal Penjualan : ${moment.tz(`Asia/${global.Wilayah}`).format('HH:mm:ss')} | ${moment.tz(`Asia/${global.Wilayah}`).format('DD/MM/YY')}`
            }, {Quoted: m});
   const trxFilePath = './SETTING/DB/trxuser.json';
    const trxUserData = JSON.parse(fs.readFileSync(trxFilePath, 'utf8'));
        const newTransaction = {
            buyer: m.sender,
            status: response.data.data.message,
            no_pembayaran: `Z26${randomPay}`,
            ref_id: response.data.data.ref_id,
            jam: moment.tz(`Asia/${global.Wilayah}`).format('HH:mm:ss'),
            waktu: moment.tz(`Asia/${global.Wilayah}`).format('DD/MM/YY'),
            produk: product_name,
            harga: parsedHarga,
            harga_modal: parsedModal,
            tujuan: user_no,
            invoice: response.data.data.sn,
        };
            trxUserData.push(newTransaction);
    fs.writeFileSync(trxFilePath, JSON.stringify(trxUserData, null, 2), 'utf8');
    setTimeout(() => {
sett("product_name", m.sender, "")
sett("price", m.sender, 0)
sett("tujuan", m.sender, "")  
sett("desc_prabayar", m.sender, "")  
sett("reff", m.sender, "") 
sett("buyer_sku_code", m.sender, "")  
sett("status", m.sender, true)
}, 8000);
}
          }})
          .catch(error => {
            if (error.response) {   
            
   sett("+saldo", cek("id", m.sender), harga) 
   console.error(error.response.data.data);
   let rekapGagal = JSON.stringify(error.response.data.data);
      fs.writeFileSync(`./SETTING/DB/TRANSACTION/Api/Prabayar/Gagal/${koderefe}.json`, rekapGagal);
AnanthaGanz.sendPoll(cek("id", m.sender), `*RINCIAN PESANAN*

> Status : Failed
> ID Trx : ${referdf}
> Layanan : ${product_name}
> Tujuan : ${user_no}
> Harga : ${formatmoney(parsedHarga)}
> Waktu : ${moment.tz(`Asia/${global.Wilayah}`).format('HH:mm:ss')} | ${moment.tz(`Asia/${global.Wilayah}`).format('DD/MM/YY')}

yahh, pesanan kamu udah nggak bisa diproses. Mau Coba Lagi?`, [`Order ${cek("buyer_sku_code", m.sender)} ${cek("tujuan", m.sender)} [Untuk Order Ulang]`,`Hubungi Admin`])
let pesanyu = error.response.data.data.message
setTimeout(() => {
sendEmailTrxCancele(sender, pushname, referdf, product_name, user_no, parsedHarga, pesanyu);
}, 2500);
              AnanthaGanz.sendMessage(`${owner}@s.whatsapp.net`, {text:`*KESALAHAN SISTEM*

> Layanan : ${product_name} 
> Message : ${error.response.data.data.message} 
> Customer : ${dengan_nol}`}, {Quoted: m})
setTimeout(() => {
sett("product_name", m.sender, "")
sett("price", m.sender, 0)
sett("tujuan", m.sender, "")  
sett("desc_prabayar", m.sender, "")  
sett("reff", m.sender, "") 
sett("buyer_sku_code", m.sender, "")  
sett("status", m.sender, true)
}, 8000);
            }  
   });
} }
break;
}
case 'qrispay': {
if (cek("verfiyemail", m.sender) == true) return reply(`Oops, Silahkan Daftarkan Email anda\nContoh : .setemail xxxxx@gmail.com`);
    if (cek("cekVerify", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, `Oops, Silahkan Verifikasi Email : ${cek("email", m.sender)}`, ['Verifikasicode','Hubungi Admin']);
    if(cek("syarat", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, 'Oops, Kamu Belum Menyetujui Syarat Ketentuan dari kami. Mohon setujuin dulu, agar dapat mengakses fitur dari kami.', ['Saya Setuju','Syarat nya apa aja']);
    if (cek("status", m.sender) == true) return reply(`Oops, kamu belum memiliki invoice! buat dulu yukk`);
    if(fs.existsSync(`./SETTING/DB/TRANSACTION/Api/Deposit/${cek("deposit", m.sender)}.json`)) return AnanthaGanz.sendPoll(m.chat, `Oops, Kamu Sedang Memiliki Invoice ${cek("deposit", m.sender)}, apakah kamu ingin cancel?`, ['Cancel Aja','Hubungi Admin']);
let user_payment_mount = `${cek("price", m.sender)}` * 1;
if (user_payment_mount < 100) return m.reply(`Minimun Payment Qris adalah Rp. 100`)
if (user_payment_mount > 10000000) return m.reply(`Maximal Payment Qris adalah Rp. 10.000.000`)
    let FormData = require('form-data');
    let axios = require('axios');
    let md5 = require('md5');
    let kode_buyer = `${cek("buyer_sku_code", m.sender)}`;

    for(let i of r) {     
        if(i.buyer_sku_code == kode_buyer) { 
            let tujuan = `${cek("tujuan", m.sender)}` ;
            let harga = user_payment_mount * 1
            let referdf = `${cek("reff", m.sender)}`;
            let product_name = `${cek("product_name", m.sender)}`;
            let user_no = `${tujuan}`;
            let harga_produk = `${harga}`;
            let kode_produk= `${kode_buyer}`;

            async function makePayment() {
                try {
                    let keynya = global.key;
                    let kodeunick = koderefe
                    let paymetcod = '17';
                    let aomut = Math.round(harga_produk);
                    let exp = 1800;
                    let create = keynya + kodeunick + paymetcod + aomut + exp + 'NewTransaction';
                    let signature = md5(create);
                    
                    // Membuat data form untuk permintaan pembayaran
                    var paymentData = new FormData();
                    paymentData.append('key', keynya);
                    paymentData.append('request', 'new');
                    paymentData.append('merchant_id', '71');
                    paymentData.append('unique_code', kodeunick);
                    paymentData.append('service', paymetcod);
                    paymentData.append('amount', aomut);
                    paymentData.append('note', `PAY ORDER ID ${referdf}`);
                    paymentData.append('valid_time', exp);
                    paymentData.append('customer_email', cek("email", m.sender));
                    paymentData.append('type_fee', '1');
                    paymentData.append('signature', signature); // Menggunakan signature yang telah dihitung

                    // Konfigurasi untuk permintaan pembayaran
                    var paymentConfig = {
                        method: 'post',
                        url: 'https://paydisini.co.id/api/',
                        headers: { 
                            ...paymentData.getHeaders()
                        },
                        data: paymentData
                    };

                    // Mengirim permintaan pembayaran
                    let paymentResponse = await axios(paymentConfig);
                    let paymentDataResponse = paymentResponse.data.data;
                  let obj = { id: m.sender, ref: `${paymentDataResponse.unique_code}`, method : `${paymentDataResponse.service_name}`, diterima: `${paymentDataResponse.balance}`, total: `${paymentDataResponse.amount}`, fee: `${paymentDataResponse.fee}`, url: `${paymentDataResponse.checkout_url}` }
          sett("deposit", m.sender, `${paymentDataResponse.unique_code}`)
fs.writeFileSync(`./SETTING/DB/TRANSACTION/Api/Deposit/${cek("deposit", m.sender)}.json`, JSON.stringify(obj))
                    let ccapt = ` CHECK OUT YOUR ORDER \n\n> Metode : ${paymentDataResponse.service_name}\n> Referensi : ${paymentDataResponse.unique_code}\n> Berlaku : 30 Menit\n> Tagihan : ${formatmoney(paymentDataResponse.balance)}\n> Fee : ${formatmoney(paymentDataResponse.fee)}\n> Total Bayar : ${formatmoney(paymentDataResponse.amount)}\n> Catatan : Pembayaran Order ${referdf}|${product_name}\n\nSilahkan Lakukan Pembayaran Tepat Waktu`;
                    AnanthaGanz.sendMessage(m.chat, { image: { url: `${paymentDataResponse.qrcode_url}` }, caption: ccapt });
                    setTimeout(() => {
const deppo = JSON.parse(fs.readFileSync(`./SETTING/DB/TRANSACTION/Api/Deposit/${cek("deposit", m.sender)}.json`))
               let method = `${checkIdDepo(m.sender, deppo) ? checkIdDepo(m.sender, deppo) : deppo.method}`
              let member = `${checkIdDepo(m.sender, deppo) ? checkIdDepo(m.sender, deppo) : deppo.id}`
                let price_sender = `${checkIdDepo(m.sender, deppo) ? checkIdDepo(m.sender, deppo) : deppo.diterima}` * 1
               let fee_sender = `${checkIdDepo(m.sender, deppo) ? checkIdDepo(m.sender, deppo) : deppo.fee}` * 1
               let ref_sender = `${checkIdDepo(m.sender, deppo) ? checkIdDepo(m.sender, deppo) : deppo.ref}` 
               let total_sender = `${checkIdDepo(m.sender, deppo) ? checkIdDepo(m.sender, deppo) : deppo.total}` * 1
               let url = `${checkIdDepo(m.sender, deppo) ? checkIdDepo(m.sender, deppo) : deppo.url}`
               sendEmailPending(sender, pushname, ref_sender, method, price_sender, fee_sender, total_sender, url);
               }, 5000);
                    let unick = paymentDataResponse.unique_code;

                    // Memantau status pembayaran
                    let dataStatus = paymentDataResponse.status;
                    const startTime = new Date().getTime();
                    while (dataStatus !== "Success") {
                        await sleep(1000);
                        let create3 = keynya + unick + 'StatusTransaction';
                        let signature3 = md5(create3);
                        var checkStatusData = new FormData();
                        checkStatusData.append('key', keynya);
                        checkStatusData.append('request', 'status');
                        checkStatusData.append('unique_code', unick);
                        checkStatusData.append('signature', signature3); 
                        // Konfigurasi untuk memeriksa status pembayaran
                        var checkStatusConfig = {
                            method: 'post',
                            url: 'https://paydisini.co.id/api/',
                            headers: { 
                                ...checkStatusData.getHeaders()
                            },
                            data: checkStatusData
                        };
                        // Mengirim permintaan untuk memeriksa status pembayaran
                        let statusResponse = await axios(checkStatusConfig);
                        let statusDataResponse = statusResponse.data.data;
                        dataStatus = statusDataResponse.status;
                        console.log(dataStatus);
                        // Memeriksa waktu timeout
                        const currentTime = new Date().getTime();
                        const elapsedTime = (currentTime - startTime) / (1000 * 60 * 30);
                        if (elapsedTime >= 1) {
                            m.reply(`Upss, tiket ${cek("deposit", m.sender)} udah gak berlaku nih. Yuk, buat yang baru!`);
              cancelPay();
                            break;
                        }
                        // Jika pembayaran berhasil
                        if (dataStatus === "Success") {
                        const deppo = JSON.parse(fs.readFileSync(`./SETTING/DB/TRANSACTION/Api/Deposit/${cek("deposit", m.sender)}.json`))
               let method = `${checkIdDepo(m.sender, deppo) ? checkIdDepo(m.sender, deppo) : deppo.method}`
              let member = `${checkIdDepo(m.sender, deppo) ? checkIdDepo(m.sender, deppo) : deppo.id}`
                let price_sender = `${checkIdDepo(m.sender, deppo) ? checkIdDepo(m.sender, deppo) : deppo.diterima}` * 1
               let fee_sender = `${checkIdDepo(m.sender, deppo) ? checkIdDepo(m.sender, deppo) : deppo.fee}` * 1
               let ref_sender = `${checkIdDepo(m.sender, deppo) ? checkIdDepo(m.sender, deppo) : deppo.ref}` 
               let total_sender = `${checkIdDepo(m.sender, deppo) ? checkIdDepo(m.sender, deppo) : deppo.total}` * 1
               
const signature = crypto.createHash('md5')
.update(digiuser + digiapi + referdf)
.digest('hex');

var config = {
    method: 'POST',
    url: `https://${global.digiFlazz}/v1/transaction`,
    headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json'
    },
    data: JSON.stringify({
        "username": digiuser,
        "buyer_sku_code": kode_buyer,
        "customer_no": user_no,
        "ref_id": referdf,
        "sign": signature
    })
};
  const parsedHarga = parseFloat(harga);  
axios(config)
.then(async res => {
AnanthaGanz.sendMessage(cek("id", m.sender), {text:`*RINCIAN PEMESANAN*

> Status : Process
> ID Trx : ${referdf}
> Layanan : ${product_name}
> Tujuan : ${user_no}
> Harga : ${formatmoney(parsedHarga)}
> Waktu : ${moment.tz(`Asia/${global.Wilayah}`).format('HH:mm:ss')} | ${moment.tz(`Asia/${global.Wilayah}`).format('DD/MM/YY')}

Weett, pesanan kamu sedang dalam proses`}, {Quoted: m})
let status = res.data.data.status;  
    console.log(status)        
while (status !== 'Sukses') {
await sleep(1000); 
const response = await axios(config);
status = response.data.data.status; 
if (status == "Gagal") {
sett("+saldo", cek("id", m.sender), harga) 
AnanthaGanz.sendPoll(cek("id", m.sender), `*RINCIAN PESANAN*

> Status : Failed
> ID Trx : ${referdf}
> Layanan : ${product_name}
> Tujuan : ${user_no}
> Harga : ${formatmoney(parsedHarga)}
> Waktu : ${moment.tz(`Asia/${global.Wilayah}`).format('HH:mm:ss')} | ${moment.tz(`Asia/${global.Wilayah}`).format('DD/MM/YY')}

yahh, pesanan kamu udah nggak bisa diproses. Mau Coba Lagi?`, [`Order ${cek("buyer_sku_code", m.sender)} ${cek("tujuan", m.sender)} [Untuk Order Ulang]`,`Hubungi Admin`])
let pesany = response.data.data.message
setTimeout(() => {
sendEmailTrxCancel(sender, pushname, referdf, product_name, user_no, parsedHarga, pesany);
}, 2500);
AnanthaGanz.sendMessage(`${owner}@s.whatsapp.net`, {text:`*KESALAHAN SISTEM*

> Layanan : ${product_name} 
> Message : ${response.data.data.message} 
> Customer : ${dengan_nol}`}, {Quoted: m})
setTimeout(() => {
sett("product_name", m.sender, "")
sett("price", m.sender, 0)
sett("tujuan", m.sender, "")  
sett("desc_prabayar", m.sender, "")  
sett("reff", m.sender, "") 
sett("buyer_sku_code", m.sender, "")  
sett("status", m.sender, true)
}, 8000);
              break;
              }
if (status === "Sukses") {
    AnanthaGanz.sendPoll(cek("id", m.sender), `*RINCIAN PEMESANAN*

> Status : Success
> ID Trx : ${referdf}
> Layanan : ${product_name}
> Tujuan : ${user_no}
> Harga : ${formatmoney(parsedHarga)}
> Waktu : ${moment.tz(`Asia/${global.Wilayah}`).format('HH:mm:ss')} | ${moment.tz(`Asia/${global.Wilayah}`).format('DD/MM/YY')}
> SN/Token : ${response.data.data.sn}

Oke Sip, pesanan kamu udah berhasil! Makasih udah belanja di *${footer}*`, [`Order ${cek("buyer_sku_code", m.sender)} ${cek("tujuan", m.sender)} [Untuk Order Ulang]`,`Print ${referdf}`])
let snket = response.data.data.sn
setTimeout(() => {
sendEmailTrxSuks(sender, pushname, snket, referdf, product_name, user_no, parsedHarga);
}, 2500);
const productDetails = d.find(i => i.product_name === product_name);
let fileRekap = JSON.stringify(response.data.data);
      fs.writeFileSync(`./SETTING/DB/TRANSACTION/Api/Prabayar/Sukses/${referdf}.json`, fileRekap);
if (productDetails) {
    const productInfo = `
Nama: ${productDetails.product_name}\nHarga: ${formatmoney(productDetails.price)}
`;
}
    const hargaModal = productDetails ? productDetails.price : null;
    const parsedModal = parseFloat(hargaModal);
    let lastSaldo = response.data.data.buyer_last_saldo * 1
    let digiSaldo = `${formatmoney(lastSaldo)}` 
    let totalPendapatan = parsedHarga - hargaModal * 1
AnanthaGanz.sendMessage(`${owner}@s.whatsapp.net`, {
                text: `*LAPORAN PENDAPATAN*

> Customer : ${dengan_nol}
> Layanan : ${product_name}
> Tujuan : ${user_no}
> ID Trx : ${referdf}
> Harga Pokok : ${formatmoney(parsedHarga)}
> Harga Modal : ${formatmoney(hargaModal)}
> Total Komisi : ${formatmoney(totalPendapatan)}
> Saldo Akhir Vendor : ${digiSaldo}
> Tanggal Penjualan : ${moment.tz(`Asia/${global.Wilayah}`).format('HH:mm:ss')} | ${moment.tz(`Asia/${global.Wilayah}`).format('DD/MM/YY')}`
            }, {Quoted: m});
   const trxFilePath = './SETTING/DB/trxuser.json';
    const trxUserData = JSON.parse(fs.readFileSync(trxFilePath, 'utf8'));
        const newTransaction = {
            buyer: m.sender,
            status: response.data.data.message,
            no_pembayaran: `Z26${randomPay}`,
            ref_id: response.data.data.ref_id,
            jam: moment.tz(`Asia/${global.Wilayah}`).format('HH:mm:ss'),
            waktu: moment.tz(`Asia/${global.Wilayah}`).format('DD/MM/YY'),
            produk: product_name,
            harga: parsedHarga,
            harga_modal: parsedModal,
            tujuan: user_no,
            invoice: response.data.data.sn,
        };
            trxUserData.push(newTransaction);
    fs.writeFileSync(trxFilePath, JSON.stringify(trxUserData, null, 2), 'utf8');
    setTimeout(() => {
sett("product_name", m.sender, "")
sett("price", m.sender, 0)
sett("tujuan", m.sender, "")  
sett("desc_prabayar", m.sender, "")  
sett("reff", m.sender, "") 
sett("buyer_sku_code", m.sender, "")  
sett("status", m.sender, true)
}, 8000);
}
          }})
          .catch(error => {
            if (error.response) {   
            
   sett("+saldo", cek("id", m.sender), harga) 
   console.error(error.response.data.data);
   let rekapGagal = JSON.stringify(error.response.data.data);
      fs.writeFileSync(`./SETTING/DB/TRANSACTION/Api/Prabayar/Gagal/${koderefe}.json`, rekapGagal);
AnanthaGanz.sendPoll(cek("id", m.sender), `*RINCIAN PESANAN*

> Status : Failed
> ID Trx : ${referdf}
> Layanan : ${product_name}
> Tujuan : ${user_no}
> Harga : ${formatmoney(parsedHarga)}
> Waktu : ${moment.tz(`Asia/${global.Wilayah}`).format('HH:mm:ss')} | ${moment.tz(`Asia/${global.Wilayah}`).format('DD/MM/YY')}

yahh, pesanan kamu udah nggak bisa diproses. Mau Coba Lagi?`, [`Order ${cek("buyer_sku_code", m.sender)} ${cek("tujuan", m.sender)} [Untuk Order Ulang]`,`Hubungi Admin`])
let pesanyu = error.response.data.data.message
setTimeout(() => {
sendEmailTrxCancele(sender, pushname, referdf, product_name, user_no, parsedHarga, pesanyu);
}, 2500);
              AnanthaGanz.sendMessage(`${owner}@s.whatsapp.net`, {text:`*KESALAHAN SISTEM*

> Layanan : ${product_name} 
> Message : ${error.response.data.data.message} 
> Customer : ${dengan_nol}`}, {Quoted: m})
setTimeout(() => {
sett("product_name", m.sender, "")
sett("price", m.sender, 0)
sett("tujuan", m.sender, "")  
sett("desc_prabayar", m.sender, "")  
sett("reff", m.sender, "") 
sett("buyer_sku_code", m.sender, "")  
sett("status", m.sender, true)
}, 8000);
            }  
   });
   setTimeout(() => {
                fs.unlinkSync(`./SETTING/DB/TRANSACTION/Api/Deposit/${cek("deposit", m.sender)}.json`);
                }, 4000);
                setTimeout(() => {
    sett("deposit", m.sender, "")
                }, 6000);
                 } else if (dataStatus === "Canceled") {
               console.log(`Berhasil! Ref ${cek("deposit", m.sender)} Dihapus`)
                        }
                    }
                } catch (error) {
                    console.log(error);
                    
                }
            }

            makePayment();
} }
break;

}
case 'axispay':
case 'xlpay':
case 'threepay':
case 'telkomselpay':
case 'gopaypay':
case 'linkajapay':
case 'ovopay':
case 'shopeepaypay':
case 'danapay': {
let send = `${sender.split('@')[0]}`
  let axios = require('axios');
  let md5 = require('md5');
  let ref_id = koderefe
  let endPoint = 'https://api.tokopay.id/v1/order' // SET ENDPOINT
if (cek("verfiyemail", m.sender) == true) return reply(`Oops, Silahkan Daftarkan Email anda\nContoh : .setemail xxxxx@gmail.com`);
    if (cek("cekVerify", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, `Oops, Silahkan Verifikasi Email : ${cek("email", m.sender)}`, ['Verifikasicode','Hubungi Admin']);
    if(cek("syarat", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, 'Oops, Kamu Belum Menyetujui Syarat Ketentuan dari kami. Mohon setujuin dulu, agar dapat mengakses fitur dari kami.', ['Saya Setuju','Syarat nya apa aja']);
    if (cek("status", m.sender) == true) return reply(`Oops, kamu belum memiliki invoice! buat dulu yukk`);
    if(fs.existsSync(`./SETTING/DB/TRANSACTION/Api/Deposit/${cek("deposit", m.sender)}.json`)) return AnanthaGanz.sendPoll(m.chat, `Oops, Kamu Sedang Memiliki Invoice ${cek("deposit", m.sender)}, apakah kamu ingin cancel?`, ['Cancel Aja','Hubungi Admin']);
   let user_payment_mount = `${cek("price", m.sender)}` * 1;
let kode_buyer = `${cek("buyer_sku_code", m.sender)}`;
for(let i of r) {     
        if(i.buyer_sku_code == kode_buyer) { 
            let tujuan = `${cek("tujuan", m.sender)}` ;
            let harga = Math.round(user_payment_mount);
            let referdf = `${cek("reff", m.sender)}`;
            let product_name = `${cek("product_name", m.sender)}`;
            let user_no = `${tujuan}`;
            let harga_produk = `${harga}`;
            let kode_produk= `${kode_buyer}`;
         
if (command === 'danapay') {
if (harga < 99) return m.reply(`Minimun Payment ${command} adalah Rp. 100`)
  if (harga > 20000000) return m.reply(`Maximal Payment ${command} adalah Rp. 20.000.000`);
    metode = 'DANA_REALTIME'; 
} else if (command === 'telkomselpay') {
 if (harga < 5000) return m.reply(`Minimun Payment ${command} adalah Rp. 5.000`)
  if (harga > 1000000) return m.reply(`Maximal Payment ${command} adalah Rp. 1.000.000`);
    metode = 'TELKOMSEL'; 
    } else if (command === 'threepay') {
 if (harga < 1000) return m.reply(`Minimun Payment ${command} adalah Rp. 1.000`)
  if (harga > 200000) return m.reply(`Maximal Payment ${command} adalah Rp. 200.000`);
    metode = 'TRI'; 
        } else if (command === 'axispay') {
 if (harga < 2000) return m.reply(`Minimun Payment ${command} adalah Rp. 2.000`)
  if (harga > 2000000) return m.reply(`Maximal Payment ${command} adalah Rp. 2.000.000`);
    metode = 'AXIS'; 
        } else if (command === 'xlpay') {
 if (harga < 2000) return m.reply(`Minimun Payment ${command} adalah Rp. 2.000`)
  if (harga > 2000000) return m.reply(`Maximal Payment ${command} adalah Rp. 2.000.000`);
    metode = 'XL'; 
} else if (command === 'shopeepaypay') {
if (harga < 99) return m.reply(`Minimun Payment ${command} adalah Rp. 100`)
    if (harga > 2000000) return m.reply(`Maximal Payment ${command} adalah Rp. 2.000.000`);
    metode = 'SHOPEEPAY_REALTIME';
    } else if (command === 'linkajapay') {
if (harga < 99) return m.reply(`Minimun Payment ${command} adalah Rp. 100`)
    if (harga > 2000000) return m.reply(`Maximal Payment ${command} adalah Rp. 2.000.000`);
    metode = 'LINKAJA';
        } else if (command === 'gopaypay') {
if (harga < 99) return m.reply(`Minimun Payment ${command} adalah Rp. 100`)
    if (harga > 2000000) return m.reply(`Maximal Payment ${command} adalah Rp. 2.000.000`);
    metode = 'GOPAY';
} else if (command === 'ovopay') {
if (harga < 99) return m.reply(`Minimun Payment ${command} adalah Rp. 100`)
    if (harga > 10000000) return m.reply(`Maximal Payment ${command} adalah Rp. 10.000.000`);
    metode = 'OVOPUSH'; 
}
let merchantid = global.merchant_id
let secret = global.secret_key
let create_md5 = `${merchantid}:${secret}:${ref_id}`;
let signature = md5(create_md5);
var config1 = {
method: 'POST',
headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
 "merchant_id": `${merchantid}`,
 "kode_channel": `${metode}`,
 "reff_id": `${ref_id}`,
 "amount": `${harga}`,
 "customer_name": `${pushname}`,
 "customer_email":`${cek("email", m.sender)}`,
 "customer_phone":`${dengan_nol}`,
 "redirect_url":"https://wa.me/6285174667722",
 "expired_ts":0, //default 0
 "signature": signature,
 "items":[{
         "product_code": `${referdf}`,
         "name":`${product_name}`,
         "price":`${harga}`,
         "product_url":"https://wa.me/6285174667722",
         "image_url":"https://telegra.ph/file/92e8994e5996b0a87fec8.jpg"
     }]
}),
}; 
fetch(endPoint, config1)
 .then(async (response) => {
     const data = await response.json();
       if (!data || !data.data || typeof data.data.total_bayar === 'undefined') {
            reply(`Oops, ${data.error_msg}`)
            console.error(data.error_msg);
            return;
        }
    const fee_users = `${data.data.total_bayar - data.data.total_diterima}` * 1
          let obj = { id: m.sender, ref: `${ref_id}`, method : `${metode}`, diterima: `${data.data.total_diterima}`, total: `${data.data.total_bayar}`, fee: `${fee_users}`, url: `${data.data.pay_url}` }
          sett("deposit", m.sender, `${ref_id}`)
fs.writeFileSync(`./SETTING/DB/TRANSACTION/Api/Deposit/${cek("deposit", m.sender)}.json`, JSON.stringify(obj))
let ccapt = ` CHECK OUT YOUR ORDER \n\n> Metode : ${metode}\n> Referensi : ${ref_id}\n> Berlaku : 30 Menit\n> Tagihan : ${formatmoney(data.data.total_diterima)}\n> Fee : ${formatmoney(fee_users)}\n> Total Bayar : ${formatmoney(data.data.total_bayar)}\n> Catatan : Pembayaran Order ${referdf}|${product_name}\n\nSilahkan Lakukan Pembayaran Tepat Waktu`;
    

AnanthaGanz.sendPoll(m.chat, ccapt, ['Bayar Sekarang','Cancel Pembayaran']);
setTimeout(() => {
const deppo = JSON.parse(fs.readFileSync(`./SETTING/DB/TRANSACTION/Api/Deposit/${cek("deposit", m.sender)}.json`))
               let method = `${checkIdDepo(m.sender, deppo) ? checkIdDepo(m.sender, deppo) : deppo.method}`
              let member = `${checkIdDepo(m.sender, deppo) ? checkIdDepo(m.sender, deppo) : deppo.id}`
                let price_sender = `${checkIdDepo(m.sender, deppo) ? checkIdDepo(m.sender, deppo) : deppo.diterima}` * 1
               let fee_sender = `${checkIdDepo(m.sender, deppo) ? checkIdDepo(m.sender, deppo) : deppo.fee}` * 1
               let ref_sender = `${checkIdDepo(m.sender, deppo) ? checkIdDepo(m.sender, deppo) : deppo.ref}` 
               let total_sender = `${checkIdDepo(m.sender, deppo) ? checkIdDepo(m.sender, deppo) : deppo.total}` * 1
               let url = `${checkIdDepo(m.sender, deppo) ? checkIdDepo(m.sender, deppo) : deppo.url}`
               sendEmailPending(sender, pushname, ref_sender, method, price_sender, fee_sender, total_sender, url);
               }, 2500);
              let dataStatus = data.data.status;
              const startTime = new Date().getTime();
              while (dataStatus !== "Success") {
              await sleep(1000);
              let zann = await fetch(endPoint, config1);
              let dataJson = await zann.json();
              let dataStatus = dataJson.data.status;
              console.log(dataStatus);
              const currentTime = new Date().getTime();
              const elapsedTime = (currentTime - startTime) / (1000 * 60 * 30);
                        if (elapsedTime >= 1) {
              m.reply(`Aduh, tiket ${cek("deposit", m.sender)} udah gak bisa dipake lagi nih. Yuk, coba lagi lain waktu! 😕`);
              try {
                fs.unlinkSync(`./SETTING/DB/TRANSACTION/Api/Deposit/${cek("deposit", m.sender)}.json`);
                  sett("deposit", m.sender, "")
                   } catch (error) {
        console.error("Gagal");
        }
                break;
            }
            if (dataStatus === "Success") {
            try {
            const deppo = JSON.parse(fs.readFileSync(`./SETTING/DB/TRANSACTION/Api/Deposit/${cek("deposit", m.sender)}.json`))
               let method = `${checkIdDepo(m.sender, deppo) ? checkIdDepo(m.sender, deppo) : deppo.method}`
              let member = `${checkIdDepo(m.sender, deppo) ? checkIdDepo(m.sender, deppo) : deppo.id}`
                let price_sender = `${checkIdDepo(m.sender, deppo) ? checkIdDepo(m.sender, deppo) : deppo.diterima}` * 1
               let fee_sender = `${checkIdDepo(m.sender, deppo) ? checkIdDepo(m.sender, deppo) : deppo.fee}` * 1
               let ref_sender = `${checkIdDepo(m.sender, deppo) ? checkIdDepo(m.sender, deppo) : deppo.ref}` 
               let total_sender = `${checkIdDepo(m.sender, deppo) ? checkIdDepo(m.sender, deppo) : deppo.total}` * 1
               
const signature = crypto.createHash('md5')
.update(digiuser + digiapi + referdf)
.digest('hex');

var config = {
    method: 'POST',
    url: `https://${global.digiFlazz}/v1/transaction`,
    headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json'
    },
    data: JSON.stringify({
        "username": digiuser,
        "buyer_sku_code": kode_buyer,
        "customer_no": user_no,
        "ref_id": referdf,
        "sign": signature
    })
};
  const parsedHarga = parseFloat(harga);  
axios(config)
.then(async res => {
AnanthaGanz.sendMessage(cek("id", m.sender), {text:`*RINCIAN PEMESANAN*

> Status : Process
> ID Trx : ${referdf}
> Layanan : ${product_name}
> Tujuan : ${user_no}
> Harga : ${formatmoney(parsedHarga)}
> Waktu : ${moment.tz(`Asia/${global.Wilayah}`).format('HH:mm:ss')} | ${moment.tz(`Asia/${global.Wilayah}`).format('DD/MM/YY')}

Weett, pesanan kamu sedang dalam proses`}, {Quoted: m})
let status = res.data.data.status;  
    console.log(status)        
while (status !== 'Sukses') {
await sleep(1000); 
const response = await axios(config);
status = response.data.data.status; 
if (status == "Gagal") {
sett("+saldo", cek("id", m.sender), harga) 
AnanthaGanz.sendPoll(cek("id", m.sender), `*RINCIAN PESANAN*

> Status : Failed
> ID Trx : ${referdf}
> Layanan : ${product_name}
> Tujuan : ${user_no}
> Harga : ${formatmoney(parsedHarga)}
> Waktu : ${moment.tz(`Asia/${global.Wilayah}`).format('HH:mm:ss')} | ${moment.tz(`Asia/${global.Wilayah}`).format('DD/MM/YY')}

yahh, pesanan kamu udah nggak bisa diproses. Mau Coba Lagi?`, [`Order ${cek("buyer_sku_code", m.sender)} ${cek("tujuan", m.sender)} [Untuk Order Ulang]`,`Hubungi Admin`])
let pesany = response.data.data.message
setTimeout(() => {
sendEmailTrxCancel(sender, pushname, referdf, product_name, user_no, parsedHarga, pesany);
}, 2500);
AnanthaGanz.sendMessage(`${owner}@s.whatsapp.net`, {text:`*KESALAHAN SISTEM*

> Layanan : ${product_name} 
> Message : ${response.data.data.message} 
> Customer : ${dengan_nol}`}, {Quoted: m})
setTimeout(() => {
sett("product_name", m.sender, "")
sett("price", m.sender, 0)
sett("tujuan", m.sender, "")  
sett("desc_prabayar", m.sender, "")  
sett("reff", m.sender, "") 
sett("buyer_sku_code", m.sender, "")  
sett("status", m.sender, true)
}, 8000);
              break;
              }
if (status === "Sukses") {
    AnanthaGanz.sendPoll(cek("id", m.sender), `*RINCIAN PEMESANAN*

> Status : Success
> ID Trx : ${referdf}
> Layanan : ${product_name}
> Tujuan : ${user_no}
> Harga : ${formatmoney(parsedHarga)}
> Waktu : ${moment.tz(`Asia/${global.Wilayah}`).format('HH:mm:ss')} | ${moment.tz(`Asia/${global.Wilayah}`).format('DD/MM/YY')}
> SN/Token : ${response.data.data.sn}

Oke Sip, pesanan kamu udah berhasil! Makasih udah belanja di *${footer}*`, [`Order ${cek("buyer_sku_code", m.sender)} ${cek("tujuan", m.sender)} [Untuk Order Ulang]`,`Print ${referdf}`])
let snket = response.data.data.sn
setTimeout(() => {
sendEmailTrxSuks(sender, pushname, snket, referdf, product_name, user_no, parsedHarga);
}, 2500);
const productDetails = d.find(i => i.product_name === product_name);
let fileRekap = JSON.stringify(response.data.data);
      fs.writeFileSync(`./SETTING/DB/TRANSACTION/Api/Prabayar/Sukses/${referdf}.json`, fileRekap);
if (productDetails) {
    const productInfo = `
Nama: ${productDetails.product_name}\nHarga: ${formatmoney(productDetails.price)}
`;
}
    const hargaModal = productDetails ? productDetails.price : null;
    const parsedModal = parseFloat(hargaModal);
    let lastSaldo = response.data.data.buyer_last_saldo * 1
    let digiSaldo = `${formatmoney(lastSaldo)}` 
    let totalPendapatan = parsedHarga - hargaModal * 1
AnanthaGanz.sendMessage(`${owner}@s.whatsapp.net`, {
                text: `*LAPORAN PENDAPATAN*

> Customer : ${dengan_nol}
> Layanan : ${product_name}
> Tujuan : ${user_no}
> ID Trx : ${referdf}
> Harga Pokok : ${formatmoney(parsedHarga)}
> Harga Modal : ${formatmoney(hargaModal)}
> Total Komisi : ${formatmoney(totalPendapatan)}
> Saldo Akhir Vendor : ${digiSaldo}
> Tanggal Penjualan : ${moment.tz(`Asia/${global.Wilayah}`).format('HH:mm:ss')} | ${moment.tz(`Asia/${global.Wilayah}`).format('DD/MM/YY')}`
            }, {Quoted: m});
   const trxFilePath = './SETTING/DB/trxuser.json';
    const trxUserData = JSON.parse(fs.readFileSync(trxFilePath, 'utf8'));
        const newTransaction = {
            buyer: m.sender,
            status: response.data.data.message,
            no_pembayaran: `Z26${randomPay}`,
            ref_id: response.data.data.ref_id,
            jam: moment.tz(`Asia/${global.Wilayah}`).format('HH:mm:ss'),
            waktu: moment.tz(`Asia/${global.Wilayah}`).format('DD/MM/YY'),
            produk: product_name,
            harga: parsedHarga,
            harga_modal: parsedModal,
            tujuan: user_no,
            invoice: response.data.data.sn,
        };
            trxUserData.push(newTransaction);
    fs.writeFileSync(trxFilePath, JSON.stringify(trxUserData, null, 2), 'utf8');
    setTimeout(() => {
sett("product_name", m.sender, "")
sett("price", m.sender, 0)
sett("tujuan", m.sender, "")  
sett("desc_prabayar", m.sender, "")  
sett("reff", m.sender, "") 
sett("buyer_sku_code", m.sender, "")  
sett("status", m.sender, true)
}, 8000);
}
          }})
          .catch(error => {
            if (error.response) {   
            
   sett("+saldo", cek("id", m.sender), harga) 
   console.error(error.response.data.data);
   let rekapGagal = JSON.stringify(error.response.data.data);
      fs.writeFileSync(`./SETTING/DB/TRANSACTION/Api/Prabayar/Gagal/${koderefe}.json`, rekapGagal);
AnanthaGanz.sendPoll(cek("id", m.sender), `*RINCIAN PESANAN*

> Status : Failed
> ID Trx : ${referdf}
> Layanan : ${product_name}
> Tujuan : ${user_no}
> Harga : ${formatmoney(parsedHarga)}
> Waktu : ${moment.tz(`Asia/${global.Wilayah}`).format('HH:mm:ss')} | ${moment.tz(`Asia/${global.Wilayah}`).format('DD/MM/YY')}

yahh, pesanan kamu udah nggak bisa diproses. Mau Coba Lagi?`, [`Order ${cek("buyer_sku_code", m.sender)} ${cek("tujuan", m.sender)} [Untuk Order Ulang]`,`Hubungi Admin`])
let pesanyu = error.response.data.data.message
setTimeout(() => {
sendEmailTrxCancele(sender, pushname, referdf, product_name, user_no, parsedHarga, pesanyu);
}, 2500);
              AnanthaGanz.sendMessage(`${owner}@s.whatsapp.net`, {text:`*KESALAHAN SISTEM*

> Layanan : ${product_name} 
> Message : ${error.response.data.data.message} 
> Customer : ${dengan_nol}`}, {Quoted: m})
setTimeout(() => {
sett("product_name", m.sender, "")
sett("price", m.sender, 0)
sett("tujuan", m.sender, "")  
sett("desc_prabayar", m.sender, "")  
sett("reff", m.sender, "") 
sett("buyer_sku_code", m.sender, "")  
sett("status", m.sender, true)
}, 8000);
            }  
   });
                  } catch (error) {
        console.log(error);
        }
                break;
            }
        }
    });
    } }
}
break;

case 'indomaretpay':
case 'alfamartpay': {
if (cek("verfiyemail", m.sender) == true) return reply(`Oops, Silahkan Daftarkan Email anda\nContoh : .setemail xxxxx@gmail.com`);
    if (cek("cekVerify", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, `Oops, Silahkan Verifikasi Email : ${cek("email", m.sender)}`, ['Verifikasicode','Hubungi Admin']);
   if(cek("syarat", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, 'Oops, Kamu Belum Menyetujui Syarat Ketentuan dari kami. Mohon setujuin dulu, agar dapat mengakses fitur dari kami.', ['Saya Setuju','Syarat nya apa aja']);
    if (cek("status", m.sender) == true) return reply(`Oops, kamu belum memiliki invoice! buat dulu yukk`);
        if(fs.existsSync(`./SETTING/DB/TRANSACTION/Api/Deposit/${cek("deposit", m.sender)}.json`)) return AnanthaGanz.sendPoll(m.chat, `Oops, Kamu Sedang Memiliki Invoice ${cek("deposit", m.sender)}, apakah kamu ingin cancel?`, ['Cancel Aja','Hubungi Admin']);
let user_payment_mount = `${cek("price", m.sender)}` * 1;
if (user_payment_mount < 15000) return m.reply(`Minimun Payment ${command} adalah Rp. 15.000`)
if (user_payment_mount > 2500000) return m.reply(`Maximal Payment ${command} adalah Rp. 2.500.000`)
    let FormData = require('form-data');
    let axios = require('axios');
    let md5 = require('md5');
    let kode_buyer = `${cek("buyer_sku_code", m.sender)}`;

    for(let i of r) {     
        if(i.buyer_sku_code == kode_buyer) { 
            let tujuan = `${cek("tujuan", m.sender)}` ;
            let harga = user_payment_mount * 1
            let referdf = `${cek("reff", m.sender)}`;
            let ref_no = `${sender.split('@')[0]}`;
            let product_name = `${cek("product_name", m.sender)}`;
            let user_no = `${tujuan}`;
            let harga_produk = `${harga}`;
            let kode_produk= `${kode_buyer}`;

            async function makePayment() {
                             if (command === 'alfamartpay') {
                paymetcod1 = '18'; // Ganti '13' dengan kode pembayaran dana yang sesuai
    } else if (command === 'indomaretpay') {
                paymetcod1 = '19'; // Ganti '14' dengan kode pembayaran linkaja yang sesuai
                }
                try {
                    let keynya = global.key;
                    let kodeunick = koderefe
                    let paymetcod = paymetcod1
                    let aomut = Math.round(harga_produk);
                    let exp = 1800;
                    let create = keynya + kodeunick + paymetcod + aomut + exp + 'NewTransaction';
                    let signature = md5(create);
                    
                    // Membuat data form untuk permintaan pembayaran
                    var paymentData = new FormData();
                    paymentData.append('key', keynya);
                    paymentData.append('request', 'new');
                    paymentData.append('unique_code', kodeunick);
                    paymentData.append('service', paymetcod);
                    paymentData.append('amount', aomut);
                    paymentData.append('note', `PAY ORDER ID ${referdf}`);
                    paymentData.append('valid_time', exp);
                    paymentData.append('customer_email', cek("email", m.sender));
                    paymentData.append('type_fee', '1');
                    paymentData.append('signature', signature); // Menggunakan signature yang telah dihitung

                    // Konfigurasi untuk permintaan pembayaran
                    var paymentConfig = {
                        method: 'post',
                        url: 'https://paydisini.co.id/api/',
                        headers: { 
                            ...paymentData.getHeaders()
                        },
                        data: paymentData
                    };

                    // Mengirim permintaan pembayaran
                    let paymentResponse = await axios(paymentConfig);
                    let paymentDataResponse = paymentResponse.data.data;
      let obj = { id: m.sender, ref: `${paymentDataResponse.unique_code}`, method : `${paymentDataResponse.service_name}`, diterima: `${paymentDataResponse.balance}`, total: `${paymentDataResponse.amount}`, fee: `${paymentDataResponse.fee}`, url: `${paymentDataResponse.checkout_url}` }
          sett("deposit", m.sender, `${paymentDataResponse.unique_code}`)
fs.writeFileSync(`./SETTING/DB/TRANSACTION/Api/Deposit/${cek("deposit", m.sender)}.json`, JSON.stringify(obj))
                    let ccapt = ` CHECK OUT YOUR ORDER \n\n> Metode : ${paymentDataResponse.service_name}\n> Referensi : ${paymentDataResponse.unique_code}\n> Berlaku : 30 Menit\n> Tagihan : ${formatmoney(paymentDataResponse.balance)}\n> Fee : ${formatmoney(paymentDataResponse.fee)}\n> Total Bayar : ${formatmoney(paymentDataResponse.amount)}\n> Catatan : Pembayaran Order ${referdf}|${product_name}\n\nKlik "Bayar Sekarang" untuk Melakukan Pembayaran`;
AnanthaGanz.sendPoll(m.chat, ccapt, ['Bayar Sekarang','Cancel Pembayaran']);
setTimeout(() => {
const deppo = JSON.parse(fs.readFileSync(`./SETTING/DB/TRANSACTION/Api/Deposit/${cek("deposit", m.sender)}.json`))
               let method = `${checkIdDepo(m.sender, deppo) ? checkIdDepo(m.sender, deppo) : deppo.method}`
              let member = `${checkIdDepo(m.sender, deppo) ? checkIdDepo(m.sender, deppo) : deppo.id}`
                let price_sender = `${checkIdDepo(m.sender, deppo) ? checkIdDepo(m.sender, deppo) : deppo.diterima}` * 1
               let fee_sender = `${checkIdDepo(m.sender, deppo) ? checkIdDepo(m.sender, deppo) : deppo.fee}` * 1
               let ref_sender = `${checkIdDepo(m.sender, deppo) ? checkIdDepo(m.sender, deppo) : deppo.ref}` 
               let total_sender = `${checkIdDepo(m.sender, deppo) ? checkIdDepo(m.sender, deppo) : deppo.total}` * 1
               let url = `${checkIdDepo(m.sender, deppo) ? checkIdDepo(m.sender, deppo) : deppo.url}`
               sendEmailPending(sender, pushname, ref_sender, method, price_sender, fee_sender, total_sender, url);
               }, 5000);
                    let unick = paymentDataResponse.unique_code;
                    // Memantau status pembayaran
                    let dataStatus = paymentDataResponse.status;
                    const startTime = new Date().getTime();
                    while (dataStatus !== "Success") {
                        await sleep(1000);
                        let create3 = keynya + unick + 'StatusTransaction';
                        let signature3 = md5(create3);
                        var checkStatusData = new FormData();
                        checkStatusData.append('key', keynya);
                        checkStatusData.append('request', 'status');
                        checkStatusData.append('unique_code', unick);
                        checkStatusData.append('signature', signature3); 
                        // Konfigurasi untuk memeriksa status pembayaran
                        var checkStatusConfig = {
                            method: 'post',
                            url: 'https://paydisini.co.id/api/',
                            headers: { 
                                ...checkStatusData.getHeaders()
                            },
                            data: checkStatusData
                        };
                        // Mengirim permintaan untuk memeriksa status pembayaran
                        let statusResponse = await axios(checkStatusConfig);
                        let statusDataResponse = statusResponse.data.data;
                        dataStatus = statusDataResponse.status;
                        console.log(dataStatus);
                        // Memeriksa waktu timeout
                        const currentTime = new Date().getTime();
                        const elapsedTime = (currentTime - startTime) / (1000 * 60 * 30);
                        if (elapsedTime >= 1) {
                            m.reply(`Upss, tiket ${cek("deposit", m.sender)} udah gak berlaku nih. Yuk, buat yang baru!`);
              cancelPay();
                            break;
                        }
                        // Jika pembayaran berhasil
                        if (dataStatus === "Success") {
                        const deppo = JSON.parse(fs.readFileSync(`./SETTING/DB/TRANSACTION/Api/Deposit/${cek("deposit", m.sender)}.json`))
               let method = `${checkIdDepo(m.sender, deppo) ? checkIdDepo(m.sender, deppo) : deppo.method}`
              let member = `${checkIdDepo(m.sender, deppo) ? checkIdDepo(m.sender, deppo) : deppo.id}`
                let price_sender = `${checkIdDepo(m.sender, deppo) ? checkIdDepo(m.sender, deppo) : deppo.diterima}` * 1
               let fee_sender = `${checkIdDepo(m.sender, deppo) ? checkIdDepo(m.sender, deppo) : deppo.fee}` * 1
               let ref_sender = `${checkIdDepo(m.sender, deppo) ? checkIdDepo(m.sender, deppo) : deppo.ref}` 
               let total_sender = `${checkIdDepo(m.sender, deppo) ? checkIdDepo(m.sender, deppo) : deppo.total}` * 1
               
const signature = crypto.createHash('md5')
.update(digiuser + digiapi + referdf)
.digest('hex');

var config = {
    method: 'POST',
    url: `https://${global.digiFlazz}/v1/transaction`,
    headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json'
    },
    data: JSON.stringify({
        "username": digiuser,
        "buyer_sku_code": kode_buyer,
        "customer_no": user_no,
        "ref_id": referdf,
        "sign": signature
    })
};
  const parsedHarga = parseFloat(harga);  
axios(config)
.then(async res => {
AnanthaGanz.sendMessage(cek("id", m.sender), {text:`*RINCIAN PEMESANAN*

> Status : Process
> ID Trx : ${referdf}
> Layanan : ${product_name}
> Tujuan : ${user_no}
> Harga : ${formatmoney(parsedHarga)}
> Waktu : ${moment.tz(`Asia/${global.Wilayah}`).format('HH:mm:ss')} | ${moment.tz(`Asia/${global.Wilayah}`).format('DD/MM/YY')}

Weett, pesanan kamu sedang dalam proses`}, {Quoted: m})
let status = res.data.data.status;  
    console.log(status)        
while (status !== 'Sukses') {
await sleep(1000); 
const response = await axios(config);
status = response.data.data.status; 
if (status == "Gagal") {
sett("+saldo", cek("id", m.sender), harga) 
AnanthaGanz.sendPoll(cek("id", m.sender), `*RINCIAN PESANAN*

> Status : Failed
> ID Trx : ${referdf}
> Layanan : ${product_name}
> Tujuan : ${user_no}
> Harga : ${formatmoney(parsedHarga)}
> Waktu : ${moment.tz(`Asia/${global.Wilayah}`).format('HH:mm:ss')} | ${moment.tz(`Asia/${global.Wilayah}`).format('DD/MM/YY')}

yahh, pesanan kamu udah nggak bisa diproses. Mau Coba Lagi?`, [`Order ${cek("buyer_sku_code", m.sender)} ${cek("tujuan", m.sender)} [Untuk Order Ulang]`,`Hubungi Admin`])
let pesany = response.data.data.message
setTimeout(() => {
sendEmailTrxCancel(sender, pushname, referdf, product_name, user_no, parsedHarga, pesany);
}, 2500);
AnanthaGanz.sendMessage(`${owner}@s.whatsapp.net`, {text:`*KESALAHAN SISTEM*

> Layanan : ${product_name} 
> Message : ${response.data.data.message} 
> Customer : ${dengan_nol}`}, {Quoted: m})
setTimeout(() => {
sett("product_name", m.sender, "")
sett("price", m.sender, 0)
sett("tujuan", m.sender, "")  
sett("desc_prabayar", m.sender, "")  
sett("reff", m.sender, "") 
sett("buyer_sku_code", m.sender, "")  
sett("status", m.sender, true)
}, 8000);
              break;
              }
if (status === "Sukses") {
    AnanthaGanz.sendPoll(cek("id", m.sender), `*RINCIAN PEMESANAN*

> Status : Success
> ID Trx : ${referdf}
> Layanan : ${product_name}
> Tujuan : ${user_no}
> Harga : ${formatmoney(parsedHarga)}
> Waktu : ${moment.tz(`Asia/${global.Wilayah}`).format('HH:mm:ss')} | ${moment.tz(`Asia/${global.Wilayah}`).format('DD/MM/YY')}
> SN/Token : ${response.data.data.sn}

Oke Sip, pesanan kamu udah berhasil! Makasih udah belanja di *${footer}*`, [`Order ${cek("buyer_sku_code", m.sender)} ${cek("tujuan", m.sender)} [Untuk Order Ulang]`,`Print ${referdf}`])
let snket = response.data.data.sn
setTimeout(() => {
sendEmailTrxSuks(sender, pushname, snket, referdf, product_name, user_no, parsedHarga);
}, 2500);
const productDetails = d.find(i => i.product_name === product_name);
let fileRekap = JSON.stringify(response.data.data);
      fs.writeFileSync(`./SETTING/DB/TRANSACTION/Api/Prabayar/Sukses/${referdf}.json`, fileRekap);
if (productDetails) {
    const productInfo = `
Nama: ${productDetails.product_name}\nHarga: ${formatmoney(productDetails.price)}
`;
}
    const hargaModal = productDetails ? productDetails.price : null;
    const parsedModal = parseFloat(hargaModal);
    let lastSaldo = response.data.data.buyer_last_saldo * 1
    let digiSaldo = `${formatmoney(lastSaldo)}` 
    let totalPendapatan = parsedHarga - hargaModal * 1
AnanthaGanz.sendMessage(`${owner}@s.whatsapp.net`, {
                text: `*LAPORAN PENDAPATAN*

> Customer : ${dengan_nol}
> Layanan : ${product_name}
> Tujuan : ${user_no}
> ID Trx : ${referdf}
> Harga Pokok : ${formatmoney(parsedHarga)}
> Harga Modal : ${formatmoney(hargaModal)}
> Total Komisi : ${formatmoney(totalPendapatan)}
> Saldo Akhir Vendor : ${digiSaldo}
> Tanggal Penjualan : ${moment.tz(`Asia/${global.Wilayah}`).format('HH:mm:ss')} | ${moment.tz(`Asia/${global.Wilayah}`).format('DD/MM/YY')}`
            }, {Quoted: m});
   const trxFilePath = './SETTING/DB/trxuser.json';
    const trxUserData = JSON.parse(fs.readFileSync(trxFilePath, 'utf8'));
        const newTransaction = {
            buyer: m.sender,
            status: response.data.data.message,
            no_pembayaran: `Z26${randomPay}`,
            ref_id: response.data.data.ref_id,
            jam: moment.tz(`Asia/${global.Wilayah}`).format('HH:mm:ss'),
            waktu: moment.tz(`Asia/${global.Wilayah}`).format('DD/MM/YY'),
            produk: product_name,
            harga: parsedHarga,
            harga_modal: parsedModal,
            tujuan: user_no,
            invoice: response.data.data.sn,
        };
            trxUserData.push(newTransaction);
    fs.writeFileSync(trxFilePath, JSON.stringify(trxUserData, null, 2), 'utf8');
    setTimeout(() => {
sett("product_name", m.sender, "")
sett("price", m.sender, 0)
sett("tujuan", m.sender, "")  
sett("desc_prabayar", m.sender, "")  
sett("reff", m.sender, "") 
sett("buyer_sku_code", m.sender, "")  
sett("status", m.sender, true)
}, 8000);
}
          }})
          .catch(error => {
            if (error.response) {   
            
   sett("+saldo", cek("id", m.sender), harga) 
   console.error(error.response.data.data);
   let rekapGagal = JSON.stringify(error.response.data.data);
      fs.writeFileSync(`./SETTING/DB/TRANSACTION/Api/Prabayar/Gagal/${koderefe}.json`, rekapGagal);
AnanthaGanz.sendPoll(cek("id", m.sender), `*RINCIAN PESANAN*

> Status : Failed
> ID Trx : ${referdf}
> Layanan : ${product_name}
> Tujuan : ${user_no}
> Harga : ${formatmoney(parsedHarga)}
> Waktu : ${moment.tz(`Asia/${global.Wilayah}`).format('HH:mm:ss')} | ${moment.tz(`Asia/${global.Wilayah}`).format('DD/MM/YY')}

yahh, pesanan kamu udah nggak bisa diproses. Mau Coba Lagi?`, [`Order ${cek("buyer_sku_code", m.sender)} ${cek("tujuan", m.sender)} [Untuk Order Ulang]`,`Hubungi Admin`])
let pesanyu = error.response.data.data.message
setTimeout(() => {
sendEmailTrxCancele(sender, pushname, referdf, product_name, user_no, parsedHarga, pesanyu);
}, 2500);
              AnanthaGanz.sendMessage(`${owner}@s.whatsapp.net`, {text:`*KESALAHAN SISTEM*

> Layanan : ${product_name} 
> Message : ${error.response.data.data.message} 
> Customer : ${dengan_nol}`}, {Quoted: m})
setTimeout(() => {
sett("product_name", m.sender, "")
sett("price", m.sender, 0)
sett("tujuan", m.sender, "")  
sett("desc_prabayar", m.sender, "")  
sett("reff", m.sender, "") 
sett("buyer_sku_code", m.sender, "")  
sett("status", m.sender, true)
}, 8000);
            }  
   });
   setTimeout(() => {
                fs.unlinkSync(`./SETTING/DB/TRANSACTION/Api/Deposit/${cek("deposit", m.sender)}.json`);
                }, 4000);
                setTimeout(() => {
    sett("deposit", m.sender, "")
                }, 6000);
                 } else if (dataStatus === "Canceled") {
               console.log(`Berhasil! Ref ${cek("deposit", m.sender)} Dihapus`)
                        }
                    }
                } catch (error) {
                    console.log(error);
                    
                }
            }

            makePayment();
} }
break;

}
case 'cektagihan':{
if (cek("verfiyemail", m.sender) == true) return reply(`Oops, Silahkan Daftarkan Email anda\nContoh : .setemail xxxxx@gmail.com`);
    if (cek("cekVerify", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, `Oops, Silahkan Verifikasi Email : ${cek("email", m.sender)}`, ['Verifikasicode','Hubungi Admin']);
if(cek("syarat", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, 'Oops, Kamu Belum Menyetujui Syarat Ketentuan dari kami. Mohon setujuin dulu, agar dapat mengakses fitur dari kami.', ['Saya Setuju','Syarat nya apa aja']);
if(cek("status", m.sender) == false) return reply(`Uh oh, sepertinya transaksi ${cek("reff", m.sender)} belum selesai nih! 😕`)
    const crypto = require("crypto")
    const axios = require("axios")
    let sku_pasca = q.split(" ")[0]
    let no_pasca = q.split(" ")[1]
    if (!sku_pasca || !no_pasca) {
        return reply(`*CEK & BAYAR TAGIHAN*

Gunakan:
*cektagihan sku_kode no_pelanggan*

Contoh:
*cektagihan PLNP 55555xxxx*`)
    }
    
    let ref_pasca = koderef
    let pasca = JSON.parse(fs.readFileSync('./SETTING/DB/pasca.json'));
    let layanan_pasca = ""
    
    for(let i of pasca) {
        if (i.buyer_sku_code == sku_pasca) {
            layanan_pasca = i.product_name;
            sett("desc_prabayar", m.sender, layanan_pasca);
            break;
        }
    }
    
    let signature = crypto.createHash('md5')
        .update(digiuser + digiapi + ref_pasca)
        .digest('hex');

    var config = {
        method: 'post', 
        url: `https://${global.digiFlazz}/v1/transaction`,  
        headers: {
            'Content-Type': 'application/json',
            'Accept': 'application/json'
        },
        data: {
            "commands": "inq-pasca",
            "username": digiuser,
            "buyer_sku_code": sku_pasca,
            "customer_no": no_pasca,
            "ref_id": ref_pasca,
            "sign": signature
        }
    };
    
    axios(config)
        .then(async response => {          
         console.log(response.data.data);
            if (response.data.data.status == "Sukses") {
const {
    lembar_tagihan,
    alamat,
    tarif,
    transaksi,
    kode_iuran,
    daya,
    jpk,
    tanggal_registrasi,
    jkk,
    kantor_cabang,
    tgl_efektif,
    kode_divisi,
    jkm,
    no_registrasi,
    jumlah_peserta,
    jht,
    jpn,
    npp,
    kode_program,
    tgl_expired,
    jatuh_tempo
} = response.data.data.desc;
const {
    customer_name,
    customer_no
} = response.data.data;
const { detail: [{ meter_awal, meter_akhir, biaya_lain }] } = response.data.data.desc;
const totalTagihan = parseInt(response.data.data.selling_price);
var periodeTagihan = response.data.data.desc.detail.map(detail => detail.periode);
var periodeTagihanFinal = periodeTagihan.join(", ");
let tgh = (totalTagihan - response.data.data.admin) * 1;
let admin = response.data.data.admin;
var denda = response.data.data.desc.detail.map(detail => detail.denda).reduce((acc, cur) => acc + cur * 1, 0);
await loading();
if (sku_pasca === "PLNP") {
    AnanthaGanz.sendPoll(m.chat, `    
> ---------------------------------------
> |   DETAIL TAGIHAN                    
> ---------------------------------------
> | Layanan: ${layanan_pasca}                        
> | Nomor Pelanggan: ${customer_no}                    
> | Nama Pelanggan: ${customer_name}                  
> | Tarif: ${tarif}    
> | Daya: ${daya}                      
> ---------------------------------------
> | *Lembar Tagihan :* ${lembar_tagihan || '-'}
> | *Periode :* ${periodeTagihanFinal}
> | *Catatan:* Tagihan Tersedia 
> ---------------------------------------
> | *Denda :* ${formatmoney(denda)}
> | *Tagihan :* ${formatmoney(tgh)}
> | *Admin :* ${formatmoney(admin)}
> | *Total :* ${formatmoney(totalTagihan)}
> | *Meter Awal :* ${meter_awal || '-'}
> | *Meter Akhir :* ${meter_akhir || '-'}
> ---------------------------------------\n`, ["Pay-tagihan", "Batal"]);
} else if (sku_pasca === "PLNTGLIS") {
    const billingInfo = `
> ---------------------------------------
> |   DETAIL TAGIHAN                    
> ---------------------------------------
> | Layanan: ${layanan_pasca}                   
> | Nomor Pelanggan: ${customer_no}                    
> | Nama Pelanggan: ${customer_name}                  
> | Tarif: ${tarif || '-'}    
> | Daya: ${daya || '-'}                      
> ---------------------------------------
> | *Lembar Tagihan :* ${lembar_tagihan || '-'} 
> | *Transaksi :* ${transaksi || '-'}
> | *No Registrasi :* ${no_registrasi || '-'}
> | *Tanggal Registrasi :* ${tanggal_registrasi || '-'}
> ---------------------------------------
> | *Tagihan :* ${formatmoney(tgh)}
> | *Admin :* ${formatmoney(admin)}
> | *Total :* ${formatmoney(totalTagihan)}
> ---------------------------------------\n`;

    AnanthaGanz.sendPoll(m.chat, billingInfo, ["Pay-tagihan", "Batal"]);
} else if (["Indihome", "Iconnet", "CBN", "TELKOMPSTN", "MyRepublic"].includes(sku_pasca)) {
    AnanthaGanz.sendPoll(m.chat, `
> ---------------------------------------
> |    DETAIL TAGIHAN                           
> ---------------------------------------
> | *Nama Pelanggan:* ${customer_name}                  
> | *Id Pelanggan:* ${customer_no}   
> | *Layanan:* ${layanan_pasca}           
> ---------------------------------------
> | *Lembar Tagihan :* ${lembar_tagihan} 
> | *Periode :* ${periodeTagihanFinal}
> | *Catatan:* Tagihan Tersedia 
> ---------------------------------------
> | *Tagihan :* ${formatmoney(tgh)}
> | *Admin :* ${formatmoney(admin)}
> | *Total :* ${formatmoney(totalTagihan)}
> ---------------------------------------\n`, ["Pay-tagihan", "Batal"]);
} else if (sku_pasca === "BPJSKES") {
    AnanthaGanz.sendPoll(m.chat, `
> ---------------------------------------
> |   DETAIL TAGIHAN                  
> ---------------------------------------
> | Layanan: ${layanan_pasca}                       
> | Nomor Peserta: ${customer_no}                    
> | Nama Peserta: ${customer_name}                 
> | Jumlah Peserta: ${jumlah_peserta}       
> | *Alamat :* ${alamat || "-"}               
> ---------------------------------------
> | *Lembar Tagihan :* ${lembar_tagihan} 
> | *Periode :* ${periodeTagihanFinal}
> | *Catatan:* Tagihan Tersedia 
> ---------------------------------------
> | *Tagihan :* ${formatmoney(tgh)}
> | *Admin :* ${formatmoney(admin)}
> | *Total :* ${formatmoney(totalTagihan)}
> ---------------------------------------\n`, ["Pay-tagihan", "Batal"]);
} else if (sku_pasca === "BPJSKBPU") {
    const billingInfo = `
> ---------------------------------------
> |        DETAIL TAGIHAN                  
> ---------------------------------------
> | Layanan: ${layanan_pasca}               
> | Nomor Peserta: ${customer_no}                    
> | Nama Peserta: ${customer_name}                           
> ---------------------------------------
> | *Lembar Tagihan :* ${lembar_tagihan || '-'} 
> | *Kode Iuran :* ${kode_iuran || '-'} 
> | *Kode Program :* ${kode_program || '-'} 
> | *JKK :* ${jkk || '-'} 
> | *JKM :* ${jkm || '-'} 
> | *JHT :* ${jht || '-'} 
> | *Kantor Cabang :* ${kantor_cabang || '-'} 
> | *Tanggal Efektif :* ${tgl_efektif || '-'} 
> | *Tanggal Expired :* ${tgl_expired || '-'} 
> ---------------------------------------
> | *Tagihan :* ${formatmoney(tgh)}
> | *Admin :* ${formatmoney(admin)}
> | *Total :* ${formatmoney(totalTagihan)}
> ---------------------------------------------------------\n`;

    AnanthaGanz.sendPoll(m.chat, billingInfo, ["Pay-tagihan", "Batal"]);
} else if (sku_pasca === "BPJSKPU") {
    const billingInfo = `
> ---------------------------------------------------------
> |        DETAIL TAGIHAN                  
> ---------------------------------------------------------
> | Layanan: ${layanan_pasca}                               
> | Nomor Peserta: ${customer_no}                    
> | Nama Peserta: ${customer_name}                 
> ---------------------------------------------------------
> | *Lembar Tagihan :* ${lembar_tagihan || '-'} 
> | *Kode Iuran :* ${kode_iuran || '-'} 
> | *JHT :* ${formatmoney(jht || 0)}
> | *JKK :* ${formatmoney(jkk || 0)}
> | *JKM :* ${formatmoney(jkm || 0)}
> | *JPK :* ${formatmoney(jpk || 0)}
> | *JPN :* ${formatmoney(jpn || 0)}
> | *NPP :* ${npp || '-'} 
> | *Kode Divisi :* ${kode_divisi || '-'} 
> ---------------------------------------------------------
> | *Tagihan :* ${formatmoney(tgh)}
> | *Admin :* ${formatmoney(admin)}
> | *Total :* ${formatmoney(totalTagihan)}
> ---------------------------------------------------------\n`;

AnanthaGanz.sendPoll(m.chat, billingInfo, ["Pay-tagihan", "Batal"]);
} else if (sku_pasca.startsWith('PDAM')) {
    AnanthaGanz.sendPoll(m.chat, `
> ---------------------------------------------------------
> |           DETAIL TAGIHAN                           
> ---------------------------------------------------------
> | *Nama Pelanggan:* ${customer_name || "-"}                  
> | *Id Pelanggan:* ${customer_no || "-"}   
> | *Layanan:* ${layanan_pasca}           
> ---------------------------------------------------------
> | *Lembar Tagihan :* ${lembar_tagihan || "-"} 
> | *Periode :* ${periodeTagihanFinal || "-"}
> | *Jatuh Tempo :* ${jatuh_tempo || "-"}
> | *Alamat :* ${alamat || "-"}
> | *Tarif :* ${tarif || "-"}
> | *Meter Awal :* ${meter_awal || "-"}
> | *Meter Akhir :* ${meter_akhir || "-"}
> | *Biaya Lain :* ${biaya_lain || "-"}
> | *Denda :* ${denda}
> ---------------------------------------------------------
> | *Tagihan :* ${formatmoney(tgh)}
> | *Admin :* ${formatmoney(admin)}
> | *Total :* ${formatmoney(totalTagihan)}
> ---------------------------------------------------------\n`, ["Pay-tagihan", "Batal"]);
} else if (sku_pasca === sku_pasca) 
    AnanthaGanz.sendPoll(m.chat, `
> ---------------------------------------------------------
> |           DETAIL TAGIHAN                           
> ---------------------------------------------------------
> | *Nama Pelanggan :* ${customer_name}                  
> | *Id Pelanggan :* ${customer_no}   
> | *Layanan :* ${layanan_pasca}           
> ---------------------------------------------------------
> | *Lembar Tagihan :* ${lembar_tagihan} 
> | *Periode :* ${periodeTagihanFinal}
> | *Catatan :* Tagihan Tersedia 
> ---------------------------------------------------------
> | *Tagihan :* ${formatmoney(tgh)}
> | *Admin :* ${formatmoney(admin)}
> | *Total :* ${formatmoney(totalTagihan)}
> ---------------------------------------------------------\n`, ["Pay-tagihan", "Batal"]);
let qc = JSON.stringify(response.data.data);
      fs.writeFileSync(`./SETTING/DB/TRANSACTION/Api/Pascabayar/Inq-pasca/${ref_pasca}.json`, qc);
                setTimeout(() => {
                    sett("price", m.sender, response.data.data.selling_price);
                    sett("product_name", m.sender, response.data.data.customer_name);
                    sett("status", m.sender, false);
                    sett("tujuan", m.sender, response.data.data.customer_no);
                    sett("buyer_sku_code", m.sender, sku_pasca);
                    sett("desc_prabayar", m.sender, layanan_pasca);
                    sett("reff", m.sender, response.data.data.ref_id);
                    sett("layanan", m.sender, layanan_pasca);
                }, 2000);
            }
switch(response.data.data.rc) {
    case "60":
        AnanthaGanz.sendMessage(from, { text: "Oops, tagihan bulan ini nggak ketemu nih! Coba lagi nanti ya..." });
        break;
    case "43":
        AnanthaGanz.sendMessage(from, { text: "Oops, *Kode SKU* tidak ditemukan! pastikan sudah terdaftar ya" });
        break;
    case "02":
        AnanthaGanz.sendMessage(from, { text: "Oops, sepertinya gagal dari server!" });
        break;
    case "54":
        AnanthaGanz.sendMessage(from, { text: "Oops, ID pelanggan kamu kayaknya tidak terdaftar nih! Pastikan udah benar ya!" });
        break;
}
        })
        .catch(error => {
    if (error.response) {
      console.log(error.response.data.data);
         let qc = JSON.stringify(error.response.data.data);
      fs.writeFileSync(`./SETTING/DB/TRANSACTION/Api/Pascabayar/Gagal/${ref_pasca}.json`, qc);
      reply("Oops, Gagal kayaknya ada kendala di server kami")
      AnanthaGanz.sendMessage(nomorKu, { text: `Oops, ${error.response.data.data.message}`}, { Quoted: m });
                }
        });
}
break; 
case 'pay-tagihan': {
if (cek("verfiyemail", m.sender) == true) return reply(`Oops, Silahkan Daftarkan Email anda\nContoh : .setemail xxxxx@gmail.com`);
    if (cek("cekVerify", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, `Oops, Silahkan Verifikasi Email : ${cek("email", m.sender)}`, ['Verifikasicode','Hubungi Admin']);
if(cek("syarat", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, 'Oops, Kamu Belum Menyetujui Syarat Ketentuan dari kami. Mohon setujuin dulu, agar dapat mengakses fitur dari kami.', ['Saya Setuju','Syarat nya apa aja']);
const crypto = require("crypto")
const axios = require("axios")
if(cek("reff", m.sender) == "") return reply(`Gagal, kamu belum melakukan *${prefix}cektagihan* yuk cek tagihan nya dulu...`)
let ru = `${sender.split('@')[0]}`
let total_tagihan = `${cek("price", m.sender)}` * 1
if(total_tagihan > cek("saldo", m.sender)) return reply(`Gagal, yah saldo kamu enggak cukup, buat proses pesanannya`)
sett("-saldo", ru+"@s.whatsapp.net", total_tagihan) 
let ref_pasca = `${cek("reff", m.sender)}`
let signature = crypto.createHash('md5')
  .update(digiuser + digiapi + ref_pasca)
  .digest('hex');

var config = {
  method: 'POST',  
  url: `https://${global.digiFlazz}/v1/transaction`,
  data: {
    "commands": "pay-pasca",
    "username": digiuser,
    "buyer_sku_code": `${cek("buyer_sku_code", m.sender)}`,
    "customer_no": `${cek("tujuan", m.sender)}`,
    "ref_id": ref_pasca,
    "sign": signature
}
};
axios(config)
  .then(async response => {   
await loading();
   if (response.data.data.status == "Gagal") 
              {           
              sett("+saldo", ru+"@s.whatsapp.net", total_tagihan) 
 AnanthaGanz.sendMessage(from, { text : `Gagal, ${response.data.data.message}`})
 AnanthaGanz.sendMessage(`${owner}@s.whatsapp.net`, {text:`🚨 *LAPORAN KESALAHAN TIDAK BERHASIL:*

Produk: ${cek("layanan", m.sender)} 
Kesalahan: ${response.data.data.message} 
Pelanggan: [Klik untuk chat](wa.me/${ru})`}, {Quoted: m})
              } else if (response.data.data.status == "Sukses") {
          let currentDate = moment.tz('Asia/Jakarta');
          let tglll = currentDate.format('DD/MM/YYYY');
          let bulanskrg = currentDate.format('MMMM');
          let thun = currentDate.format('YYYY');
          let totalTagihan = parseInt(response.data.data.selling_price);
          let tgh = (totalTagihan - response.data.data.admin) * 1;
          let admin = response.data.data.admin;
          let periodeTagihan = response.data.data.desc.detail.map(detail => detail.periode);
          let periodeTagihanFinal = periodeTagihan.join(", ");
          setTimeout(() => {
            AnanthaGanz.sendPoll(from, `    
> ---------------------------------------
> STRUK PEMBAYARAN
> ---------------------------------------
> Tanggal : ${tglll} ${bulanskrg} ${thun}
> Waktu : ${currentDate.format('HH:mm')} WITA
> Nama Pelanggan : ${response.data.data.customer_name}
> Nomor Pelanggan : ${response.data.data.customer_no}     
> Layanan : ${cek("layanan", m.sender)} 
> ---------------------------------------
> Lembar Tagihan : ${response.data.data.desc.lembar_tagihan} 
> Periode : ${periodeTagihanFinal}
> ---------------------------------------
> Tagihan : ${formatmoney(tgh)}                       
> Admin : ${formatmoney(admin)}                                
> Total : ${formatmoney(totalTagihan)}
> ---------------------------------------
> Potongan : Rp 0
> Total Pembayaran : ${formatmoney(totalTagihan)}
> ---------------------------------------
> Nomor Seri : ${response.data.data.sn}
> ---------------------------------------
> Terima kasih telah melakukan pembayaran.
> Silakan simpan struk ini sebagai bukti pembayaran.\n`, ['Menu', 'Hubungi Kami']);
          }, 3000);
          let qc = JSON.stringify(response.data.data);
          fs.writeFileSync(`./SETTING/DB/TRANSACTION/Api/Pascabayar/Pay-pasca/${response.data.data.ref_id}.json`, qc);
          AnanthaGanz.sendMessage(`${owner}@s.whatsapp.net`, {
            text: `*LAPORAN PENDAPATAN*

> Customer : wa.me/${ru}
> Layanan : ${cek("layanan", m.sender)}
> Tujuan : ${response.data.data.customer_no}
> ID Trx : ${response.data.data.ref_id}
> Tagihan : ${formatmoney(totalTagihan)}
> Tanggal Penjualan : ${moment.tz(`Asia/${global.Wilayah}`).format('HH:mm:ss')} | ${moment.tz(`Asia/${global.Wilayah}`).format('DD/MM/YY')}`
  }, {Quoted: m});
          const trxFilePath = './SETTING/DB/trxuser.json';
          const trxUserData = JSON.parse(fs.readFileSync(trxFilePath, 'utf8'));
          const newTransaction = {
            buyer: m.sender,
            status: response.data.data.message,
            no_pembayaran: `INV${randomPay}`,
            ref_id: response.data.data.ref_id,
            jam: moment.tz(`Asia/${global.Wilayah}`).format('HH:mm:ss'),
            waktu: moment.tz(`Asia/${global.Wilayah}`).format('DD/MM/YY'),
            produk: `${cek("layanan", m.sender)}`,
            harga: totalTagihan,
            harga_modal: response.data.data.price,
            tujuan: response.data.data.customer_no,
            invoice: response.data.data.sn,
          };
          trxUserData.push(newTransaction);
          fs.writeFileSync(trxFilePath, JSON.stringify(trxUserData, null, 2), 'utf8');
      }
    })
    .catch(error => {
      if (error.response) {
            console.log(error.response.data.data)
                sett("+saldo", ru + "@s.whatsapp.net", total_tagihan);
                reply("Oops, Sistem Overload Tunggu beberapa saat lagi")
                AnanthaGanz.sendMessage(`${owner}@s.whatsapp.net`, { text: `Oops, ${String(error.response.data.data.message)}` });
            }
    });
}
break;
case 'prabayar': {
if (cek("verfiyemail", m.sender) == true) return reply(`Oops, Silahkan Daftarkan Email anda\nContoh : .setemail xxxxx@gmail.com`);
    if (cek("cekVerify", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, `Oops, Silahkan Verifikasi Email : ${cek("email", m.sender)}`, ['Verifikasicode','Hubungi Admin']);
if(cek("syarat", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, 'Oops, Kamu Belum Menyetujui Syarat Ketentuan dari kami. Mohon setujuin dulu, agar dapat mengakses fitur dari kami.', ['Saya Setuju','Syarat nya apa aja']);
  // 📚 Baca data customer_kode dari file JSON
  const dataProduk = JSON.parse(fs.readFileSync('./SETTING/DB/datadigiflaz.json', 'utf8'));
  
  // 💼 Jika ada pengirim
  if (from) {
    // 📋 Ambil kategori unik dan urutkan
    const kategori = Array.from(new Set(dataProduk.map(item => item.kategori))).sort();
    
    // 📝 Siapkan pesan dengan nama pengirim
    const pesan = `Pilih dulu ya, ${pushname}. Pastikan sesuai yang kamu mau.`;
    
    // 📊 Kirim polling dengan opsi kategori yang telah ditentukan
    AnanthaGanz.sendPoll(from, pesan, ['E-Money', 'PLN', 'PULSA/DATA','GAME TOPUP','VOUCHER']);
  }
  break;
}
case 'pulsa/data':{
if (cek("verfiyemail", m.sender) == true) return reply(`Oops, Silahkan Daftarkan Email anda\nContoh : .setemail xxxxx@gmail.com`);
    if (cek("cekVerify", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, `Oops, Silahkan Verifikasi Email : ${cek("email", m.sender)}`, ['Verifikasicode','Hubungi Admin']);
AnanthaGanz.sendPoll(from, "Mau Beli Kuota Apa Nih?", ['Kuota/Data','PulsaReguler','PulsaTransfer','Voucher.']);
}
break
case 'kuota/data':{
if (cek("verfiyemail", m.sender) == true) return reply(`Oops, Silahkan Daftarkan Email anda\nContoh : .setemail xxxxx@gmail.com`);
    if (cek("cekVerify", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, `Oops, Silahkan Verifikasi Email : ${cek("email", m.sender)}`, ['Verifikasicode','Hubungi Admin']);
AnanthaGanz.sendPoll(from, "Mau Beli Kuota Apa Nih?", ['D-XL (DATA)', 'D-SMARTFREN (DATA)', 'D-TELKOMSEL (DATA)','D-TRI (DATA)','D-INDOSAT (DATA)','D-by.U (DATA)','D-AXIS (DATA)']);
}
break
case 'voucher.':{
if (cek("verfiyemail", m.sender) == true) return reply(`Oops, Silahkan Daftarkan Email anda\nContoh : .setemail xxxxx@gmail.com`);
    if (cek("cekVerify", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, `Oops, Silahkan Verifikasi Email : ${cek("email", m.sender)}`, ['Verifikasicode','Hubungi Admin']);
AnanthaGanz.sendPoll(from, "Mau Beli Voucher Apa Nih?", ['V-XL (VOUCHER)', 'V-SMARTFREN (VOUCHER)', 'V-TELKOMSEL (VOUCHER)','V-TRI (VOUCHER)','V-INDOSAT (VOUCHER)','V-by.U (VOUCHER)','V-AXIS (VOUCHER)']);
}
break
case 'pulsareguler':{
if (cek("verfiyemail", m.sender) == true) return reply(`Oops, Silahkan Daftarkan Email anda\nContoh : .setemail xxxxx@gmail.com`);
    if (cek("cekVerify", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, `Oops, Silahkan Verifikasi Email : ${cek("email", m.sender)}`, ['Verifikasicode','Hubungi Admin']);
AnanthaGanz.sendPoll(from, "Mau Beli Pulsa Apa Nih?", ['P-XL (PULSA)', 'P-SMARTFREN (PULSA)', 'P-TELKOMSEL (PULSA)','P-TRI (PULSA)','P-INDOSAT (PULSA)','P-by.U (PULSA)','P-AXIS (PULSA)']);
}
break
case 'pulsatransfer':{
if (cek("verfiyemail", m.sender) == true) return reply(`Oops, Silahkan Daftarkan Email anda\nContoh : .setemail xxxxx@gmail.com`);
    if (cek("cekVerify", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, `Oops, Silahkan Verifikasi Email : ${cek("email", m.sender)}`, ['Verifikasicode','Hubungi Admin']);
AnanthaGanz.sendPoll(from, "Mau Beli Pulsa Apa Nih?", ['T-XL (PULSATF)', 'T-SMARTFREN (PULSATF)', 'T-TELKOMSEL (PULSATF)','T-TRI (PULSATF)','T-INDOSAT (PULSATF)','T-by.U (PULSATF)','T-AXIS (PULSATF)']);
}
break
case 'listmember': {
    if (m.isGroup || !isOwner) return;

    // Membaca data anggota dari file JSON
    let listmemb = JSON.parse(fs.readFileSync('./SETTING/DB/user.json'));

    // Membaca data riwayat transaksi dari file JSON
    const trxFilePath = './SETTING/DB/trxuser.json';
    const trxFileData = fs.readFileSync(trxFilePath, 'utf8');
    const allTrxUserData = JSON.parse(trxFileData);

    // Membaca data riwayat deposit dari file JSON
    const depFilePath = './SETTING/DB/TRANSACTION/depouser.json';
    const depFileData = fs.readFileSync(depFilePath, 'utf8');
    const allDepUserData = JSON.parse(depFileData);

    // Mengurutkan anggota berdasarkan saldo
    listmemb.sort((a, b) => b.saldo - a.saldo);

    // Membuat pesan daftar anggota dengan format yang lebih sederhana
    let listmember1 = "*[ LIST MEMBER ]*\n\n";
    listmemb.forEach(member => {
        // Menghitung jumlah transaksi untuk anggota saat ini
        const memberTrxCount = allTrxUserData.filter(trx => trx.buyer === member.id).length;
        
        // Menghitung jumlah deposit untuk anggota saat ini
        const memberDepCount = allDepUserData.filter(dep => dep.buyer === member.id).length;

        // Menghasilkan UID sesuai dengan permintaan
        const UID = member.id.split('@')[0].replace('62', '0');

        // Cek status premium untuk setiap anggota
        

        listmember1 += `> ${UID}\nSaldo: ${formatmoney(member.saldo)}\nLevel : ${member.level}\nTransaksi: ${memberTrxCount}\nDeposit: ${memberDepCount}\n\n`;
    });            

    // Mengirim pesan dengan daftar anggota yang sudah diformat
    reply(listmember1);
}
break;
case 'cekmember': {
    if (m.isGroup || !isOwner) return;

    // Membaca data anggota dari file JSON
    let listmemb = JSON.parse(fs.readFileSync('./SETTING/DB/user.json'));

    // Mengambil ID anggota yang ingin diperiksa
    let pelanggan = q.split(" ")[0];
    let hasil = pelanggan + "@s.whatsapp.net";
    const memberId = hasil;
    if (!pelanggan) {
        reply("Format yang benar: .cekmember 6285174667722");
        return;
    }
    
    // Menyesuaikan format nomor jika dimulai dengan 0
    if (pelanggan.startsWith('0')) {
        pelanggan = '62' + pelanggan.substring(1); // Mengubah nomor yang dimulai dengan 0 menjadi 62
        reply("Pastikan untuk menggunakan nomor yang dimulai dengan 62 untuk memeriksa anggota.");
    }

    // Mencari anggota berdasarkan ID
    const member = listmemb.find(m => m.id === memberId);

    if (member !== undefined) {
        // Membaca data riwayat transaksi dari file JSON
        const trxFilePath = './SETTING/DB/trxuser.json';
        const trxFileData = fs.readFileSync(trxFilePath, 'utf8');
        const allTrxUserData = JSON.parse(trxFileData);

        // Membaca data riwayat deposit dari file JSON
        const depFilePath = './SETTING/DB/TRANSACTION/depouser.json';
        const depFileData = fs.readFileSync(depFilePath, 'utf8');
        const allDepUserData = JSON.parse(depFileData);

        // Menghitung jumlah transaksi untuk anggota saat ini
        const memberTrxCount = allTrxUserData.filter(trx => trx.buyer === memberId).length;

        // Menghitung jumlah deposit untuk anggota saat ini
        const memberDepCount = allDepUserData.filter(dep => dep.buyer === memberId).length;

        // Menghasilkan UID sesuai dengan permintaan
        const UID = memberId.split('@')[0].replace('62', '0');

        // Format pesan dengan detail anggota
        const memberDetails = ` *MEMBER DETAILS* \n\n> UID : ${UID}\n> Saldo : ${formatmoney(member.saldo)}\n> Level : ${member.level}\n> Email : ${member.email}\n> Jumlah Transaksi : ${memberTrxCount}\n> Jumlah Deposit : ${memberDepCount}`;

        // Mengirim pesan dengan detail anggota
        reply(memberDetails);
    } else {
        reply("Anggota dengan ID tersebut tidak ditemukan.");
    }
    break;
}
case 'cektrx': {
    let refId = q.split(" ")[0]; // Menyimpan ref_id yang ingin diperiksa

    if (!refId) {
        reply("Kamu belum memasukkan ref_id yang ingin diperiksa.\n\nContoh : cektrx ZNxxxxx");
        return;
    }

    const filePath = './SETTING/DB/trxuser.json';
    try {
        const fileData = fs.readFileSync(filePath, 'utf8');
        const allUserData = JSON.parse(fileData);

        const userData = allUserData.find(data => data.ref_id === refId); // Mencari transaksi berdasarkan refId

        if (!userData) {
            return reply(`Transaksi dengan *${refId}* ini tidak ditemukan.`);
        }

        let totalHarga = parseFloat(userData.harga);
        let totale = totalHarga * 1;

        const replyMessage = `
*RIWAYAT TRANSAKSI* 

> Produk : ${userData.produk}
> ID Trx : ${userData.ref_id}
> Tujuan : ${userData.tujuan}
> Harga : ${formatmoney(totale)}
> Status : Succes
> Waktu : ${userData.jam} | ${userData.waktu}
> Catatan : ${userData.invoice}
`;

        reply(replyMessage);
    } catch (error) {
        console.error('Error reading the transaction history file:', error);
        reply("Gagal, Ada Masalah Ketika Membaca data, silahkan hubungi Admin");
    }
    break;
}
case 'cekriwayattrx': {
    let pelanggan = q.split(" ")[0];
    let hasil = pelanggan + "@s.whatsapp.net";
    let userId = hasil; // ID pengguna yang ingin diperiksa riwayat transaksinya

    if (!userId) {
        reply("Kamu belum memasukkan ID pengguna yang ingin diperiksa.\n\nContoh : cekriwayattrx 6285174667722");
        return;
    }

    if (userId.startsWith('0')) {
        userId = '62' + userId.substring(1); // Mengubah nomor yang dimulai dengan 0 menjadi 62
        reply("Pastikan untuk menggunakan nomor yang dimulai dengan 62 untuk memeriksa riwayat transaksinya");
    }

    const filePath = './SETTING/DB/trxuser.json';
    try {
        const fileData = fs.readFileSync(filePath, 'utf8');
        const allUserData = JSON.parse(fileData);

        const userData = allUserData.filter(data => data.buyer === userId);

        if (userData.length === 0) {
            return reply("Pengguna ini belum memiliki riwayat transaksi yang sukses.");
        }

        let totalHarga = 0;
        let totalTransactions = userData.length;

        userData.forEach(data => {
            totalHarga += parseFloat(data.harga);
        });

        const historyText = userData.map((data, index) => {
            let totale = data.harga * 1;
            return `
  Trx - ${index + 1}:
> Produk : ${data.produk}
> ID Trx : ${data.ref_id}
> Tujuan : ${data.tujuan}
> Harga : ${formatmoney(totale)}
> Status : Succes
> Waktu : ${data.jam} | ${data.waktu}
> Catatan : ${data.invoice}
`;
        });

        let totalw = totalHarga * 1;
        const replyMessage = `
*Riwayat Transaksi Pengguna* 

Total Pesanan : ${totalTransactions}
Total Harga Pesanan : ${formatmoney(totalw)}

${historyText.join('\n')}
`;

        reply(replyMessage);
    } catch (error) {
        console.error('Error reading the transaction history file:', error);
        reply("Gagal, Ada Masalah Ketika Membaca data, silahkan hubungi Admin");
    }
    break;
}
                    case 'pln': {
                    if (cek("verfiyemail", m.sender) == true) return reply(`Oops, Silahkan Daftarkan Email anda\nContoh : .setemail xxxxx@gmail.com`);
    if (cek("cekVerify", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, `Oops, Silahkan Verifikasi Email : ${cek("email", m.sender)}`, ['Verifikasicode','Hubungi Admin']);
                  if(cek("syarat", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, 'Oops, Kamu Belum Menyetujui Syarat Ketentuan dari kami. Mohon setujuin dulu, agar dapat mengakses fitur dari kami.', ['Saya Setuju','Syarat nya apa aja']);

    const productData = JSON.parse(fs.readFileSync('./SETTING/DB/datadigiflaz.json', 'utf8'));
    const requestedCategory = "PLN";
    const brands = [...new Set(productData.filter(item => item.category === requestedCategory).map(item => item.brand))];
    
    if (brands.length > 0) {
        AnanthaGanz.sendPoll(m.chat, "Pilih Varian Pln nya dulu Yuk! ⚡", ['List PLN','List2 PLN PASCABAYAR']);
    }
}
break;
                  
    case 'game': {
    if (cek("verfiyemail", m.sender) == true) return reply(`Oops, Silahkan Daftarkan Email anda\nContoh : .setemail xxxxx@gmail.com`);
    if (cek("cekVerify", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, `Oops, Silahkan Verifikasi Email : ${cek("email", m.sender)}`, ['Verifikasicode','Hubungi Admin']);
 if(cek("syarat", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, 'Oops, Kamu Belum Menyetujui Syarat Ketentuan dari kami. Mohon setujuin dulu, agar dapat mengakses fitur dari kami.', ['Saya Setuju','Syarat nya apa aja']);

    const productData = JSON.parse(fs.readFileSync('./SETTING/DB/datadigiflaz.json', 'utf8'));
    const requestedCategory = "Games";
    let brands = [...new Set(productData.filter(item => item.category === requestedCategory).map(item => item.brand))];
    
    // Acak urutan brand
    brands = brands.sort(() => Math.random() - 0.5);
    
    if (brands.length > 0) {
        let providerList = brands.slice(0, 11).map(brand => `List ${brand}`);
        
        // Tambahkan opsi "Game Lainnya"
        providerList.push("Game Lainnya");
        
        AnanthaGanz.sendPoll(m.chat, "Pilih Game Favorit mu & lakukan Top Up 📱", providerList);
    }
}
break;
case 'pdam.': {
    if (cek("verfiyemail", m.sender) == true) return reply(`Oops, Silahkan Daftarkan Email anda\nContoh : .setemail xxxxx@gmail.com`);
    if (cek("cekVerify", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, `Oops, Silahkan Verifikasi Email : ${cek("email", m.sender)}`, ['Verifikasicode','Hubungi Admin']);
    if (cek("syarat", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, 'Oops, Kamu Belum Menyetujui Syarat Ketentuan dari kami. Mohon setujuin dulu, agar dapat mengakses fitur dari kami.', ['Saya Setuju','Syarat nya apa aja']);

    const fs = require('fs');
    const productData = JSON.parse(fs.readFileSync('./SETTING/DB/pasca.json', 'utf8'));
    const requestedBrand = "PDAM";
    let desc = [...new Set(productData.filter(item => item.brand === requestedBrand).map(item => item.desc))];

    // Filter deskripsi yang bukan "-"
    desc = desc.filter(description => description !== "-");
    
    // Acak urutan deskripsi
    desc = desc.sort(() => Math.random() - 0.5);
    
    if (desc.length > 0) {
        let descList = desc.slice(0, 11).map(description => `PDAM ${description}`);
        
        // Tambahkan opsi "Deskripsi Lainnya"
        descList.push("Pdam. Lainnya");
        
        AnanthaGanz.sendPoll(m.chat, "Pilih PDAM Yang Kamu Inginkan", descList);
    }
}
break;
case 'voucher': {
if (cek("verfiyemail", m.sender) == true) return reply(`Oops, Silahkan Daftarkan Email anda\nContoh : .setemail xxxxx@gmail.com`);
    if (cek("cekVerify", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, `Oops, Silahkan Verifikasi Email : ${cek("email", m.sender)}`, ['Verifikasicode','Hubungi Admin']);
if(cek("syarat", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, 'Oops, Kamu Belum Menyetujui Syarat Ketentuan dari kami. Mohon setujuin dulu, agar dapat mengakses fitur dari kami.', ['Saya Setuju','Syarat nya apa aja']);
    const productData = JSON.parse(fs.readFileSync('./SETTING/DB/datadigiflaz.json', 'utf8'));
    const requestedCategory = "Voucher";
    let brands = [...new Set(productData.filter(item => item.category === requestedCategory).map(item => item.brand))];
    
    // Acak urutan brand
    brands = brands.sort(() => Math.random() - 0.5);
    
    if (brands.length > 0) {
        let providerList = brands.slice(0, 11).map(brand => `List ${brand}`);
        
        // Tambahkan opsi "Game Lainnya"
        providerList.push("Voucher Lainnya");
        
        AnanthaGanz.sendPoll(m.chat, "Pilih Voucher Favorit mu & lakukan Top Up 📱", providerList);
    }
}
break;
          case 'e-money': {
          if (cek("verfiyemail", m.sender) == true) return reply(`Oops, Silahkan Daftarkan Email anda\nContoh : .setemail xxxxx@gmail.com`);
    if (cek("cekVerify", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, `Oops, Silahkan Verifikasi Email : ${cek("email", m.sender)}`, ['Verifikasicode','Hubungi Admin']);
        if(cek("syarat", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, 'Oops, Kamu Belum Menyetujui Syarat Ketentuan dari kami. Mohon setujuin dulu, agar dapat mengakses fitur dari kami.', ['Saya Setuju','Syarat nya apa aja']);
    const productData = JSON.parse(fs.readFileSync('./SETTING/DB/datadigiflaz.json', 'utf8'));
    const requestedCategory = "E-Money";
    const brands = [...new Set(productData.filter(item => item.category === requestedCategory).map(item => item.brand))];
    
    if (brands.length > 0) {
        const providerList = brands.map(brand => `List ${brand}`);
        providerList.push("Bebas Nominal");
        AnanthaGanz.sendPoll(m.chat, "Pilih E-Wallet yang Ingin Kamu Top Up 📱", providerList);
    }
}
break;
case 'bebas': {
if (cek("verfiyemail", m.sender) == true) return reply(`Oops, Silahkan Daftarkan Email anda\nContoh : .setemail xxxxx@gmail.com`);
    if (cek("cekVerify", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, `Oops, Silahkan Verifikasi Email : ${cek("email", m.sender)}`, ['Verifikasicode','Hubungi Admin']);
if(cek("syarat", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, 'Oops, Kamu Belum Menyetujui Syarat Ketentuan dari kami. Mohon setujuin dulu, agar dapat mengakses fitur dari kami.', ['Saya Setuju','Syarat nya apa aja']);
  if(cek("level", m.sender) == "Basic") return reply(`Oops, Fitur Ini Khusus Untuk Akun Premium! Silahkan Upgrade akun anda`)
    // Membaca data customer_kode dari file JSON yang disimpan sebelumnya
    const productData = JSON.parse(
        fs.readFileSync('./SETTING/DB/pasca.json', 'utf8')
    );
     let text = "E-MONEY"
    // Mengubah merek yang diminta menjadi huruf kecil untuk konsistensi
    const requestedBrand = text.toLowerCase();

    // Memeriksa apakah pengguna menyertakan merek customer_kode
    if (!requestedBrand) return m.reply("Bro, kasih tau gw merek produknya dong.");

    // Mencocokkan customer_kode berdasarkan merek yang diminta
    const matchingProducts = productData.filter(item => item.brand.toLowerCase() === requestedBrand);

    // Jika tidak ada customer_kode yang cocok dengan merek yang diminta, beri tahu pengguna
    if (matchingProducts.length === 0) {
        return m.reply(`Gak ada nih merek ${requestedBrand.toUpperCase()}, coba merek lain ya.`);
    }


    // Membuat respons yang diformat dengan baik berdasarkan customer_kode yang ditemukan
    let formattedResponse = `*List Produk ${requestedBrand.toUpperCase()}*\n\n`;
    matchingProducts.forEach(product => {
        const status = product.seller_product_status ? "Ready" : "Sold Out";
        const statusEmoji = product.seller_product_status ? "✅" : "❌";
       
        
        formattedResponse += `
≫ ${product.product_name}

> *Kode :* ${product.buyer_sku_code}
> *Status :* ${statusEmoji} ${status}
> *Deskripsi :* ${product.desc}
> *Cara Order :* Reply pesan ini dengan *${prefix}bebasnominal ${product.buyer_sku_code}|no_ewallet|nominal*

---------------------------------------
            
`;
    });

    // Mengirim pesan respons bersama dengan thumbnail dan tautan terkait
    AnanthaGanz.sendMessage(m.chat, {
        text: formattedResponse,
        contextInfo: {
            externalAdReply: {
                title: `${footer}`,
                thumbnailUrl: `https://i.ibb.co/0KGj27t/20240223-202951.jpg`,
                sourceUrl: `${grup}`,
                mediaType: 1,
                renderLargerThumbnail: true
            }
        }
    }, { quoted: fdocc });
}
break;
case 'pascabayar': {
    if (cek("verfiyemail", m.sender) == true) return reply(`Oops, Silahkan Daftarkan Email anda\nContoh : .setemail xxxxx@gmail.com`);
    if (cek("cekVerify", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, `Oops, Silahkan Verifikasi Email : ${cek("email", m.sender)}`, ['Verifikasicode','Hubungi Admin']);
    if(cek("syarat", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, 'Oops, Kamu Belum Menyetujui Syarat Ketentuan dari kami. Mohon setujuin dulu, agar dapat mengakses fitur dari kami.', ['Saya Setuju','Syarat nya apa aja']);
    
    const productData = JSON.parse(fs.readFileSync('./SETTING/DB/pasca.json', 'utf8'));
    const requestedCategory = "Pascabayar";
    let brands = [...new Set(productData.filter(item => item.category === requestedCategory && item.brand !== "E-MONEY" && item.brand !== "PDAM").map(item => item.brand))];
    
    // Acak urutan brand
    brands = brands.sort(() => Math.random() - 0.4);
    
    if (brands.length > 0) {
        let providerList = brands.slice(0, 4).map(brand => `List2 ${brand}`);
        
        // Tambahkan opsi "Game Lainnya"
        providerList.push("PDAM.");
        providerList.push("Cekpasca");
        providerList.push("Pascabayar Lainnya");
        
        AnanthaGanz.sendPoll(m.chat, "Silakan pilih Brand Pascabayar & lakukan cektagihan 📱", providerList);
    }
}
break;
     case 'list': {
     if (cek("verfiyemail", m.sender) == true) return reply(`Oops, Silahkan Daftarkan Email anda\nContoh : .setemail xxxxx@gmail.com`);
    if (cek("cekVerify", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, `Oops, Silahkan Verifikasi Email : ${cek("email", m.sender)}`, ['Verifikasicode','Hubungi Admin']);
 if(cek("syarat", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, 'Oops, Kamu Belum Menyetujui Syarat Ketentuan dari kami. Mohon setujuin dulu, agar dapat mengakses fitur dari kami.', ['Saya Setuju','Syarat nya apa aja']);
    // Membaca data customer_kode dari file JSON yang disimpan sebelumnya
    const productData = JSON.parse(
        fs.readFileSync('./SETTING/DB/datadigiflaz.json', 'utf8')
    );

    // Mengubah merek yang diminta menjadi huruf kecil untuk konsistensi
    const requestedBrand = text.toLowerCase();

    // Memeriksa apakah pengguna menyertakan merek customer_kode
    if (!requestedBrand) return m.reply("Oops, kamu belum input brand.");

    // Mencocokkan customer_kode berdasarkan merek yang diminta
    const matchingProducts = productData.filter(item => item.brand.toLowerCase() === requestedBrand);

    // Jika tidak ada customer_kode yang cocok dengan merek yang diminta, beri tahu pengguna
    if (matchingProducts.length === 0) {
        return m.reply(`Gak ada nih merek ${requestedBrand.toUpperCase()}, coba merek lain ya.`);
    }

    // Mengurutkan customer_kode berdasarkan harga
    matchingProducts.sort((a, b) => a.price - b.price);

    // Membuat respons yang diformat dengan baik berdasarkan customer_kode yang ditemukan
    let formattedResponse = `*===[ ${requestedBrand.toUpperCase()} ]===*\n\n> 🪀 24/7\n> ⚡ Proses Cepat\n> ✅ Garansi Uang Kembali\n> ✅ Aman & Terpercaya\n\n*© PT ZANNPAY INDONESIA*\n---------------------------------------\n`;
    matchingProducts.forEach(product => {
        const status = product.seller_product_status ? "Ready" : "Sold Out";
        const statusEmoji = product.seller_product_status ? "✅" : "❌";
        let stock_display = product.stock === 0 ? "∞" : product.stock;
        const priceFormatted = formatmoney(product.price);
        let produknya = `≫ *${product.product_name}*`
        formattedResponse += `
${produknya}

> Kode : ${product.buyer_sku_code}
> Status : ${statusEmoji} ${status}
> Harga : ${priceFormatted}
> Kategori : ${product.category}
> Tipe : ${product.type}
> Stock : ${stock_display}
> Deskripsi : ${product.desc}
> Cara Order : Reply pesan ini dengan *${prefix}order ${product.buyer_sku_code} <tujuan/userid/zone>*

---------------------------------------
`;
    });

    // Mengirim pesan respons bersama dengan thumbnail dan tautan terkait
    AnanthaGanz.sendMessage(m.chat, {
        text: formattedResponse,
        contextInfo: {
            externalAdReply: {
                title: `${footer}`,
                thumbnailUrl: `https://i.ibb.co/0KGj27t/20240223-202951.jpg`,
                sourceUrl: `${grup}`,
                mediaType: 1,
                renderLargerThumbnail: true
            }
        }
    }, { quoted: fdocc });
}
break;
  case 'pdam': {
    if (cek("verfiyemail", m.sender) == true) return reply(`Oops, Silahkan Daftarkan Email anda\nContoh : .setemail xxxxx@gmail.com`);
    if (cek("cekVerify", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, `Oops, Silahkan Verifikasi Email : ${cek("email", m.sender)}`, ['Verifikasicode','Hubungi Admin']);
    if(cek("syarat", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, 'Oops, Kamu Belum Menyetujui Syarat Ketentuan dari kami. Mohon setujuin dulu, agar dapat mengakses fitur dari kami.', ['Saya Setuju','Syarat nya apa aja']);
    
    // Membaca data customer_kode dari file JSON yang disimpan sebelumnya
    const productData = JSON.parse(
        fs.readFileSync('./SETTING/DB/pasca.json', 'utf8')
    );

    // Mengubah deskripsi yang diminta menjadi huruf kecil untuk konsistensi
    const requestedDesc = text.toLowerCase();

    // Memeriksa apakah pengguna menyertakan deskripsi produk
    if (!requestedDesc) return m.reply("Oops, kamu belum input deskripsi produk.");

    // Mencocokkan deskripsi produk dengan deskripsi yang diminta
    const matchingProducts = productData.filter(item => item.desc.toLowerCase().includes(requestedDesc));

    // Jika tidak ada produk yang cocok dengan deskripsi yang diminta, beri tahu pengguna
    if (matchingProducts.length === 0) {
        return m.reply(`Pdam Pada Wilayah  "${requestedDesc}" Tidak Tersedia `);
    }

    // Membuat respons yang diformat dengan baik berdasarkan deskripsi produk yang ditemukan
    let formattedResponse = `*PDAM ${requestedDesc}*\n\n`;
    matchingProducts.forEach(product => {
        const status = product.seller_product_status ? "Ready" : "Sold Out";
        const statusEmoji = product.seller_product_status ? "✅" : "❌";
        
        formattedResponse += `
≫ ${product.product_name}

> *Kode :* ${product.buyer_sku_code}
> *Status :* ${statusEmoji} ${status}
> *Deskripsi :* ${product.desc}
> *Cara Order :* Reply pesan ini dengan *${prefix}cektagihan ${product.buyer_sku_code} <id_pelanggan>*

---------------------------------------
`;
    });

    // Mengirim pesan respons bersama dengan thumbnail dan tautan terkait
    AnanthaGanz.sendMessage(m.chat, {
        text: formattedResponse,
        contextInfo: {
            externalAdReply: {
                title: `${footer}`,
                thumbnailUrl: `https://i.ibb.co/0KGj27t/20240223-202951.jpg`,
                sourceUrl: `${grup}`,
                mediaType: 1,
                renderLargerThumbnail: true
            }
        }
    }, { quoted: fdocc });
}
break;
case 'list2': {
if (cek("verfiyemail", m.sender) == true) return reply(`Oops, Silahkan Daftarkan Email anda\nContoh : .setemail xxxxx@gmail.com`);
    if (cek("cekVerify", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, `Oops, Silahkan Verifikasi Email : ${cek("email", m.sender)}`, ['Verifikasicode','Hubungi Admin']);
if(cek("syarat", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, 'Oops, Kamu Belum Menyetujui Syarat Ketentuan dari kami. Mohon setujuin dulu, agar dapat mengakses fitur dari kami.', ['Saya Setuju','Syarat nya apa aja']);
    // Membaca data customer_kode dari file JSON yang disimpan sebelumnya
    const productData = JSON.parse(
        fs.readFileSync('./SETTING/DB/pasca.json', 'utf8')
    );

    // Mengubah merek yang diminta menjadi huruf kecil untuk konsistensi
    const requestedBrand = text.toLowerCase();

    // Memeriksa apakah pengguna menyertakan merek customer_kode
    if (!requestedBrand) return m.reply("Oops, kamu belum input brand.");

    // Mencocokkan customer_kode berdasarkan merek yang diminta
    const matchingProducts = productData.filter(item => item.brand.toLowerCase() === requestedBrand);

    // Jika tidak ada customer_kode yang cocok dengan merek yang diminta, beri tahu pengguna
    if (matchingProducts.length === 0) {
        return m.reply(`Gak ada nih merek ${requestedBrand.toUpperCase()}, coba merek lain ya.`);
    }


    // Membuat respons yang diformat dengan baik berdasarkan customer_kode yang ditemukan
    let formattedResponse = `*List Produk ${requestedBrand.toUpperCase()}*\n\n`;
    matchingProducts.forEach(product => {
        const status = product.seller_product_status ? "Ready" : "Sold Out";
        const statusEmoji = product.seller_product_status ? "✅" : "❌";
       
        
        formattedResponse += `
≫ ${product.product_name}

> *Kode :* ${product.buyer_sku_code}
> *Status :* ${statusEmoji} ${status}
> *Deskripsi :* ${product.desc}
> *Cara Order :* Reply pesan ini dengan *${prefix}cektagihan ${product.buyer_sku_code} <id_pelanggan>*

---------------------------------------
`;
    });

    // Mengirim pesan respons bersama dengan thumbnail dan tautan terkait
    AnanthaGanz.sendMessage(m.chat, {
        text: formattedResponse,
        contextInfo: {
            externalAdReply: {
                title: `${footer}`,
                thumbnailUrl: `https://i.ibb.co/0KGj27t/20240223-202951.jpg`,
                sourceUrl: `${grup}`,
                mediaType: 1,
                renderLargerThumbnail: true
            }
        }
    }, { quoted: fdocc });
}
break;
     
case 'ping':{
   const used = process.memoryUsage();
  const cpus = os.cpus().map(cpu => {
    cpu.total = Object.keys(cpu.times).reduce((last, type) => last + cpu.times[type], 0);
    return cpu;
  });

  const cpu = cpus.reduce((last, cpu, _, { length }) => {
    last.total += cpu.total;
    last.speed += cpu.speed / length;
    last.times.user += cpu.times.user;
    last.times.nice += cpu.times.nice;
    last.times.sys += cpu.times.sys;
    last.times.idle += cpu.times.idle;
    last.times.irq += cpu.times.irq;
    return last;
  }, {
    speed: 0,
    total: 0,
    times: {
      user: 0,
      nice: 0,
      sys: 0,
      idle: 0,
      irq: 0
    }
  });

  let timestamp = speed();
  let latensi = speed() - timestamp;
  neww = performance.now();
  oldd = performance.now();
     m.reply( `Kecepatan Respon :
${latensi.toFixed(4)} _Second_
${oldd - neww} _miliseconds_

Runtime : ${runtime(process.uptime())}

💻 Info Server
RAM: ${formatp(os.totalmem() - os.freemem())} / ${formatp(os.totalmem())}`)
}
break       


//FITUR OWNER         
function calculateSignature(username, apiKey, action) {
  return crypto.createHash('md5')
    .update(username + apiKey + action)
    .digest('hex');
}

case 'depoin': {
  let axios = require('axios')
  // Cek kalo lagi di grup, kalo iya, kasih tau kalo ini privat
  if (m.isGroup) return m.reply(mess.private);
  // Cek dulu, nih, kalo kamu bukan bos, ya udah bilang ke kamu kalo kamu bukan bos
  if (!isOwner) return m.reply(mess.owner);

  // Pisahin pesan berdasarkan titik
  const textParts = text.split(".");
  // Kalo ga ada 3 bagian, beri tahu cara menggunakan fitur ini
  if (textParts.length !== 3) {
    return m.reply(`*DEPO DIGIFLAZZ*\n\nNih caranya, tulis begini ya:\n\n.depoin [Jumlah Uang].[Nama Rekening].[Kode Bank]\n\nContoh:\n.depoin 200000.PT ZANNPAY INDONESIA.BRI\n\nKode Bank yang tersedia:\n- BCA\n- MANDIRI\n- BRI\n- BNI`);
  }

  // Ambil nilai nominal, nama rekening, dan kode bank dari pesan
  const [nominal, namaRekening, kodeBank] = textParts;

  // Kalo ada yang kosong, kasih tau cara benerinnya
  if (!nominal || !namaRekening || !kodeBank) {
    return m.reply(`*Deposit Yuk!*\n\nNih caranya, tulis begini ya:\n\n.depoin [Jumlah Uang].[Nama Rekening].[Kode Bank]\n\nContoh:\n.depoin 200000.PT ZANNPAY INDONESIA.BRI\n\nKode Bank yang tersedia:\n- BCA\n- MANDIRI\n- BRI\n- BNI`);
  }

  // Buat tanda tangan menggunakan username, API key, dan kata kunci "deposit"
  const signature = crypto.createHash('md5')
    .update(`${digiuser}${digiapi}deposit`)
    .digest('hex');

  // Ubah nominal ke format angka bulat
  const amount = parseInt(nominal);
  // Data yang akan dikirim ke API untuk deposit
  const requestData = {
    "username": String(digiuser),
    "amount": amount,
    "bank": String(kodeBank),
    "owner_name": String(namaRekening),
    "sign": String(signature)
  };

  // Konfigurasi untuk mengirim permintaan ke API
  const config = {
    method: 'POST',
    url: 'https://api.digiflazz.com/v1/deposit',
    data: requestData
  };

  // Kirim permintaan ke API Digiflazz
  axios(config)
    .then(async response => {
      m.reply(mess.wait);

      // Tanggapi balasan dari API
      const depositData = response.data.data;
      let rekening = depositData.rc;

      // Ubah nomor rekening sesuai dengan kode bank yang dipilih
      switch (kodeBank) {
        case 'BCA':
          rekening = '6042888890';
          break;
        case 'MANDIRI':
          rekening = '1550009910111';
          break;
        case 'BRI':
          rekening = '213501000291307';
          break;
        case 'BNI':
          rekening = '1996888992';
          break;
      }

      // Tunggu sebentar sebelum memberikan balasan
      setTimeout(() => {
        m.reply(`Yuk, Langsung aja transfer ke Rekening Digiflazz :\n\nRekening Bank ${kodeBank}: ${rekening}\n\nAtas Nama *DIGIFLAZZ INTERKONEKSI INDONESIA*\n\nTotal Deposit : Rp ${depositData.amount}\nCatatan : ${depositData.notes}`);
      }, 1000);
    })
    .catch(error => {
      // Tanggapan jika permintaan gagal
      if (error.response) {
        m.reply(`*Oops! Gagal nih!*\n\n› Pesan: ${String(error.response.data.data.message)}`);
      }
    });
  break;
}


case 'margin':
    if (m.isGroup) return m.reply(mess.private);
    if (!isOwner) return m.reply(mess.owner);

    const newData = JSON.parse(fs.readFileSync("./SETTING/DB/untung.json"));

    if (text) {
        const newMargin = text.split(" ")[0]
        if (isNaN(newMargin)) {
            return reply("Format salah, bro. Harusnya : margin <nilai_margin>");
        }

        newData[0].keuntungan = newMargin;

        // Simpan ke file JSON
        fs.writeFileSync('./SETTING/DB/untung.json', JSON.stringify(newData));
        reply(`Yeay, harga produk udah disetel jadi ${newMargin}%`);

        // Delay antara setiap pemanggilan fungsi untuk memberikan jeda waktu   
        setTimeout(() => {
            const updd = JSON.parse(fs.readFileSync("./SETTING/DB/untung.json"));
            let up = updd[0].keuntungan;
            getProduk(digiuser, digiapi, up);
        }, 1000); // Jeda 1 detik
        setTimeout(() => {
            const updd = JSON.parse(fs.readFileSync("./SETTING/DB/untung.json"));
            let up3 = updd[0].keuntungan;
            getPasca(digiuser, digiapi, up3);
        }, 6000); // Jeda 3 detik 
        setTimeout(() => {
            const updd = JSON.parse(fs.readFileSync("./SETTING/DB/untung.json"));
            let up2 = updd[0].keuntungan;
            getHarga(digiuser, digiapi, up2);
        }, 8000); // Jeda 7 detik
    } else {
        const currentMargin = newData[0].keuntungan;
        reply(`Margin harga sekarang : ${currentMargin}%`);
    }
    break;
    case 'addharga': {
    if (!isOwner) return reply(mess.owner);
    const args = text.split(' ')[0];
    const args1 = text.split(' ')[1];
    if (!args || !args1) {
        reply(`Contoh: ${prefix}addharga <category> <price_increase>`);
        return;
    }
    const category = args;
    const priceIncrease = parseFloat(args1);
    if (isNaN(priceIncrease)) {
        reply("Gagal, Masukan Jumlah Harga Baru Untuk Ditambahkan");
        return;
    }
    let jsonData;
    try {
        jsonData = JSON.parse(fs.readFileSync('./SETTING/DB/datadigiflaz.json', 'utf8'));
    } catch (error) {
        reply("Error reading 'datadigiflaz.json': " + error.message);
        return;
    }
    let updated = false;
    let product;
    for (product of jsonData) {
        if (product.category === category) {
            // Menghitung penambahan harga dengan persentase
            const priceIncreasePercent = (priceIncrease / 100) * product.price;
            // Menambahkan harga dengan persentase
            product.price += priceIncreasePercent;
            updated = true;
        }
    }
    if (updated) {
        fs.writeFileSync('./SETTING/DB/datadigiflaz.json', JSON.stringify(jsonData, null, 2), 'utf8');
        reply(`Harga Semua Produk Dengan Category ${category} Sukses Diperbarui`);
    } else {
        reply(`Produk Dengan Category ${category} Tidak Ditemukan`);
    }

    break;
}
case 'addbrand': {
    if (!isOwner) return reply(mess.owner);
    const args = text.split('"')[1];
    const args1 = text.split('"')[2];
    if (!args || !args1) {
        reply(`Contoh: ${prefix}addharga "<brand>" <price_increase>`);
        return;
    }
    const brand = args;
    const priceIncrease = parseFloat(args1);
    if (isNaN(priceIncrease)) {
        reply("Gagal, Masukan Jumlah Harga Baru Untuk Ditambahkan");
        return;
    }
    let jsonData;
    try {
        jsonData = JSON.parse(fs.readFileSync('./SETTING/DB/datadigiflaz.json', 'utf8'));
    } catch (error) {
        reply("Error reading 'datadigiflaz.json': " + error.message);
        return;
    }
    let updated = false;
    for (let product of jsonData) {
        if (product.brand === brand) {
            // Menghitung penambahan harga dengan persentase
            const priceIncreaseAmount = (priceIncrease / 100) * product.price;
            // Menambahkan harga dengan persentase
            product.price += priceIncreaseAmount;
            updated = true;
        }
    }
    if (updated) {
        fs.writeFileSync('./SETTING/DB/datadigiflaz.json', JSON.stringify(jsonData, null, 2), 'utf8');
        reply(`Harga Semua Produk Dengan Brand "${brand}" Sukses Diperbarui`);
    } else {
        reply(`Produk Dengan Brand "${brand}" Tidak Ditemukan`);
    }

    break;
}
case 'update_all':
  if (m.isGroup || !isOwner) return m.reply(m.isGroup ? mess.private : mess.owner);
  const updateData = JSON.parse(fs.readFileSync("./SETTING/DB/untung.json"))[0].keuntungan;
  
  // Update data secara paralel dengan Promise.all()
  Promise.all([
    new Promise((resolve) => setTimeout(() => {
      getPasca(digiuser, digiapi, updateData);
      resolve();
    }, 2000)),
    new Promise((resolve) => setTimeout(() => {
      getProduk(digiuser, digiapi, updateData);
      resolve();
    }, 4000)), // Penundaan 2 detik dari sebelumnya
    new Promise((resolve) => setTimeout(() => {
      getHarga(digiuser, digiapi, updateData);
      resolve();
    }, 7000)), // Penundaan 3 detik dari sebelumnya
  ]).then(() => reply("Sip, Berhasil Update"));

  break;
case 'update_seller':
  if (m.isGroup) return m.reply(mess.private);
  if (!isOwner) return m.reply(mess.owner);

  const updateSeller = JSON.parse(fs.readFileSync("./SETTING/DB/untung.json"));
  let up = updateSeller[0].keuntungan;

  // Menunda pemanggilan fungsi getHarga selama 5 detik
  setTimeout(() => {
    getHarga(digiuser, digiapi, up);
    }, 5000); // Penundaan 5 detik
    reply("Sip, Berhasil Update Seller");

  break;

case 'update_prabayar':
 if (m.isGroup || !isOwner) return m.reply(m.isGroup ? mess.private : mess.owner);

  const updatePrabayar = JSON.parse(fs.readFileSync("./SETTING/DB/untung.json"));
  let up2 = updatePrabayar[0].keuntungan;

  // Menunda pemanggilan fungsi getProduk selama 5 detik
  setTimeout(() => {
    getProduk(digiuser, digiapi, up2);
      }, 10000); // Penundaan 5 detik
    reply("Sip, Berhasil Update Prabayar");
  break;

case 'update_pascabayar':
  if (m.isGroup) return m.reply(mess.private);
  if (!isOwner) return m.reply(mess.owner);

  const updatePasca = JSON.parse(fs.readFileSync("./SETTING/DB/untung.json"));
  let up3 = updatePasca[0].keuntungan;
  getPasca(digiuser, digiapi, up3);

  reply("Sip, Berhasil Update Pascabayar");
  break;
case 'balance': {
  if (m.isGroup || !isOwner) return m.reply(m.isGroup ? mess.private : mess.owner);

  const crypto = require("crypto");
  const axios = require("axios");
  const third = 'depo';
  const hash = crypto.createHash('md5').update(digiuser + digiapi + third).digest('hex');

  const config = {
    method: 'POST',
    url: 'https://api.digiflazz.com/v1/cek-saldo',
    data: {
      "cmd": "deposit",
      "username": digiuser,
      "sign": hash
    }
  };

  axios(config)
    .then(response => {
      if (response.data.data) {
        const profile = response.data.data;
        const df = `Saldo Digiflazz anda : *${formatmoney(profile.deposit)}*.`;
        m.reply(df);
      } else {
        console.log("Failed to get API data.");
      }
    })
    .catch(error => {
      console.error("Error:", error);
      console.log("Failed to make API request.");
    });
}
break;
case 'getbank':{
let axios = require('axios');
let apiUrl = `https://${global.apiNick}/listBank`;
let config = {
  headers: {
    'Content-Type': 'application/json', // Contoh header, sesuaikan dengan kebutuhan Anda
  }
};
axios.get(apiUrl, config)
  .then((response) => {
    let responseData = JSON.stringify(response.data.data);
    fs.writeFileSync("./SETTING/DB/data.json", responseData);
    reply("Sip, Berhasil get all bank")
    })
  .catch((error) => {
    console.error('Error:', error);
});
}
break 
/* API STALKING */
case 'cekbankid':{
if(cek("syarat", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, 'Oops, Kamu Belum Menyetujui Syarat Ketentuan dari kami. Mohon setujuin dulu, agar dapat mengakses fitur dari kami.', ['Saya Setuju','Syarat nya apa aja']);
if(cek("verfiyemail", m.sender) == true) return reply(`Oops, Silahkan Daftarkan Email anda\nContoh : .setemail xxxxx@gmail.com`)
let code_bank = q.split(" ")[0];
let no_bank = q.split(" ")[1];
if (!code_bank || !no_bank) {
          return reply(`BANK INDONESIA\n\nMasukan Kode bank dan rekening dengan benar, *Contoh :*\n.cekbankid 535 901341077047`)
        }
let axios = require('axios');
let apiUrl = `https://${global.apiNick}/getBankAccount?bankCode=${code_bank}&accountNumber=${no_bank}`;
let config = {
  headers: {
    'Content-Type': 'application/json', // Contoh header, sesuaikan dengan kebutuhan Anda
  }
};
axios.get(apiUrl, config)
  .then((response) => {
    let responseData = response.data;
    if (!responseData.data || !responseData.data.accountname) {
    reply("Oops, akun bank tidak ditemukan")
    }
    reply(`*${responseData.data.bankname}*\n\n> Nama Pemilik : ${responseData.data.accountname}\n> Nomor Rekening : ${responseData.data.accountnumber}\n> Kode Bank : ${responseData.data.bankcode}\n\n${toko}`)
})
  .catch((error) => {
    console.error('Error:', error);
});
}
break
case 'listbank': {
    if (cek("verifyemail", m.sender) === true) 
        return reply(`Oops, Silahkan Daftarkan Email Anda\nContoh: .setemail xxxxx@gmail.com`);
        
    if (cek("cekVerify", m.sender) === true) 
        return AnanthaGanz.sendPoll(m.chat, `Oops, Silahkan Verifikasi Email Anda: ${cek("email", m.sender)}`, ['Verifikasicode','Hubungi Admin']);
        
    if (cek("syarat", m.sender) === true) 
        return AnanthaGanz.sendPoll(m.chat, 'Oops, Anda Belum Menyetujui Syarat & Ketentuan Kami. Mohon setujuin terlebih dahulu untuk mengakses fitur kami.', ['Saya Setuju','Syaratnya Apa?']);
        
    let replyBank = "「 BANK INDONESIA 」\n";
    let dataBank = JSON.parse(fs.readFileSync('./SETTING/DB/data.json'));
    dataBank.forEach(function(product) {
        replyBank += `
${product.namaBank}\n> Kode Bank : ${product.kodeBank}\n`;
    });
    
    reply(`${replyBank}`);
    break;
}

 

      
      case 'manual.':{
      if (cek("verfiyemail", m.sender) == true) return reply(`Oops, Silahkan Daftarkan Email anda\nContoh : .setemail xxxxx@gmail.com`);
    if (cek("cekVerify", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, `Oops, Silahkan Verifikasi Email : ${cek("email", m.sender)}`, ['Verifikasicode','Hubungi Admin']);
if(cek("syarat", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, 'Oops, Kamu Belum Menyetujui Syarat Ketentuan dari kami. Mohon setujuin dulu, agar dapat mengakses fitur dari kami.', ['Saya Setuju','Syarat nya apa aja']);
AnanthaGanz.sendPoll(m.chat, "Nominal Cepat", ['MANUAL 50000','MANUAL 100000','MANUAL 200000','MANUAL 500000','MANUAL'])
}
break
case 'manual': {
if (cek("verfiyemail", m.sender) == true) return reply(`Oops, Silahkan Daftarkan Email anda\nContoh : .setemail xxxxx@gmail.com`);
    if (cek("cekVerify", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, `Oops, Silahkan Verifikasi Email : ${cek("email", m.sender)}`, ['Verifikasicode','Hubungi Admin']);
if(cek("syarat", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, 'Oops, Kamu Belum Menyetujui Syarat Ketentuan dari kami. Mohon setujuin dulu, agar dapat mengakses fitur dari kami.', ['Saya Setuju','Syarat nya apa aja']);
    // Mendapatkan nama pengirim
    let senderName = sender.split('@')[0];
if(fs.existsSync(`./SETTING/DB/TRANSACTION/Api/Deposit/${cek("deposit", m.sender)}.json`)) return AnanthaGanz.sendPoll(m.chat, `Oops, Kamu Sedang Memiliki Invoice ${cek("deposit", m.sender)}, apakah kamu ingin cancel?`, ['Cancel Aja','Hubungi Admin']);
    // Mendapatkan nominal deposit dari pesan pengguna
    let depositAmount = parseInt(q.split(" ")[0]);

    // Memeriksa apakah nominal deposit valid (berupa angka)
    if (isNaN(depositAmount)) {
        return reply("Oops, Masukkan Jumlah Deposit Yang Diinginkan");
    }

    // Memeriksa apakah nominal deposit telah dimasukkan
    if (!depositAmount) {
        return reply(`Oops, Cara Deposit Salah\n\nContoh : .manual 20000`);
    }

    // Memeriksa batasan minimal dan maksimal deposit
    if (depositAmount < 10000) {
        return m.reply(`Oops, minimal deposit 10.000`);
    }
    if (depositAmount > 2000000) {
        return m.reply(`Oops, maximal deposit 2 juta`);
    }

    // Membuat nomor referensi unik
    let referenceNumber = generateRandomString(3); // Fungsi generateRandomString disediakan
 let unikk = referenceNumber * 1
    // Menghitung jumlah pembayaran termasuk kode unik
    let totalPayment = depositAmount + referenceNumber * 1

    // Menyimpan data deposit ke dalam file JSON
    sett("deposit", m.sender, `${koderef}`)
    let depositData = {
        id: sender,
        ref: koderef,
        method: 'MANUAL',
        diterima: depositAmount,
        total: totalPayment,
        fee: 0,
        url: `https://wa.me${botNumber}?text=.menu`
    };
    fs.writeFileSync(`./SETTING/DB/TRANSACTION/Api/Deposit/${cek("deposit", m.sender)}.json`, JSON.stringify(depositData));
    loading();
    // Menyiapkan pesan informasi deposit
    let depositInfoMessage = `\n\n*DEPOSIT MANUAL* \n\n
› *Referensi :* ${koderef}\n
› *Berita Transfer :* ${beritatf}\n
› *Jumlah :* ${formatmoney(depositAmount)}\n
› *Unik Kode :* ${formatmoney(referenceNumber)}\n
› *Total Transfer :* ${formatmoney(totalPayment)}\n
=========================\n
*Pilih Metode Pembayaran :*\n
> QRIS : Silahkan Scan QR di atas\n
> OVO : 085174667722\n
> SHOPEEPAY : 085174667722\n
> GOPAY : 085174667722\n
> SEABANK : 901341077047\n
=========================\n
*Cara Melakukan Pembayaran* \n\n
1. Pilih Metode Pembayaran\n
2. Transfer Sesuai *${totalPayment}* Tanpa Pembulatan/Pengurangan\n
3. Masukkan *${beritatf}* Pada Kolom Catatan Transfer\n
4. Konfirmasi & Lanjutkan Pembayaran\n
5. Transfer Selesai, Tunggu 10 - 20 Menit\n
6. Saldo Berhasil Masuk\n

*NOTE !*\n
! Salah Memasukkan Nominal Transfer, Potong 10% ❌
! Jika Saldo Belum Masuk Sampai 1 Jam Silahkan Hubungi Admin
    `;

    // Mengirim pesan informasi deposit
    let qtt = { url: 'https://telegra.ph/file/df20236c41c3948b13f66.jpg' }
 AnanthaGanz.sendMessage(from,{image: qtt, caption: depositInfoMessage },  { quoted: m })
setTimeout(() => {
    let notif = `*Tiket Deposit Manual*\n\nHalo *${ownername}*,\nAda tiket deposit manual baru yang dibuat!\n\nDetail Tiket :\n> Member : ${senderName}\n> Referensi : ${koderef}\n> Berita Transfer : ${beritatf}\n> Jumlah : ${formatmoney(depositAmount)}\n> Kode Unik : ${referenceNumber}\n> Total Transfer : ${formatmoney(totalPayment)}\n\n> Waktu : ${moment.tz(`Asia/${global.Wilayah}`).format('HH:mm:ss')} | ${moment.tz(`Asia/${global.Wilayah}`).format('DD/MM/YY')}\n*JIKA KAMU MENERIMA UANG\n Silahkan Ketik :\n${prefix}accdepo ${senderName}\n\n${toko}`;
    AnanthaGanz.sendMessage(`${owner}@s.whatsapp.net`, { text: notif }, { quoted: m });
}, 7000);
    break;
}

    case 'qris.': {
    if (cek("verfiyemail", m.sender) == true) return reply(`Oops, Silahkan Daftarkan Email anda\nContoh : .setemail xxxxx@gmail.com`);
    if (cek("cekVerify", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, `Oops, Silahkan Verifikasi Email : ${cek("email", m.sender)}`, ['Verifikasicode','Hubungi Admin']);
    if(cek("syarat", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, 'Oops, Kamu Belum Menyetujui Syarat Ketentuan dari kami. Mohon setujuin dulu, agar dapat mengakses fitur dari kami.', ['Saya Setuju','Syarat nya apa aja']);
    AnanthaGanz.sendPoll(m.chat, "Nominal Cepat", ['QRISS 50000', 'QRISS 100000', 'QRISS 200000', 'QRISS 500000', 'QRISS']);
    break;
}

case 'deposit': {
if (cek("verfiyemail", m.sender) == true) return reply(`Oops, Silahkan Daftarkan Email anda\nContoh : .setemail xxxxx@gmail.com`);
    if (cek("cekVerify", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, `Oops, Silahkan Verifikasi Email : ${cek("email", m.sender)}`, ['Verifikasicode','Hubungi Admin']);
if(cek("syarat", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, 'Oops, Kamu Belum Menyetujui Syarat Ketentuan dari kami. Mohon setujuin dulu, agar dapat mengakses fitur dari kami.', ['Saya Setuju','Syarat nya apa aja']);
    AnanthaGanz.sendPoll(m.chat, "Silahkan Pilih Metode :", ['E-Wallet & Qris', 'Virtual Account [Premium]', 'Convenience Store', 'Manual.']);
    break;
}

case 'e-wallet': {
if (cek("verfiyemail", m.sender) == true) return reply(`Oops, Silahkan Daftarkan Email anda\nContoh : .setemail xxxxx@gmail.com`);
    if (cek("cekVerify", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, `Oops, Silahkan Verifikasi Email : ${cek("email", m.sender)}`, ['Verifikasicode','Hubungi Admin']);
if(cek("syarat", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, 'Oops, Kamu Belum Menyetujui Syarat Ketentuan dari kami. Mohon setujuin dulu, agar dapat mengakses fitur dari kami.', ['Saya Setuju','Syarat nya apa aja']);
    AnanthaGanz.sendPoll(m.chat, "Silahkan Pilih Metode :", ['Qris.', 'Dana.','LinkAja.','Shopeepay.']);
    break;
}

case 'convenience': {
if (cek("verfiyemail", m.sender) == true) return reply(`Oops, Silahkan Daftarkan Email anda\nContoh : .setemail xxxxx@gmail.com`);
    if (cek("cekVerify", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, `Oops, Silahkan Verifikasi Email : ${cek("email", m.sender)}`, ['Verifikasicode','Hubungi Admin']);
if(cek("syarat", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, 'Oops, Kamu Belum Menyetujui Syarat Ketentuan dari kami. Mohon setujuin dulu, agar dapat mengakses fitur dari kami.', ['Saya Setuju','Syarat nya apa aja']);
    AnanthaGanz.sendPoll(m.chat, "Silahkan Pilih Metode :", ['Alfamart', 'Indomaret']);
    break;
}
case 'virtual': {
if (cek("verfiyemail", m.sender) == true) return reply(`Oops, Silahkan Daftarkan Email anda\nContoh : .setemail xxxxx@gmail.com`);
    if (cek("cekVerify", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, `Oops, Silahkan Verifikasi Email : ${cek("email", m.sender)}`, ['Verifikasicode','Hubungi Admin']);
if(cek("syarat", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, 'Oops, Kamu Belum Menyetujui Syarat Ketentuan dari kami. Mohon setujuin dulu, agar dapat mengakses fitur dari kami.', ['Saya Setuju','Syarat nya apa aja']);
if(cek("level", m.sender) == "Basic") return reply(`Oops, Fitur Ini Khusus Untuk Akun Premium! Silahkan Upgrade akun anda`)
    AnanthaGanz.sendPoll(m.chat, "Silahkan Pilih Metode :", ['BCA VIRTUAL ACCOUNT', 'BNI VIRTUAL ACCOUNT', 'MANDIRI VIRTUAL ACCOUNT', 'BRI VIRTUAL ACCOUNT', 'BSI VIRTUAL ACCOUNT', 'NEO BANK VIRTUAL ACCOUNT', 'CIMB NIAGA VIRTUAL AKUN','PERMATA VIRTUAL ACCOUNT','DANAMON VIRTUAL ACCOUNT','MAYBANK VIRTUAL ACCOUNT']);
    break;
}
case 'alfamart': {
if (cek("verfiyemail", m.sender) == true) return reply(`Oops, Silahkan Daftarkan Email anda\nContoh : .setemail xxxxx@gmail.com`);
    if (cek("cekVerify", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, `Oops, Silahkan Verifikasi Email : ${cek("email", m.sender)}`, ['Verifikasicode','Hubungi Admin']);
if(cek("syarat", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, 'Oops, Kamu Belum Menyetujui Syarat Ketentuan dari kami. Mohon setujuin dulu, agar dapat mengakses fitur dari kami.', ['Saya Setuju','Syarat nya apa aja']);
    AnanthaGanz.sendPoll(m.chat, "Nominal Cepat", ['ALFA 50000', 'ALFA 100000', 'ALFA 200000', 'ALFA 500000', 'ALFA']);
    break;
}

case 'indomaret': {
if (cek("verfiyemail", m.sender) == true) return reply(`Oops, Silahkan Daftarkan Email anda\nContoh : .setemail xxxxx@gmail.com`);
    if (cek("cekVerify", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, `Oops, Silahkan Verifikasi Email : ${cek("email", m.sender)}`, ['Verifikasicode','Hubungi Admin']);
if(cek("syarat", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, 'Oops, Kamu Belum Menyetujui Syarat Ketentuan dari kami. Mohon setujuin dulu, agar dapat mengakses fitur dari kami.', ['Saya Setuju','Syarat nya apa aja']);
    AnanthaGanz.sendPoll(m.chat, "Nominal Cepat", ['INDO 50000', 'INDO 100000', 'INDO 200000', 'INDO 500000', 'INDO']);
    break;
}


case 'bayar': {
if (cek("verfiyemail", m.sender) == true) return reply(`Oops, Silahkan Daftarkan Email anda\nContoh : .setemail xxxxx@gmail.com`);
    if (cek("cekVerify", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, `Oops, Silahkan Verifikasi Email : ${cek("email", m.sender)}`, ['Verifikasicode','Hubungi Admin']);
if(cek("syarat", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, 'Oops, Kamu Belum Menyetujui Syarat Ketentuan dari kami. Mohon setujuin dulu, agar dapat mengakses fitur dari kami.', ['Saya Setuju','Syarat nya apa aja']);
    if (!fs.existsSync(`./SETTING/DB/TRANSACTION/Api/Deposit/${cek("deposit", m.sender)}.json`)) {
        AnanthaGanz.sendMessage(from, { text: "Oops! Sepertinya belum ada Invoice yang tersedia saat ini.." }, { quoted: m });
    } else {
        const depositData = JSON.parse(fs.readFileSync(`./SETTING/DB/TRANSACTION/Api/Deposit/${cek("deposit", m.sender)}.json`));
        const paymentUrl = checkIdDepo(m.sender, depositData) ? checkIdDepo(m.sender, depositData) : depositData.url;
        reply(`Sip, Ini Link Pembayaran Buat kamu & jangan lupa bayar tepat waktu ya!\n\n${paymentUrl} `);
    }
    break;
}

case 'qriss': {
if (cek("verfiyemail", m.sender) == true) return reply(`Oops, Silahkan Daftarkan Email anda\nContoh : .setemail xxxxx@gmail.com`);
    if (cek("cekVerify", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, `Oops, Silahkan Verifikasi Email : ${cek("email", m.sender)}`, ['Verifikasicode','Hubungi Admin']);
    if(cek("syarat", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, 'Oops, Kamu Belum Menyetujui Syarat Ketentuan dari kami. Mohon setujuin dulu, agar dapat mengakses fitur dari kami.', ['Saya Setuju','Syarat nya apa aja']);
let send = `${sender.split('@')[0]}`
  let axios = require('axios');
  let FormData = require('form-data');
  let md5 = require('md5');
let minimal = '100' * 1// SETT MIN DEPO
let max = '5000000' * 1 // SETT MAX DEPO
 if(fs.existsSync(`./SETTING/DB/TRANSACTION/Api/Deposit/${cek("deposit", m.sender)}.json`)) return AnanthaGanz.sendPoll(m.chat, `Oops, Kamu Sedang Memiliki Invoice ${cek("deposit", m.sender)}, apakah kamu ingin cancel?`, ['Cancel Aja','Hubungi Admin']);
let request_depo = q.split(" ")[0]
let total = `${request_depo}` * 1
      if (isNaN(request_depo)) {
        reply("Oops, deposit harus berupa angka bukan simbol/selain angka");
        return;
    }
if (!request_depo) return reply(`Oops, format salah, ikuti yang bener yuk :\n\nContoh: ${prefix + command} 5000`)
if (total < minimal) return m.reply(`Oops, minimal deposit adalah ${formatmoney(minimal)}`)
if (total > max) return m.reply(`Oops, Maximal deposit adalah ${formatmoney(max)}`)
  async function makePayment() {
    try {
      let keynya = global.key;
      let kodeunick = koderefe
      let paymetcod = '17';
      let aomut = total * 1;
      let exp = 1800;
      let create = keynya + kodeunick + paymetcod + aomut + exp + 'NewTransaction'
      let signature = md5(create);
      // Membuat data form untuk permintaan pembayaran
      var paymentData = new FormData();
      paymentData.append('key', keynya);
      paymentData.append('request', 'new');
      paymentData.append('merchant_id', '71');
      paymentData.append('unique_code', kodeunick);
      paymentData.append('service', paymetcod);
      paymentData.append('amount', aomut);
      paymentData.append('note', `PENAMBAHAN SALDO MEMBER ${pushname}`);
      paymentData.append('valid_time', exp);
      paymentData.append('customer_email', cek("email", m.sender));
      paymentData.append('type_fee', '1');
      paymentData.append('signature', signature); // Menggunakan signature yang telah dihitung

      // Konfigurasi untuk permintaan pembayaran
      var paymentConfig = {
        method: 'post',
        url: 'https://paydisini.co.id/api/',
        headers: { 
          ...paymentData.getHeaders()
        },
        data: paymentData
      };

      // Mengirim permintaan pembayaran
      let paymentResponse = await axios(paymentConfig);
            let paymentDataResponse = paymentResponse.data.data;
          let obj = { id: m.sender, ref: `${paymentDataResponse.unique_code}`, method : `${paymentDataResponse.service_name}`, diterima: `${paymentDataResponse.balance}`, total: `${paymentDataResponse.amount}`, fee: `${paymentDataResponse.fee}`, url: `${paymentDataResponse.checkout_url}` }
          sett("deposit", m.sender, `${paymentDataResponse.unique_code}`)
fs.writeFileSync(`./SETTING/DB/TRANSACTION/Api/Deposit/${cek("deposit", m.sender)}.json`, JSON.stringify(obj))
     await loading()
            let ccapt = ` QRIS OTOMATIS
            
> Metode : ${paymentDataResponse.service_name}
> Referensi : ${paymentDataResponse.unique_code}
> Berlaku : ${getExpirationTime()} menit
> Total Diterima : ${formatmoney(paymentDataResponse.balance)}
> Fee : ${formatmoney(paymentDataResponse.fee)}
> Total Bayar : ${formatmoney(paymentDataResponse.amount)}

Silahkan Lakukan Pembayaran Tepat Waktu`
AnanthaGanz.sendMessage(m.chat, { image: { url: `${paymentDataResponse.qrcode_url}` }, caption: ccapt })
setTimeout(() => {
const deppo = JSON.parse(fs.readFileSync(`./SETTING/DB/TRANSACTION/Api/Deposit/${cek("deposit", m.sender)}.json`))
               let method = `${checkIdDepo(m.sender, deppo) ? checkIdDepo(m.sender, deppo) : deppo.method}`
              let member = `${checkIdDepo(m.sender, deppo) ? checkIdDepo(m.sender, deppo) : deppo.id}`
                let price_sender = `${checkIdDepo(m.sender, deppo) ? checkIdDepo(m.sender, deppo) : deppo.diterima}` * 1
               let fee_sender = `${checkIdDepo(m.sender, deppo) ? checkIdDepo(m.sender, deppo) : deppo.fee}` * 1
               let ref_sender = `${checkIdDepo(m.sender, deppo) ? checkIdDepo(m.sender, deppo) : deppo.ref}` 
               let total_sender = `${checkIdDepo(m.sender, deppo) ? checkIdDepo(m.sender, deppo) : deppo.total}` * 1
               let url = `${checkIdDepo(m.sender, deppo) ? checkIdDepo(m.sender, deppo) : deppo.url}`
               sendEmailPending(sender, pushname, ref_sender, method, price_sender, fee_sender, total_sender, url);
               }, 2500);
let unick = paymentDataResponse.unique_code
function getExpirationTime() {
    const currentTime = new Date().getTime();
    const expirationTime = currentTime + (10 * 60 * 1000); // 30 menit kedepan
    const timeRemaining = Math.ceil((expirationTime - currentTime) / 60000); // Konversi ke menit dan dibulatkan ke atas
    return timeRemaining;
}
      // Memantau status pembayaran
      let dataStatus = paymentDataResponse.status;
      const startTime = new Date().getTime();
      while (dataStatus !== "Success") {
        await sleep(1000);
       let create3 = keynya + unick + 'StatusTransaction'
      let signature3 = md5(create3);
        var checkStatusData = new FormData();
        checkStatusData.append('key', keynya);
        checkStatusData.append('request', 'status');
        checkStatusData.append('unique_code', unick);
        checkStatusData.append('signature', signature3); 
        // Konfigurasi untuk memeriksa status pembayaran
        var checkStatusConfig = {
          method: 'post',
          url: 'https://paydisini.co.id/api/',
          headers: { 
            ...checkStatusData.getHeaders()
          },
          data: checkStatusData
        };
        // Mengirim permintaan untuk memeriksa status pembayaran
        let statusResponse = await axios(checkStatusConfig);
        let statusDataResponse = statusResponse.data.data;
        dataStatus = statusDataResponse.status;
        console.log(dataStatus);
        // Memeriksa waktu timeout
        const currentTime = new Date().getTime();
        const elapsedTime = (currentTime - startTime) / (1000 * 60 * 10);
              if (elapsedTime >= 1) {
              cancelPay();
              m.reply(`Upss, tiket ${cek("deposit", m.sender)} udah gak berlaku nih. Yuk, buat yang baru!`);
          break;
        }
        // Jika pembayaran berhasil
        if (dataStatus === "Success") {
          const deppo = JSON.parse(fs.readFileSync(`./SETTING/DB/TRANSACTION/Api/Deposit/${cek("deposit", m.sender)}.json`))
               let method = `${checkIdDepo(m.sender, deppo) ? checkIdDepo(m.sender, deppo) : deppo.method}`
              let member = `${checkIdDepo(m.sender, deppo) ? checkIdDepo(m.sender, deppo) : deppo.id}`
                let price_sender = `${checkIdDepo(m.sender, deppo) ? checkIdDepo(m.sender, deppo) : deppo.diterima}` * 1
               let fee_sender = `${checkIdDepo(m.sender, deppo) ? checkIdDepo(m.sender, deppo) : deppo.fee}` * 1
               let ref_sender = `${checkIdDepo(m.sender, deppo) ? checkIdDepo(m.sender, deppo) : deppo.ref}` 
               let total_sender = `${checkIdDepo(m.sender, deppo) ? checkIdDepo(m.sender, deppo) : deppo.total}` * 1
const depoFilepAth = './SETTING/DB/TRANSACTION/depouser.json';
    const depoUser = JSON.parse(fs.readFileSync(depoFilepAth, 'utf8'));
        const newDepo = {
            buyer: m.sender,
            status: "PAID",
            jam: moment.tz(`Asia/${global.Wilayah}`).format('HH:mm:ss'),
            waktu: moment.tz(`Asia/${global.Wilayah}`).format('DD/MM/YY'),
            no_pembayaran: `${ref_sender}`,
            method: `${method}`,
            jumlah: `${price_sender}`,
            fee: `${fee_sender}`,
            total: `${total_sender}`,
            
        };
            depoUser.push(newDepo);
    fs.writeFileSync(depoFilepAth, JSON.stringify(depoUser, null, 2), 'utf8');
    sendEmailDepo(sender, pushname, ref_sender, method, price_sender, fee_sender, total_sender);
                setTimeout(() => {
let notif = `Hai *${ownername}*,
Ada transaksi yang telah dibayar!

Member : ${dengan_nol}
Kode Unik : ${ref_sender}
Metode Pembayaran : ${method}
Jumlah Deposit : ${formatmoney(price_sender)}
Biaya Admin : ${formatmoney(fee_sender)}
Total Deposit : ${formatmoney(total_sender)}
Waktu : ${moment.tz(`Asia/${global.Wilayah}`).format('HH:mm:ss')} | ${moment.tz(`Asia/${global.Wilayah}`).format('DD/MM/YY')}

Detail transaksi dapat dilihat pada website https://paydisini.co.id/Riwayat-Transaksi/?status=&unique_code=${ref_sender}
`
AnanthaGanz.sendMessage(`${owner}@s.whatsapp.net`,{text: notif },  { quoted: m })
   }, 2000); // 2000 milliseconds (3 seconds)
                const capt = `*Pembayaran Berhasil*

Payment Details  :

› *Metode :* ${method}
› *Referensi :* ${ref_sender}
› *Jumlah :* ${formatmoney(price_sender)}
› *Fee :* ${formatmoney(fee_sender)}
› *Total :* ${formatmoney(total_sender)}

Information :
Pengisian saldo berhasil! Terima kasih atas transaksinya.

${toko}
`

AnanthaGanz.sendPoll(member, capt, ['Deposit Lagi','Hubungi Admin'])
                sett("+saldo", member, price_sender)           
                setTimeout(() => {
                fs.unlinkSync(`./SETTING/DB/TRANSACTION/Api/Deposit/${cek("deposit", m.sender)}.json`);
                }, 4000);
                setTimeout(() => {
    sett("deposit", m.sender, "")
                }, 6000);
                } else if (dataStatus === "Canceled") {
               console.log(`Berhasil! Ref ${cek("deposit", m.sender)} Dihapus`)
          break;
        }
      }
    } catch (error) {
      console.log(error);
    }
  }
  // Memanggil fungsi untuk melakukan pembayaran
  makePayment();
}
break;
case 'indo':
case 'alfa': {
if (cek("verfiyemail", m.sender) == true) return reply(`Oops, Silahkan Daftarkan Email anda\nContoh : .setemail xxxxx@gmail.com`);
    if (cek("cekVerify", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, `Oops, Silahkan Verifikasi Email : ${cek("email", m.sender)}`, ['Verifikasicode','Hubungi Admin']);
    if(cek("syarat", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, 'Oops, Kamu Belum Menyetujui Syarat Ketentuan dari kami. Mohon setujuin dulu, agar dapat mengakses fitur dari kami.', ['Saya Setuju','Syarat nya apa aja']);
let send = `${sender.split('@')[0]}`
  let axios = require('axios');
  let FormData = require('form-data');
  let md5 = require('md5');
let minimal = '15000' * 1// SETT MIN DEPO
let max = '2500000' * 1 // SETT MAX DEPO
 if(fs.existsSync(`./SETTING/DB/TRANSACTION/Api/Deposit/${cek("deposit", m.sender)}.json`)) return AnanthaGanz.sendPoll(m.chat, `Oops, Kamu Sedang Memiliki Invoice ${cek("deposit", m.sender)}, apakah kamu ingin cancel?`, ['Cancel Aja','Hubungi Admin']);
let request_depo = q.split(" ")[0]
let total = `${request_depo}` * 1
  if (isNaN(request_depo)) {
        reply("Oops, deposit harus berupa angka bukan simbol/selain angka");
        return;
    }
if (!request_depo) return reply(`Oops, format salah, ikuti yang bener yuk :\n\nContoh: ${prefix + command} 5000`)
if (total < minimal) return m.reply(`Oops, minimal deposit adalah ${formatmoney(minimal)}`)
if (total > max) return m.reply(`Oops, Maximal deposit adalah ${formatmoney(max)}`)
  async function makePayment() {
    try {
      let keynya = global.key;
     let kodeunick = koderefe
      let paymetcod;
     if (command === 'alfa') {
                paymetcod = '18'; // Ganti 'XX' dengan kode pembayaran Alfa yang sesuai
    } else if (command === 'indo') {
                paymetcod = '19'; // Ganti 'YY' dengan kode pembayaran Indo yang sesuai
            }
      let aomut = total * 1;
      let exp = 10800;
      let create = keynya + kodeunick + paymetcod + aomut + exp + 'NewTransaction'
      let signature = md5(create);
      // Membuat data form untuk permintaan pembayaran
      var paymentData = new FormData();
      paymentData.append('key', keynya);
      paymentData.append('request', 'new');
      paymentData.append('unique_code', kodeunick);
      paymentData.append('service', paymetcod);
      paymentData.append('amount', aomut);
      paymentData.append('note', `DEPOSIT ${pushname}`);
      paymentData.append('valid_time', exp);
      paymentData.append('customer_email', cek("email", m.sender));
      paymentData.append('type_fee', '1');
      paymentData.append('signature', signature); // Menggunakan signature yang telah dihitung

      // Konfigurasi untuk permintaan pembayaran
      var paymentConfig = {
        method: 'post',
        url: 'https://paydisini.co.id/api/',
        headers: { 
          ...paymentData.getHeaders()
        },
        data: paymentData
      };

      // Mengirim permintaan pembayaran
      let paymentResponse = await axios(paymentConfig);
      let paymentDataResponse = paymentResponse.data.data;
      let obj = { id: m.sender, ref: `${paymentDataResponse.unique_code}`, method : `${paymentDataResponse.service_name}`, diterima: `${paymentDataResponse.balance}`, total: `${paymentDataResponse.amount}`, fee: `${paymentDataResponse.fee}`, url: `${paymentDataResponse.checkout_url}` }
          sett("deposit", m.sender, `${paymentDataResponse.unique_code}`)
fs.writeFileSync(`./SETTING/DB/TRANSACTION/Api/Deposit/${cek("deposit", m.sender)}.json`, JSON.stringify(obj))
     await loading()
        let ccapt = `Convenience Store

> Metode : ${paymentDataResponse.service_name}
> Referensi : ${paymentDataResponse.unique_code}
> Berlaku : ${getExpirationTime()} menit
> Total Diterima : ${formatmoney(paymentDataResponse.balance)}
> Fee : ${formatmoney(paymentDataResponse.fee)}
> Total Pembayaran : ${formatmoney(paymentDataResponse.amount)}

Klik "Bayar Sekarang" untuk Melakukan Pembayaran`;
AnanthaGanz.sendPoll(m.chat, ccapt, ['Bayar Sekarang','Cancel Pembayaran']);
setTimeout(() => {
const deppo = JSON.parse(fs.readFileSync(`./SETTING/DB/TRANSACTION/Api/Deposit/${cek("deposit", m.sender)}.json`))
               let method = `${checkIdDepo(m.sender, deppo) ? checkIdDepo(m.sender, deppo) : deppo.method}`
              let member = `${checkIdDepo(m.sender, deppo) ? checkIdDepo(m.sender, deppo) : deppo.id}`
                let price_sender = `${checkIdDepo(m.sender, deppo) ? checkIdDepo(m.sender, deppo) : deppo.diterima}` * 1
               let fee_sender = `${checkIdDepo(m.sender, deppo) ? checkIdDepo(m.sender, deppo) : deppo.fee}` * 1
               let ref_sender = `${checkIdDepo(m.sender, deppo) ? checkIdDepo(m.sender, deppo) : deppo.ref}` 
               let total_sender = `${checkIdDepo(m.sender, deppo) ? checkIdDepo(m.sender, deppo) : deppo.total}` * 1
               let url = `${checkIdDepo(m.sender, deppo) ? checkIdDepo(m.sender, deppo) : deppo.url}`
               sendEmailPending(sender, pushname, ref_sender, method, price_sender, fee_sender, total_sender, url);
               }, 5000);
let unick = paymentDataResponse.unique_code
function getExpirationTime() {
    const currentTime = new Date().getTime();
    const expirationTime = currentTime + (3 * 60 * 60 * 60 * 1000); // 3 jam ke depan
    const timeRemaining = Math.ceil((expirationTime - currentTime) / (60 * 60 * 1000));// Konversi ke menit dan dibulatkan ke atas
    return timeRemaining;
}
      // Memantau status pembayaran
      let dataStatus = paymentDataResponse.status;
      const startTime = new Date().getTime();
      while (dataStatus !== "Success") {
        await sleep(1000);
       let create3 = keynya + unick + 'StatusTransaction'
      let signature3 = md5(create3);
        var checkStatusData = new FormData();
        checkStatusData.append('key', keynya);
        checkStatusData.append('request', 'status');
        checkStatusData.append('unique_code', unick);
        checkStatusData.append('signature', signature3); 
        // Konfigurasi untuk memeriksa status pembayaran
        var checkStatusConfig = {
          method: 'post',
          url: 'https://paydisini.co.id/api/',
          headers: { 
            ...checkStatusData.getHeaders()
          },
          data: checkStatusData
        };
        // Mengirim permintaan untuk memeriksa status pembayaran
        let statusResponse = await axios(checkStatusConfig);
        let statusDataResponse = statusResponse.data.data;
        dataStatus = statusDataResponse.status;
        console.log(dataStatus);
        // Memeriksa waktu timeout
        const currentTime = new Date().getTime();
              const elapsedTime = (currentTime - startTime) / (1000 * 60 * 60 * 3);
              if (elapsedTime >= 1) {
              m.reply(`Upss, tiket ${cek("deposit", m.sender)} udah gak berlaku nih. Yuk, buat yang baru!`);
              cancelPay();
          break;
        }
        // Jika pembayaran berhasil
        if (dataStatus === "Success") {
          const deppo = JSON.parse(fs.readFileSync(`./SETTING/DB/TRANSACTION/Api/Deposit/${cek("deposit", m.sender)}.json`))
               let method = `${checkIdDepo(m.sender, deppo) ? checkIdDepo(m.sender, deppo) : deppo.method}`
              let member = `${checkIdDepo(m.sender, deppo) ? checkIdDepo(m.sender, deppo) : deppo.id}`
                let price_sender = `${checkIdDepo(m.sender, deppo) ? checkIdDepo(m.sender, deppo) : deppo.diterima}` * 1
               let fee_sender = `${checkIdDepo(m.sender, deppo) ? checkIdDepo(m.sender, deppo) : deppo.fee}` * 1
               let ref_sender = `${checkIdDepo(m.sender, deppo) ? checkIdDepo(m.sender, deppo) : deppo.ref}` 
               let total_sender = `${checkIdDepo(m.sender, deppo) ? checkIdDepo(m.sender, deppo) : deppo.total}` * 1
const depoFilepAth = './SETTING/DB/TRANSACTION/depouser.json';
    const depoUser = JSON.parse(fs.readFileSync(depoFilepAth, 'utf8'));
        const newDepo = {
            buyer: m.sender,
            status: "PAID",
            jam: moment.tz(`Asia/${global.Wilayah}`).format('HH:mm:ss'),
            waktu: moment.tz(`Asia/${global.Wilayah}`).format('DD/MM/YY'),
            no_pembayaran: `${ref_sender}`,
            method: `${method}`,
            jumlah: `${price_sender}`,
            fee: `${fee_sender}`,
            total: `${total_sender}`,
            
        };
            depoUser.push(newDepo);
    fs.writeFileSync(depoFilepAth, JSON.stringify(depoUser, null, 2), 'utf8');
    sendEmailDepo(sender, pushname, ref_sender, method, price_sender, fee_sender, total_sender);
                setTimeout(() => {
let notif = `Hai *${ownername}*,
Ada transaksi yang telah dibayar!

Member : ${dengan_nol}
Kode Unik : ${ref_sender}
Metode Pembayaran : ${method}
Jumlah Deposit : ${formatmoney(price_sender)}
Biaya Admin : ${formatmoney(fee_sender)}
Total Deposit : ${formatmoney(total_sender)}
Waktu : ${moment.tz(`Asia/${global.Wilayah}`).format('HH:mm:ss')} | ${moment.tz(`Asia/${global.Wilayah}`).format('DD/MM/YY')}

Detail transaksi dapat dilihat pada website https://paydisini.co.id/Riwayat-Transaksi/?status=&unique_code=${ref_sender}
`
AnanthaGanz.sendMessage(`${owner}@s.whatsapp.net`,{text: notif },  { quoted: m })
   }, 2000); // 2000 milliseconds (3 seconds)
                const capt = `*Pembayaran Berhasil*

Payment Details  :

› *Metode :* ${method}
› *Referensi :* ${ref_sender}
› *Jumlah :* ${formatmoney(price_sender)}
› *Fee :* ${formatmoney(fee_sender)}
› *Total :* ${formatmoney(total_sender)}

Information :
Pengisian saldo berhasil! Terima kasih atas transaksinya.

${toko}
`

AnanthaGanz.sendPoll(member, capt, ['Deposit Lagi','Hubungi Admin'])
                sett("+saldo", member, price_sender)           
                setTimeout(() => {
                fs.unlinkSync(`./SETTING/DB/TRANSACTION/Api/Deposit/${cek("deposit", m.sender)}.json`);
                }, 4000);
                setTimeout(() => {
    sett("deposit", m.sender, "")
                }, 6000);
                } else if (dataStatus === "Canceled") {
               console.log(`Berhasil! Ref ${cek("deposit", m.sender)} Dihapus`)
          break;
        }
      }
    } catch (error) {
      console.log(error);
    }
  }
  // Memanggil fungsi untuk melakukan pembayaran
  makePayment();
}
break;
case 'bsi':{
if (cek("verfiyemail", m.sender) == true) return reply(`Oops, Silahkan Daftarkan Email anda\nContoh : .setemail xxxxx@gmail.com`);
    if (cek("cekVerify", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, `Oops, Silahkan Verifikasi Email : ${cek("email", m.sender)}`, ['Verifikasicode','Hubungi Admin']);
    if(cek("syarat", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, 'Oops, Kamu Belum Menyetujui Syarat Ketentuan dari kami. Mohon setujuin dulu, agar dapat mengakses fitur dari kami.', ['Saya Setuju','Syarat nya apa aja']);
AnanthaGanz.sendPoll(m.chat, "Nominal Cepat", ['BSIVA 50000','BSIVA 100000','BSIVA 200000','BSIVA 500000','BSIVA'])
}
break
case 'bni':{
if (cek("verfiyemail", m.sender) == true) return reply(`Oops, Silahkan Daftarkan Email anda\nContoh : .setemail xxxxx@gmail.com`);
    if (cek("cekVerify", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, `Oops, Silahkan Verifikasi Email : ${cek("email", m.sender)}`, ['Verifikasicode','Hubungi Admin']);
    if(cek("syarat", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, 'Oops, Kamu Belum Menyetujui Syarat Ketentuan dari kami. Mohon setujuin dulu, agar dapat mengakses fitur dari kami.', ['Saya Setuju','Syarat nya apa aja']);
AnanthaGanz.sendPoll(m.chat, "Nominal Cepat", ['BNIVA 50000','BNIVA 100000','BNIVA 200000','BNIVA 500000','BNIVA'])
}
break
case 'mandiri':{
if (cek("verfiyemail", m.sender) == true) return reply(`Oops, Silahkan Daftarkan Email anda\nContoh : .setemail xxxxx@gmail.com`);
    if (cek("cekVerify", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, `Oops, Silahkan Verifikasi Email : ${cek("email", m.sender)}`, ['Verifikasicode','Hubungi Admin']);
    if(cek("syarat", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, 'Oops, Kamu Belum Menyetujui Syarat Ketentuan dari kami. Mohon setujuin dulu, agar dapat mengakses fitur dari kami.', ['Saya Setuju','Syarat nya apa aja']);
AnanthaGanz.sendPoll(m.chat, "Nominal Cepat", ['MANDIRIVA 50000','MANDIRIVA 100000','MANDIRIVA 200000','MANDIRIVA 500000','MANDIRIVA'])
}
break
case 'bca':{
if (cek("verfiyemail", m.sender) == true) return reply(`Oops, Silahkan Daftarkan Email anda\nContoh : .setemail xxxxx@gmail.com`);
    if (cek("cekVerify", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, `Oops, Silahkan Verifikasi Email : ${cek("email", m.sender)}`, ['Verifikasicode','Hubungi Admin']);
    if(cek("syarat", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, 'Oops, Kamu Belum Menyetujui Syarat Ketentuan dari kami. Mohon setujuin dulu, agar dapat mengakses fitur dari kami.', ['Saya Setuju','Syarat nya apa aja']);
AnanthaGanz.sendPoll(m.chat, "Nominal Cepat", ['BCAVA 50000','BCAVA 100000','BCAVA 200000','BCAVA 500000','BCAVA'])
}
break
case 'maybank':{
if (cek("verfiyemail", m.sender) == true) return reply(`Oops, Silahkan Daftarkan Email anda\nContoh : .setemail xxxxx@gmail.com`);
    if (cek("cekVerify", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, `Oops, Silahkan Verifikasi Email : ${cek("email", m.sender)}`, ['Verifikasicode','Hubungi Admin']);
    if(cek("syarat", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, 'Oops, Kamu Belum Menyetujui Syarat Ketentuan dari kami. Mohon setujuin dulu, agar dapat mengakses fitur dari kami.', ['Saya Setuju','Syarat nya apa aja']);
AnanthaGanz.sendPoll(m.chat, "Nominal Cepat", ['MAYBANKVA 50000','MAYBANKVA 100000','MAYBANKVA 200000','MAYBANKVA 500000','MAYBANKVA'])
}
break
case 'bri':{
if (cek("verfiyemail", m.sender) == true) return reply(`Oops, Silahkan Daftarkan Email anda\nContoh : .setemail xxxxx@gmail.com`);
    if (cek("cekVerify", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, `Oops, Silahkan Verifikasi Email : ${cek("email", m.sender)}`, ['Verifikasicode','Hubungi Admin']);
    if(cek("syarat", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, 'Oops, Kamu Belum Menyetujui Syarat Ketentuan dari kami. Mohon setujuin dulu, agar dapat mengakses fitur dari kami.', ['Saya Setuju','Syarat nya apa aja']);
AnanthaGanz.sendPoll(m.chat, "Nominal Cepat", ['BRIVA 50000','BRIVA 100000','BRIVA 200000','BRIVA 500000','BRIVA'])
}
break
case 'cimb':{
if (cek("verfiyemail", m.sender) == true) return reply(`Oops, Silahkan Daftarkan Email anda\nContoh : .setemail xxxxx@gmail.com`);
    if (cek("cekVerify", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, `Oops, Silahkan Verifikasi Email : ${cek("email", m.sender)}`, ['Verifikasicode','Hubungi Admin']);
    if(cek("syarat", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, 'Oops, Kamu Belum Menyetujui Syarat Ketentuan dari kami. Mohon setujuin dulu, agar dapat mengakses fitur dari kami.', ['Saya Setuju','Syarat nya apa aja']);
AnanthaGanz.sendPoll(m.chat, "Nominal Cepat", ['CIMBVA 50000','CIMBVA 100000','CIMBVA 200000','CIMBVA 500000','CIMBVA'])
}
break
case 'neo':{
if (cek("verfiyemail", m.sender) == true) return reply(`Oops, Silahkan Daftarkan Email anda\nContoh : .setemail xxxxx@gmail.com`);
    if (cek("cekVerify", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, `Oops, Silahkan Verifikasi Email : ${cek("email", m.sender)}`, ['Verifikasicode','Hubungi Admin']);
    if(cek("syarat", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, 'Oops, Kamu Belum Menyetujui Syarat Ketentuan dari kami. Mohon setujuin dulu, agar dapat mengakses fitur dari kami.', ['Saya Setuju','Syarat nya apa aja']);
AnanthaGanz.sendPoll(m.chat, "Nominal Cepat", ['BNCVA 50000','BNCVA 100000','BNCVA 200000','BNCVA 500000','BNCVA'])
}
break
case 'danamon':{
if (cek("verfiyemail", m.sender) == true) return reply(`Oops, Silahkan Daftarkan Email anda\nContoh : .setemail xxxxx@gmail.com`);
    if (cek("cekVerify", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, `Oops, Silahkan Verifikasi Email : ${cek("email", m.sender)}`, ['Verifikasicode','Hubungi Admin']);
    if(cek("syarat", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, 'Oops, Kamu Belum Menyetujui Syarat Ketentuan dari kami. Mohon setujuin dulu, agar dapat mengakses fitur dari kami.', ['Saya Setuju','Syarat nya apa aja']);
AnanthaGanz.sendPoll(m.chat, "Nominal Cepat", ['DANAMONVA 50000','DANAMONVA 100000','DANAMONVA 200000','DANAMONVA 500000','DANAMONVA'])
}
break
case 'permata':{
if (cek("verfiyemail", m.sender) == true) return reply(`Oops, Silahkan Daftarkan Email anda\nContoh : .setemail xxxxx@gmail.com`);
    if (cek("cekVerify", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, `Oops, Silahkan Verifikasi Email : ${cek("email", m.sender)}`, ['Verifikasicode','Hubungi Admin']);
    if(cek("syarat", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, 'Oops, Kamu Belum Menyetujui Syarat Ketentuan dari kami. Mohon setujuin dulu, agar dapat mengakses fitur dari kami.', ['Saya Setuju','Syarat nya apa aja']);
AnanthaGanz.sendPoll(m.chat, "Nominal Cepat", ['PERMATAVA 50000','PERMATAVA 100000','PERMATAVA 200000','PERMATAVA 500000','PERMATAVA'])
}
break
case 'cimbva':
case 'briva':
case 'bniva':
case 'bncva':
case 'bcava':
case 'bsiva':
case 'danamonva':
case 'permatava':
case 'maybankva':
case 'mandiriva': {
if (cek("verfiyemail", m.sender) == true) return reply(`Oops, Silahkan Daftarkan Email anda\nContoh : .setemail xxxxx@gmail.com`);
    if (cek("cekVerify", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, `Oops, Silahkan Verifikasi Email : ${cek("email", m.sender)}`, ['Verifikasicode','Hubungi Admin']);
    if(cek("syarat", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, 'Oops, Kamu Belum Menyetujui Syarat Ketentuan dari kami. Mohon setujuin dulu, agar dapat mengakses fitur dari kami.', ['Saya Setuju','Syarat nya apa aja']);
let send = `${sender.split('@')[0]}`
  let axios = require('axios');
  let FormData = require('form-data');
  let md5 = require('md5');
let minimal = '10000' * 1// SETT MIN DEPO
let max = '5000000' * 1 // SETT MAX DEPO
if(fs.existsSync(`./SETTING/DB/TRANSACTION/Api/Deposit/${cek("deposit", m.sender)}.json`)) return AnanthaGanz.sendPoll(m.chat, `Oops, Kamu Sedang Memiliki Invoice ${cek("deposit", m.sender)}, apakah kamu ingin cancel?`, ['Cancel Aja','Hubungi Admin']);
let request_depo = q.split(" ")[0]
let total = `${request_depo}` * 1
    if (isNaN(request_depo)) {
        reply("Oops, deposit harus berupa angka bukan simbol/selain angka");
        return;
    }
if (!request_depo) return reply(`Oops, format salah, ikuti yang bener yuk :\n\nContoh: ${prefix + command} 5000`)
if (total < minimal) return m.reply(`Oops, minimal deposit adalah ${formatmoney(minimal)}`)
if (total > max) return m.reply(`Oops, Maximal deposit adalah ${formatmoney(max)}`)
  async function makePayment() {
    try {
      let keynya = global.key;
      let kodeunick = koderefe
      let paymetcod;
     if (command === 'mandiriva') {
               paymetcod = '5'; // Ganti '5' dengan kode pembayaran mandiri yang sesuai
    } else if (command === 'bcava') {
                paymetcod = '1'; // Ganti '1' dengan kode pembayaran bca yang sesuai
    } else if (command === 'bniva') {
                paymetcod = '4'; // Ganti '4' dengan kode pembayaran bni yang sesuai
     } else if (command === 'briva') {
                paymetcod = '2'; // Ganti '2' dengan kode pembayaran bri yang sesuai
     } else if (command === 'cimbva') {
                paymetcod = '3'; // Ganti '3' dengan kode pembayaran cimb yang sesuai
     } else if (command === 'bncva') {
                paymetcod = '10'; // Ganti '10' dengan kode pembayaran bnc yang sesuai
     } else if (command === 'bsiva') {
                paymetcod = '9'; // Ganti '9' dengan kode pembayaran bsi yang sesuai
     } else if (command === 'danamonva') {
                paymetcod = '8'; // Ganti '8' dengan kode pembayaran danamonva yang sesuai
     } else if (command === 'permatava') {
                paymetcod = '7'; // Ganti '7' dengan kode pembayaran permatava yang sesuai
     } else if (command === 'maybankva') {
                paymetcod = '6'; // Ganti '6' dengan kode pembayaran maybankva yang sesuai
            }
      let aomut = total * 1;
      let exp = 1800;
      let create = keynya + kodeunick + paymetcod + aomut + exp + 'NewTransaction'
      let signature = md5(create);
      // Membuat data form untuk permintaan pembayaran
      var paymentData = new FormData();
      paymentData.append('key', keynya);
      paymentData.append('request', 'new');
      paymentData.append('unique_code', kodeunick);
      paymentData.append('service', paymetcod);
      paymentData.append('amount', aomut);
      paymentData.append('note', `DEPOSIT ${pushname}`);
      paymentData.append('valid_time', exp);
      paymentData.append('customer_email', cek("email", m.sender));
      paymentData.append('type_fee', '1');
      paymentData.append('signature', signature); // Menggunakan signature yang telah dihitung

      // Konfigurasi untuk permintaan pembayaran
      var paymentConfig = {
        method: 'post',
        url: 'https://paydisini.co.id/api/',
        headers: { 
          ...paymentData.getHeaders()
        },
        data: paymentData
      };

      // Mengirim permintaan pembayaran
      let paymentResponse = await axios(paymentConfig);
      let paymentDataResponse = paymentResponse.data.data;
          let obj = { id: m.sender, ref: `${paymentDataResponse.unique_code}`, method : `${paymentDataResponse.service_name}`, diterima: `${paymentDataResponse.balance}`, total: `${paymentDataResponse.amount}`, fee: `${paymentDataResponse.fee}`, url: `${paymentDataResponse.checkout_url}` }
          sett("deposit", m.sender, `${paymentDataResponse.unique_code}`)
fs.writeFileSync(`./SETTING/DB/TRANSACTION/Api/Deposit/${cek("deposit", m.sender)}.json`, JSON.stringify(obj))
     await loading()
    let ccapt = ` VIRTUAL ACCOUNT

> Metode : ${paymentDataResponse.service_name}
> Referensi : ${paymentDataResponse.unique_code}
> Berlaku : ${getExpirationTime()} menit
> Total Diterima : ${formatmoney(paymentDataResponse.balance)}
> Fee : ${formatmoney(paymentDataResponse.fee)}
> Total Pembayaran : ${formatmoney(paymentDataResponse.amount)}

Klik "Bayar Sekarang" untuk Melakukan Pembayaran`;

AnanthaGanz.sendPoll(m.chat, ccapt, ['Bayar Sekarang','Cancel Pembayaran']);
setTimeout(() => {
const deppo = JSON.parse(fs.readFileSync(`./SETTING/DB/TRANSACTION/Api/Deposit/${cek("deposit", m.sender)}.json`))
               let method = `${checkIdDepo(m.sender, deppo) ? checkIdDepo(m.sender, deppo) : deppo.method}`
              let member = `${checkIdDepo(m.sender, deppo) ? checkIdDepo(m.sender, deppo) : deppo.id}`
                let price_sender = `${checkIdDepo(m.sender, deppo) ? checkIdDepo(m.sender, deppo) : deppo.diterima}` * 1
               let fee_sender = `${checkIdDepo(m.sender, deppo) ? checkIdDepo(m.sender, deppo) : deppo.fee}` * 1
               let ref_sender = `${checkIdDepo(m.sender, deppo) ? checkIdDepo(m.sender, deppo) : deppo.ref}` 
               let total_sender = `${checkIdDepo(m.sender, deppo) ? checkIdDepo(m.sender, deppo) : deppo.total}` * 1
               let url = `${checkIdDepo(m.sender, deppo) ? checkIdDepo(m.sender, deppo) : deppo.url}`
               sendEmailPending(sender, pushname, ref_sender, method, price_sender, fee_sender, total_sender, url);
               }, 5000);
let unick = paymentDataResponse.unique_code
function getExpirationTime() {
    const currentTime = new Date().getTime();
    const expirationTime = currentTime + (3 * 60 * 60 * 60 * 1000); // 3 jam ke depan
    const timeRemaining = Math.ceil((expirationTime - currentTime) / (60 * 60 * 1000));// Konversi ke menit dan dibulatkan ke atas
    return timeRemaining;
}
      // Memantau status pembayaran
      let dataStatus = paymentDataResponse.status;
      const startTime = new Date().getTime();
      while (dataStatus !== "Success") {
        await sleep(1000);
       let create3 = keynya + unick + 'StatusTransaction'
      let signature3 = md5(create3);
        var checkStatusData = new FormData();
        checkStatusData.append('key', keynya);
        checkStatusData.append('request', 'status');
        checkStatusData.append('unique_code', kodeunick);
        checkStatusData.append('signature', signature3); 
        // Konfigurasi untuk memeriksa status pembayaran
        var checkStatusConfig = {
          method: 'post',
          url: 'https://paydisini.co.id/api/',
          headers: { 
            ...checkStatusData.getHeaders()
          },
          data: checkStatusData
        };
        // Mengirim permintaan untuk memeriksa status pembayaran
        let statusResponse = await axios(checkStatusConfig);
        let statusDataResponse = statusResponse.data.data;
        dataStatus = statusDataResponse.status;
        console.log(dataStatus);
        // Memeriksa waktu timeout
        const currentTime = new Date().getTime();
              const elapsedTime = (currentTime - startTime) / (1000 * 60 * 60 * 3);
              if (elapsedTime >= 1) {
m.reply(`Upss, tiket ${cek("deposit", m.sender)} udah gak berlaku nih. Yuk, buat yang baru!`);
cancelPay();
          break;
        }
        // Jika pembayaran berhasil
        if (dataStatus === "Success") {
          const deppo = JSON.parse(fs.readFileSync(`./SETTING/DB/TRANSACTION/Api/Deposit/${cek("deposit", m.sender)}.json`))
               let method = `${checkIdDepo(m.sender, deppo) ? checkIdDepo(m.sender, deppo) : deppo.method}`
              let member = `${checkIdDepo(m.sender, deppo) ? checkIdDepo(m.sender, deppo) : deppo.id}`
                let price_sender = `${checkIdDepo(m.sender, deppo) ? checkIdDepo(m.sender, deppo) : deppo.diterima}` * 1
               let fee_sender = `${checkIdDepo(m.sender, deppo) ? checkIdDepo(m.sender, deppo) : deppo.fee}` * 1
               let ref_sender = `${checkIdDepo(m.sender, deppo) ? checkIdDepo(m.sender, deppo) : deppo.ref}` 
               let total_sender = `${checkIdDepo(m.sender, deppo) ? checkIdDepo(m.sender, deppo) : deppo.total}` * 1
const depoFilepAth = './SETTING/DB/TRANSACTION/depouser.json';
    const depoUser = JSON.parse(fs.readFileSync(depoFilepAth, 'utf8'));
        const newDepo = {
            buyer: m.sender,
            status: "PAID",
            jam: moment.tz(`Asia/${global.Wilayah}`).format('HH:mm:ss'),
            waktu: moment.tz(`Asia/${global.Wilayah}`).format('DD/MM/YY'),
            no_pembayaran: `${ref_sender}`,
            method: `${method}`,
            jumlah: `${price_sender}`,
            fee: `${fee_sender}`,
            total: `${total_sender}`,
            
        };
            depoUser.push(newDepo);
    fs.writeFileSync(depoFilepAth, JSON.stringify(depoUser, null, 2), 'utf8');
    sendEmailDepo(sender, pushname, ref_sender, method, price_sender, fee_sender, total_sender);
                setTimeout(() => {
let notif = `Hai *${ownername}*,
Ada transaksi yang telah dibayar!

Member : ${dengan_nol}
Kode Unik : ${ref_sender}
Metode Pembayaran : ${method}
Jumlah Deposit : ${formatmoney(price_sender)}
Biaya Admin : ${formatmoney(fee_sender)}
Total Deposit : ${formatmoney(total_sender)}
Waktu : ${moment.tz(`Asia/${global.Wilayah}`).format('HH:mm:ss')} | ${moment.tz(`Asia/${global.Wilayah}`).format('DD/MM/YY')}

Detail transaksi dapat dilihat pada website https://paydisini.co.id/Riwayat-Transaksi/?status=&unique_code=${ref_sender}
`
AnanthaGanz.sendMessage(`${owner}@s.whatsapp.net`,{text: notif },  { quoted: m })
   }, 2000); // 2000 milliseconds (3 seconds)
                const capt = `*Pembayaran Berhasil*

Payment Details  :

› *Metode :* ${method}
› *Referensi :* ${ref_sender}
› *Jumlah :* ${formatmoney(price_sender)}
› *Fee :* ${formatmoney(fee_sender)}
› *Total :* ${formatmoney(total_sender)}

Information :
Pengisian saldo berhasil! Terima kasih atas transaksinya.

${toko}
`

AnanthaGanz.sendPoll(member, capt, ['Deposit Lagi','Hubungi Admin'])
                sett("+saldo", member, price_sender)           
                setTimeout(() => {
                fs.unlinkSync(`./SETTING/DB/TRANSACTION/Api/Deposit/${cek("deposit", m.sender)}.json`);
                }, 4000);
                setTimeout(() => {
    sett("deposit", m.sender, "")
                }, 6000);
                } else if (dataStatus === "Canceled") {
               console.log(`Berhasil! Ref ${cek("deposit", m.sender)} Dihapus`)
          break;
        }
      }
    } catch (error) {
      console.log(error);
    }
  }
  // Memanggil fungsi untuk melakukan pembayaran
  makePayment();
}
break;
case 'dana.':{
if (cek("verfiyemail", m.sender) == true) return reply(`Oops, Silahkan Daftarkan Email anda\nContoh : .setemail xxxxx@gmail.com`);
    if (cek("cekVerify", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, `Oops, Silahkan Verifikasi Email : ${cek("email", m.sender)}`, ['Verifikasicode','Hubungi Admin']);
    if(cek("syarat", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, 'Oops, Kamu Belum Menyetujui Syarat Ketentuan dari kami. Mohon setujuin dulu, agar dapat mengakses fitur dari kami.', ['Saya Setuju','Syarat nya apa aja']);
AnanthaGanz.sendPoll(m.chat, "Nominal Cepat", ['DANA 50000','DANA 100000','DANA 200000','DANA 500000','DANA'])
}
break
case 'shopeepay.':{
if (cek("verfiyemail", m.sender) == true) return reply(`Oops, Silahkan Daftarkan Email anda\nContoh : .setemail xxxxx@gmail.com`);
    if (cek("cekVerify", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, `Oops, Silahkan Verifikasi Email : ${cek("email", m.sender)}`, ['Verifikasicode','Hubungi Admin']);
    if(cek("syarat", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, 'Oops, Kamu Belum Menyetujui Syarat Ketentuan dari kami. Mohon setujuin dulu, agar dapat mengakses fitur dari kami.', ['Saya Setuju','Syarat nya apa aja']);
AnanthaGanz.sendPoll(m.chat, "Nominal Cepat", ['SHOPEEPAY 50000','SHOPEEPAY 100000','SHOPEEPAY 200000','SHOPEEPAY 500000','SHOPEEPAY'])
}
break
case 'linkaja.':{
if (cek("verfiyemail", m.sender) == true) return reply(`Oops, Silahkan Daftarkan Email anda\nContoh : .setemail xxxxx@gmail.com`);
    if (cek("cekVerify", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, `Oops, Silahkan Verifikasi Email : ${cek("email", m.sender)}`, ['Verifikasicode','Hubungi Admin']);
    if(cek("syarat", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, 'Oops, Kamu Belum Menyetujui Syarat Ketentuan dari kami. Mohon setujuin dulu, agar dapat mengakses fitur dari kami.', ['Saya Setuju','Syarat nya apa aja']);
AnanthaGanz.sendPoll(m.chat, "Nominal Cepat", ['LINKAJA 50000','LINKAJA 100000','LINKAJA 200000','LINKAJA 500000','LINKAJA'])
}
break

case 'shopeepay':
case 'linkaja':
case 'dana': {
if (cek("verfiyemail", m.sender) == true) return reply(`Oops, Silahkan Daftarkan Email anda\nContoh : .setemail xxxxx@gmail.com`);
    if (cek("cekVerify", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, `Oops, Silahkan Verifikasi Email : ${cek("email", m.sender)}`, ['Verifikasicode','Hubungi Admin']);
    if(cek("syarat", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, 'Oops, Kamu Belum Menyetujui Syarat Ketentuan dari kami. Mohon setujuin dulu, agar dapat mengakses fitur dari kami.', ['Saya Setuju','Syarat nya apa aja']);
let send = `${sender.split('@')[0]}`
let axios = require('axios');
let FormData = require('form-data');
let md5 = require('md5');
let minimal = '15000' * 1// SETT MIN DEPO
let max = '2500000' * 1 // SETT MAX DEPO
if(fs.existsSync(`./SETTING/DB/TRANSACTION/Api/Deposit/${cek("deposit", m.sender)}.json`)) return AnanthaGanz.sendPoll(m.chat, `Oops, Kamu Sedang Memiliki Invoice ${cek("deposit", m.sender)}, apakah kamu ingin cancel?`, ['Cancel Aja','Hubungi Admin']);
let request_depo = q.split(" ")[0]
let total = `${request_depo}` * 1
     if (isNaN(request_depo)) {
        reply("Oops, deposit harus berupa angka bukan simbol/selain angka");
        return;
    }
if (!request_depo) return reply(`Oops, format salah, ikuti yang bener yuk :\n\nContoh: ${prefix + command} 5000`)
if (total < minimal) return m.reply(`Oops, minimal deposit adalah ${formatmoney(minimal)}`)
if (total > max) return m.reply(`Oops, Maximal deposit adalah ${formatmoney(max)}`)
  async function makePayment() {
    try {
      let keynya = global.key;
      let kodeunick = koderefe
      let paymetcod;
     if (command === 'dana') {
                paymetcod = '13'; // Ganti '13' dengan kode pembayaran dana yang sesuai
    } else if (command === 'linkaja') {
                paymetcod = '14'; // Ganti '14' dengan kode pembayaran linkaja yang sesuai
              } else  if (command === 'shopeepay') {
                paymetcod = '16'; // Ganti '16' dengan kode pembayaran shopeepay     yang sesuai
     
            }
            
      let aomut = total * 1;
      let exp = 10800;
      let create = keynya + kodeunick + paymetcod + aomut + exp + 'NewTransaction'
      let signature = md5(create);
      let no_waletsend = `${sender.split('@')[0]}`;
      no_waletsend = no_waletsend.replace('62', '0');
      // Membuat data form untuk permintaan pembayaran
      var paymentData = new FormData();
      paymentData.append('key', keynya);
      paymentData.append('request', 'new');
      paymentData.append('unique_code', kodeunick);
      paymentData.append('service', paymetcod);
      paymentData.append('amount', aomut);
      paymentData.append('note', `DEPOSIT ${pushname}`);
      paymentData.append('valid_time', exp);
      paymentData.append('ewallet_phone', no_waletsend);
      paymentData.append('customer_email', cek("email", m.sender));
      paymentData.append('type_fee', '1');
      paymentData.append('signature', signature); // Menggunakan signature yang telah dihitung

      // Konfigurasi untuk permintaan pembayaran
      var paymentConfig = {
        method: 'post',
        url: 'https://paydisini.co.id/api/',
        headers: { 
          ...paymentData.getHeaders()
        },
        data: paymentData
      };

      // Mengirim permintaan pembayaran
      let paymentResponse = await axios(paymentConfig);
            let paymentDataResponse = paymentResponse.data.data;
          let obj = { id: m.sender, ref: `${paymentDataResponse.unique_code}`, method : `${paymentDataResponse.service_name}`, diterima: `${paymentDataResponse.balance}`, total: `${paymentDataResponse.amount}`, fee: `${paymentDataResponse.fee}`, url: `${paymentDataResponse.checkout_url}` }
          sett("deposit", m.sender, `${paymentDataResponse.unique_code}`)
fs.writeFileSync(`./SETTING/DB/TRANSACTION/Api/Deposit/${cek("deposit", m.sender)}.json`, JSON.stringify(obj))
     await loading()
    let ccapt = ` Wallet Otomatis 

> Metode : ${paymentDataResponse.service_name}
> Referensi : ${paymentDataResponse.unique_code}
> Berlaku : ${getExpirationTime()} menit
> Total Diterima : ${formatmoney(paymentDataResponse.balance)}
> Fee : ${formatmoney(paymentDataResponse.fee)}
> Total Pembayaran : ${formatmoney(paymentDataResponse.amount)}

Klik "Bayar Sekarang" untuk Melakukan Pembayaran`;

AnanthaGanz.sendPoll(m.chat, ccapt, ['Bayar Sekarang','Cancel Pembayaran']);
setTimeout(() => {
const deppo = JSON.parse(fs.readFileSync(`./SETTING/DB/TRANSACTION/Api/Deposit/${cek("deposit", m.sender)}.json`))
               let method = `${checkIdDepo(m.sender, deppo) ? checkIdDepo(m.sender, deppo) : deppo.method}`
              let member = `${checkIdDepo(m.sender, deppo) ? checkIdDepo(m.sender, deppo) : deppo.id}`
                let price_sender = `${checkIdDepo(m.sender, deppo) ? checkIdDepo(m.sender, deppo) : deppo.diterima}` * 1
               let fee_sender = `${checkIdDepo(m.sender, deppo) ? checkIdDepo(m.sender, deppo) : deppo.fee}` * 1
               let ref_sender = `${checkIdDepo(m.sender, deppo) ? checkIdDepo(m.sender, deppo) : deppo.ref}` 
               let total_sender = `${checkIdDepo(m.sender, deppo) ? checkIdDepo(m.sender, deppo) : deppo.total}` * 1
               let url = `${checkIdDepo(m.sender, deppo) ? checkIdDepo(m.sender, deppo) : deppo.url}`
               sendEmailPending(sender, pushname, ref_sender, method, price_sender, fee_sender, total_sender, url);
               }, 5000);
let unick = paymentDataResponse.unique_code
function getExpirationTime() {
    const currentTime = new Date().getTime();
    const expirationTime = currentTime + (30 * 60 * 1000); // 30 menit kedepan
    const timeRemaining = Math.ceil((expirationTime - currentTime) / 60000); // Konversi ke menit dan dibulatkan ke atas
    return timeRemaining;
}
      // Memantau status pembayaran
      let dataStatus = paymentDataResponse.status;
      const startTime = new Date().getTime();
      while (dataStatus !== "Success") {
        await sleep(1000);
       let create3 = keynya + unick + 'StatusTransaction'
      let signature3 = md5(create3);
        var checkStatusData = new FormData();
        checkStatusData.append('key', keynya);
        checkStatusData.append('request', 'status');
        checkStatusData.append('unique_code', kodeunick);
        checkStatusData.append('signature', signature3); 
        // Konfigurasi untuk memeriksa status pembayaran
        var checkStatusConfig = {
          method: 'post',
          url: 'https://paydisini.co.id/api/',
          headers: { 
            ...checkStatusData.getHeaders()
          },
          data: checkStatusData
        };
        // Mengirim permintaan untuk memeriksa status pembayaran
        let statusResponse = await axios(checkStatusConfig);
        let statusDataResponse = statusResponse.data.data;
        dataStatus = statusDataResponse.status;
        console.log(dataStatus);
        // Memeriksa waktu timeout
        const currentTime = new Date().getTime();
           const elapsedTime = (currentTime - startTime) / (1000 * 60 * 30);
             if (elapsedTime >= 1) {
              m.reply(`Upss, tiket ${cek("deposit", m.sender)} udah gak berlaku nih. Yuk, buat yang baru!`);
              cancelPay();
          break;
        }
        // Jika pembayaran berhasil
        if (dataStatus === "Success") {
          const deppo = JSON.parse(fs.readFileSync(`./SETTING/DB/TRANSACTION/Api/Deposit/${cek("deposit", m.sender)}.json`))
               let method = `${checkIdDepo(m.sender, deppo) ? checkIdDepo(m.sender, deppo) : deppo.method}`
              let member = `${checkIdDepo(m.sender, deppo) ? checkIdDepo(m.sender, deppo) : deppo.id}`
                let price_sender = `${checkIdDepo(m.sender, deppo) ? checkIdDepo(m.sender, deppo) : deppo.diterima}` * 1
               let fee_sender = `${checkIdDepo(m.sender, deppo) ? checkIdDepo(m.sender, deppo) : deppo.fee}` * 1
               let ref_sender = `${checkIdDepo(m.sender, deppo) ? checkIdDepo(m.sender, deppo) : deppo.ref}` 
               let total_sender = `${checkIdDepo(m.sender, deppo) ? checkIdDepo(m.sender, deppo) : deppo.total}` * 1
const depoFilepAth = './SETTING/DB/TRANSACTION/depouser.json';
    const depoUser = JSON.parse(fs.readFileSync(depoFilepAth, 'utf8'));
        const newDepo = {
            buyer: m.sender,
            status: "PAID",
            jam: moment.tz(`Asia/${global.Wilayah}`).format('HH:mm:ss'),
            waktu: moment.tz(`Asia/${global.Wilayah}`).format('DD/MM/YY'),
            no_pembayaran: `${ref_sender}`,
            method: `${method}`,
            jumlah: `${price_sender}`,
            fee: `${fee_sender}`,
            total: `${total_sender}`,
            
        };
            depoUser.push(newDepo);
    fs.writeFileSync(depoFilepAth, JSON.stringify(depoUser, null, 2), 'utf8');
     sendEmailDepo(sender, pushname, ref_sender, method, price_sender, fee_sender, total_sender);
                setTimeout(() => {
let notif = `Hai *${ownername}*,
Ada transaksi yang telah dibayar!

Member : ${dengan_nol}
Kode Unik : ${ref_sender}
Metode Pembayaran : ${method}
Jumlah Deposit : ${formatmoney(price_sender)}
Biaya Admin : ${formatmoney(fee_sender)}
Total Deposit : ${formatmoney(total_sender)}
Waktu : ${moment.tz(`Asia/${global.Wilayah}`).format('HH:mm:ss')} | ${moment.tz(`Asia/${global.Wilayah}`).format('DD/MM/YY')}

Detail transaksi dapat dilihat pada website https://paydisini.co.id/Riwayat-Transaksi/?status=&unique_code=${ref_sender}
`
AnanthaGanz.sendMessage(`${owner}@s.whatsapp.net`,{text: notif },  { quoted: m })
   }, 2000); // 2000 milliseconds (3 seconds)
                const capt = `*Pembayaran Berhasil*

Payment Details  :

› *Metode :* ${method}
› *Referensi :* ${ref_sender}
› *Jumlah :* ${formatmoney(price_sender)}
› *Fee :* ${formatmoney(fee_sender)}
› *Total :* ${formatmoney(total_sender)}

Information :
Pengisian saldo berhasil! Terima kasih atas transaksinya.

${toko}
`

AnanthaGanz.sendPoll(member, capt, ['Deposit Lagi','Hubungi Admin'])
                sett("+saldo", member, price_sender)           
                setTimeout(() => {
                fs.unlinkSync(`./SETTING/DB/TRANSACTION/Api/Deposit/${cek("deposit", m.sender)}.json`);
                }, 4000);
                setTimeout(() => {
    sett("deposit", m.sender, "")
                }, 6000);
                } else if (dataStatus === "Canceled") {
               console.log(`Berhasil! Ref ${cek("deposit", m.sender)} Dihapus`)
          break;
        }
      }
    } catch (error) {
      console.log(error);
    }
  }
  // Memanggil fungsi untuk melakukan pembayaran
  makePayment();
}
break;
case 'infopaydisini':{
var axios = require('axios');
let md5 = require('md5');
var FormData = require('form-data');
let keynya = global.key;
var data = new FormData();
let signnya = keynya + 'Profile'
let signa3 = md5(signnya);
data.append('key', keynya);
data.append('request', 'profile');
data.append('signature', signa3);

var config = {
  method: 'post',
maxBodyLength: Infinity,
  url: 'https://paydisini.co.id/api/',
  headers: { 
    ...data.getHeaders()
  },
  data : data
};

axios(config)
.then(function (response) {
 let tersedia = response.data.data.saldo * 1
 let tertahan = response.data.data.saldo_tertahan * 1
 reply(`INFO AKUN PAYDISINI \n\n> Nama : ${response.data.data.full_name}\n> Merchant : ${response.data.data.merchant}\n> No.Telp : ${response.data.data.telephone}\n> Email : ${response.data.data.email}\n> Saldo Tersedia : ${formatmoney(tersedia)}\n> Tertahan : ${formatmoney(tertahan)}\n> Auto Withdraw : ${response.data.data.auto_wd}`)
})
.catch(function (error) {
  console.log(error);
});
}
break 

case 'getlayanann':{
let axios = require('axios');

const api_key = "9hg0pjrcztur46gh3728ip0joytnluf";
const secret_key = "y831jmeebnqrlowrd7f94n79yigkt60u6shmxz10pa5u3ojc8v";
const action = "services";

const url = "https://buzzerpanel.id/api/json.php";

        axios('https://buzzerpanel.id/api/json.php',{
method: 'POST',
data: new URLSearchParams(Object.entries({
api_key: api_key,
secret_key: secret_key,
action: 'services',
}))}).then((response) => {
        // Lakukan sesuatu dengan data yang diperoleh
        console.log(response.data);
    })
    .catch(error => {
        console.error("Error:", error);
    });
}
break
case 'tourl': {
           m.reply(mess.wait)
        let { UploadFileUgu, webp2mp4File, TelegraPh } = require('./uploader')
        let media = await AnanthaGanz.downloadAndSaveMediaMessage(qmsg)
        if (/image/.test(mime)) {
            let anu = await TelegraPh(media)
            m.reply(util.format(anu))
        } else if (!/image/.test(mime)) {
            let anu = await UploadFileUgu(media)
            m.reply(util.format(anu))
        }
        await fs.
        unlinkSync(media)
    }
    break;
    /* LIST XL AXIATA*/
 case 'd-xl': {
 if (cek("verfiyemail", m.sender) == true) return reply(`Oops, Silahkan Daftarkan Email anda\nContoh : .setemail xxxxx@gmail.com`);
    if (cek("cekVerify", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, `Oops, Silahkan Verifikasi Email : ${cek("email", m.sender)}`, ['Verifikasicode','Hubungi Admin']);
    if(cek("syarat", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, 'Oops, Kamu Belum Menyetujui Syarat Ketentuan dari kami. Mohon setujuin dulu, agar dapat mengakses fitur dari kami.', ['Saya Setuju','Syarat nya apa aja']);
    let data10 = JSON.parse(fs.readFileSync('./SETTING/DB/datadigiflaz.json'));
    data10.sort((a, b) => a.price - b.price);
    let formattedResponse = `*===[ DATA XL ]===*\n\n> 🪀 24/7\n> ⚡ Proses Cepat\n> ✅ Garansi Uang Kembali\n> ✅ Aman & Terpercaya\n\n*© PT ZANNPAY INDONESIA*\n---------------------------------------\n`;
    let productsFound = false;

    data10.forEach(function(product) {
        if (product.category === "Data" && product.brand === "XL") { // Filter berdasarkan type paket yang dipilih
            productsFound = true;
            const status = product.seller_product_status ? "Ready" : "Sold Out";
            const statusEmoji = product.seller_product_status ? "✅" : "❌";
            let stock_display = product.stock === 0 ? "∞" : product.stock;
            let produknya = `≫ *${product.product_name}*`;
            formattedResponse += `
${produknya}

> Kode : ${product.buyer_sku_code}
> Status : ${statusEmoji} ${status}
> Harga : ${formatmoney(product.price)}
> Kategori : ${product.category}
> Tipe : ${product.type}
> Stock : ${stock_display}
> Deskripsi : ${product.desc}
> Cara Order : Reply pesan ini dengan *${prefix}order ${product.buyer_sku_code} <tujuan/userid/zone>*

---------------------------------------
`;
        }
    });

    if (!productsFound) {
        formattedResponse += "Oops, produk tidak tersedia saat ini.";
    }

    AnanthaGanz.sendMessage(m.chat, {
        text: formattedResponse,
        contextInfo: {
            externalAdReply: {
                title: `${footer}`,
                thumbnailUrl: `https://i.ibb.co/0KGj27t/20240223-202951.jpg`,
                sourceUrl: `https://wa.me/${botNumber}?text=menu`,
                mediaType: 1,
                renderLargerThumbnail: true
            }
        }
    }, { quoted: fdocc });
}
break;

case 'v-xl': {
if (cek("verfiyemail", m.sender) == true) return reply(`Oops, Silahkan Daftarkan Email anda\nContoh : .setemail xxxxx@gmail.com`);
    if (cek("cekVerify", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, `Oops, Silahkan Verifikasi Email : ${cek("email", m.sender)}`, ['Verifikasicode','Hubungi Admin']);
    if(cek("syarat", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, 'Oops, Kamu Belum Menyetujui Syarat Ketentuan dari kami. Mohon setujuin dulu, agar dapat mengakses fitur dari kami.', ['Saya Setuju','Syarat nya apa aja']);
    let data10 = JSON.parse(fs.readFileSync('./SETTING/DB/datadigiflaz.json'));
    data10.sort((a, b) => a.price - b.price);
    let formattedResponse = `*===[ VOUCHER XL ]===*\n\n> 🪀 24/7\n> ⚡ Proses Cepat\n> ✅ Garansi Uang Kembali\n> ✅ Aman & Terpercaya\n\n*© PT ZANNPAY INDONESIA*\n---------------------------------------\n`;
    let productsFound = false;
    data10.forEach(function(product) {
        if (product.category === "Voucher" && product.brand === "XL") {
            productsFound = true;
            const status = product.seller_product_status ? "Ready" : "Sold Out";
            const statusEmoji = product.seller_product_status ? "✅" : "❌";
            let stock_display = product.stock === 0 ? "∞" : product.stock;
            let produknya = `≫ *${product.product_name}*`;
            formattedResponse += `
${produknya}

> Kode : ${product.buyer_sku_code}
> Status : ${statusEmoji} ${status}
> Harga : ${formatmoney(product.price)}
> Kategori : ${product.category}
> Tipe : ${product.type}
> Stock : ${stock_display}
> Deskripsi : ${product.desc}
> Cara Order : Reply pesan ini dengan *${prefix}order ${product.buyer_sku_code} <tujuan/userid/zone>*

---------------------------------------
`;
        }
    });

    if (!productsFound) {
        formattedResponse += "Oops, produk tidak tersedia saat ini.";
    }

    AnanthaGanz.sendMessage(m.chat, {
        text: formattedResponse,
        contextInfo: {
            externalAdReply: {
                title: `${footer}`,
                thumbnailUrl: `https://i.ibb.co/0KGj27t/20240223-202951.jpg`,
                sourceUrl: `https://wa.me/${botNumber}?text=menu`,
                mediaType: 1,
                renderLargerThumbnail: true
            }
        }
    }, { quoted: fdocc });
}
break;

case 't-xl': {
if (cek("verfiyemail", m.sender) == true) return reply(`Oops, Silahkan Daftarkan Email anda\nContoh : .setemail xxxxx@gmail.com`);
    if (cek("cekVerify", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, `Oops, Silahkan Verifikasi Email : ${cek("email", m.sender)}`, ['Verifikasicode','Hubungi Admin']);
    if(cek("syarat", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, 'Oops, Kamu Belum Menyetujui Syarat Ketentuan dari kami. Mohon setujuin dulu, agar dapat mengakses fitur dari kami.', ['Saya Setuju','Syarat nya apa aja']);
    let data10 = JSON.parse(fs.readFileSync('./SETTING/DB/datadigiflaz.json'));
    data10.sort((a, b) => a.price - b.price);
    let formattedResponse = `*===[ PULSA TRANSFER XL ]===*\n\n> 🪀 24/7\n> ⚡ Proses Cepat\n> ✅ Garansi Uang Kembali\n> ✅ Aman & Terpercaya\n\n*© PT ZANNPAY INDONESIA*\n---------------------------------------\n`;
    let productsFound = false;
    data10.forEach(function(product) {
        if (product.category === "Pulsa" && product.brand === "XL" && product.type === "Pulsa Transfer") {
            productsFound = true;
            const status = product.seller_product_status ? "Ready" : "Sold Out";
            const statusEmoji = product.seller_product_status ? "✅" : "❌";
            let stock_display = product.stock === 0 ? "∞" : product.stock;
            let produknya = `≫ *${product.product_name}*`;
            formattedResponse += `
${produknya}

> Kode : ${product.buyer_sku_code}
> Status : ${statusEmoji} ${status}
> Harga : ${formatmoney(product.price)}
> Kategori : ${product.category}
> Tipe : ${product.type}
> Stock : ${stock_display}
> Deskripsi : ${product.desc}
> Cara Order : Reply pesan ini dengan *${prefix}order ${product.buyer_sku_code} <tujuan/userid/zone>*

---------------------------------------
`;
        }
    });

    if (!productsFound) {
        formattedResponse += "Oops, produk tidak tersedia saat ini.";
    }

    AnanthaGanz.sendMessage(m.chat, {
        text: formattedResponse,
        contextInfo: {
            externalAdReply: {
                title: `${footer}`,
                thumbnailUrl: `https://i.ibb.co/0KGj27t/20240223-202951.jpg`,
                sourceUrl: `https://wa.me/${botNumber}?text=menu`,
                mediaType: 1,
                renderLargerThumbnail: true
            }
        }
    }, { quoted: fdocc });
}
break;
case 'p-xl': {
if (cek("verfiyemail", m.sender) == true) return reply(`Oops, Silahkan Daftarkan Email anda\nContoh : .setemail xxxxx@gmail.com`);
    if (cek("cekVerify", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, `Oops, Silahkan Verifikasi Email : ${cek("email", m.sender)}`, ['Verifikasicode','Hubungi Admin']);
    if(cek("syarat", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, 'Oops, Kamu Belum Menyetujui Syarat Ketentuan dari kami. Mohon setujuin dulu, agar dapat mengakses fitur dari kami.', ['Saya Setuju','Syarat nya apa aja']);
    let data10 = JSON.parse(fs.readFileSync('./SETTING/DB/datadigiflaz.json'));
    data10.sort((a, b) => a.price - b.price);
    let formattedResponse = `*===[ PULSA REGULER XL ]===*\n\n> 🪀 24/7\n> ⚡ Proses Cepat\n> ✅ Garansi Uang Kembali\n> ✅ Aman & Terpercaya\n\n*© PT ZANNPAY INDONESIA*\n---------------------------------------\n`;
    let productsFound = false;
    data10.forEach(function(product) {
        if (product.category === "Pulsa" && product.brand === "XL" && product.type === "Umum") {
            productsFound = true;
            const status = product.seller_product_status ? "Ready" : "Sold Out";
            const statusEmoji = product.seller_product_status ? "✅" : "❌";
            let stock_display = product.stock === 0 ? "∞" : product.stock;
            let produknya = `≫ *${product.product_name}*`;
            formattedResponse += `
${produknya}

> Kode : ${product.buyer_sku_code}
> Status : ${statusEmoji} ${status}
> Harga : ${formatmoney(product.price)}
> Kategori : ${product.category}
> Tipe : ${product.type}
> Stock : ${stock_display}
> Deskripsi : ${product.desc}
> Cara Order : Reply pesan ini dengan *${prefix}order ${product.buyer_sku_code} <tujuan/userid/zone>*

---------------------------------------
`;
        }
    });

    if (!productsFound) {
        formattedResponse += "Oops, produk tidak tersedia saat ini.";
    }

    AnanthaGanz.sendMessage(m.chat, {
        text: formattedResponse,
        contextInfo: {
            externalAdReply: {
                title: `${footer}`,
                thumbnailUrl: `https://i.ibb.co/0KGj27t/20240223-202951.jpg`,
                sourceUrl: `https://wa.me/${botNumber}?text=menu`,
                mediaType: 1,
                renderLargerThumbnail: true
            }
        }
    }, { quoted: fdocc });
}
break;
/* end Xl*/
/* TELKOM */
case 'd-telkomsel': {
if (cek("verfiyemail", m.sender) == true) return reply(`Oops, Silahkan Daftarkan Email anda\nContoh : .setemail xxxxx@gmail.com`);
    if (cek("cekVerify", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, `Oops, Silahkan Verifikasi Email : ${cek("email", m.sender)}`, ['Verifikasicode','Hubungi Admin']);
    if(cek("syarat", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, 'Oops, Kamu Belum Menyetujui Syarat Ketentuan dari kami. Mohon setujuin dulu, agar dapat mengakses fitur dari kami.', ['Saya Setuju','Syarat nya apa aja']);
    let data10 = JSON.parse(fs.readFileSync('./SETTING/DB/datadigiflaz.json'));
    data10.sort((a, b) => a.price - b.price);
    let formattedResponse = `*===[ DATA TELKOMSEL ]===*\n\n> 🪀 24/7\n> ⚡ Proses Cepat\n> ✅ Garansi Uang Kembali\n> ✅ Aman & Terpercaya\n\n*© PT ZANNPAY INDONESIA*\n---------------------------------------\n`;
    let productsFound = false;
    data10.forEach(function(product) {
        if (product.category === "Data" && product.brand === "TELKOMSEL") {
            productsFound = true;
            const status = product.seller_product_status ? "Ready" : "Sold Out";
            const statusEmoji = product.seller_product_status ? "✅" : "❌";
            let stock_display = product.stock === 0 ? "∞" : product.stock;
            let produknya = `≫ *${product.product_name}*`;
            formattedResponse += `
${produknya}

> Kode : ${product.buyer_sku_code}
> Status : ${statusEmoji} ${status}
> Harga : ${formatmoney(product.price)}
> Kategori : ${product.category}
> Tipe : ${product.type}
> Stock : ${stock_display}
> Deskripsi : ${product.desc}
> Cara Order : Reply pesan ini dengan *${prefix}order ${product.buyer_sku_code} <tujuan/userid/zone>*

---------------------------------------
`;
        }
    });

    if (!productsFound) {
        formattedResponse += "Oops, produk tidak tersedia saat ini.";
    }

    AnanthaGanz.sendMessage(m.chat, {
        text: formattedResponse,
        contextInfo: {
            externalAdReply: {
                title: `${footer}`,
                thumbnailUrl: `https://i.ibb.co/0KGj27t/20240223-202951.jpg`,
                sourceUrl: `https://wa.me/${botNumber}?text=menu`,
                mediaType: 1,
                renderLargerThumbnail: true
            }
        }
    }, { quoted: fdocc });
}
break;

case 'v-telkomsel': {
if (cek("verfiyemail", m.sender) == true) return reply(`Oops, Silahkan Daftarkan Email anda\nContoh : .setemail xxxxx@gmail.com`);
    if (cek("cekVerify", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, `Oops, Silahkan Verifikasi Email : ${cek("email", m.sender)}`, ['Verifikasicode','Hubungi Admin']);
    if(cek("syarat", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, 'Oops, Kamu Belum Menyetujui Syarat Ketentuan dari kami. Mohon setujuin dulu, agar dapat mengakses fitur dari kami.', ['Saya Setuju','Syarat nya apa aja']);
    let data10 = JSON.parse(fs.readFileSync('./SETTING/DB/datadigiflaz.json'));
    data10.sort((a, b) => a.price - b.price);
    let formattedResponse = `*===[ VOUCHER TELKOMSEL ]===*\n\n> 🪀 24/7\n> ⚡ Proses Cepat\n> ✅ Garansi Uang Kembali\n> ✅ Aman & Terpercaya\n\n*© PT ZANNPAY INDONESIA*\n---------------------------------------\n`;
    let productsFound = false;
    data10.forEach(function(product) {
        if (product.category === "Voucher" && product.brand === "Telkomsel") {
            productsFound = true;
            const status = product.seller_product_status ? "Ready" : "Sold Out";
            const statusEmoji = product.seller_product_status ? "✅" : "❌";
            let stock_display = product.stock === 0 ? "∞" : product.stock;
            let produknya = `≫ *${product.product_name}*`;
            formattedResponse += `
${produknya}

> Kode : ${product.buyer_sku_code}
> Status : ${statusEmoji} ${status}
> Harga : ${formatmoney(product.price)}
> Kategori : ${product.category}
> Tipe : ${product.type}
> Stock : ${stock_display}
> Deskripsi : ${product.desc}
> Cara Order : Reply pesan ini dengan *${prefix}order ${product.buyer_sku_code} <tujuan/userid/zone>*

---------------------------------------
`;
        }
    });

    if (!productsFound) {
        formattedResponse += "Oops, produk tidak tersedia saat ini.";
    }

    AnanthaGanz.sendMessage(m.chat, {
        text: formattedResponse,
        contextInfo: {
            externalAdReply: {
                title: `${footer}`,
                thumbnailUrl: `https://i.ibb.co/0KGj27t/20240223-202951.jpg`,
                sourceUrl: `https://wa.me/${botNumber}?text=menu`,
                mediaType: 1,
                renderLargerThumbnail: true
            }
        }
    }, { quoted: fdocc });
}
break;

case 't-telkomsel': {
if (cek("verfiyemail", m.sender) == true) return reply(`Oops, Silahkan Daftarkan Email anda\nContoh : .setemail xxxxx@gmail.com`);
    if (cek("cekVerify", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, `Oops, Silahkan Verifikasi Email : ${cek("email", m.sender)}`, ['Verifikasicode','Hubungi Admin']);
    if(cek("syarat", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, 'Oops, Kamu Belum Menyetujui Syarat Ketentuan dari kami. Mohon setujuin dulu, agar dapat mengakses fitur dari kami.', ['Saya Setuju','Syarat nya apa aja']);
    let data10 = JSON.parse(fs.readFileSync('./SETTING/DB/datadigiflaz.json'));
    data10.sort((a, b) => a.price - b.price);
    let formattedResponse = `*===[ PULSA TRANSFER TELKOMSEL ]===*\n\n> 🪀 24/7\n> ⚡ Proses Cepat\n> ✅ Garansi Uang Kembali\n> ✅ Aman & Terpercaya\n\n*© PT ZANNPAY INDONESIA*\n---------------------------------------\n`;
    let productsFound = false;
    data10.forEach(function(product) {
        if (product.category === "Pulsa" && product.brand === "TELKOMSEL" && product.type === "Pulsa Transfer") {
            productsFound = true;
            const status = product.seller_product_status ? "Ready" : "Sold Out";
            const statusEmoji = product.seller_product_status ? "✅" : "❌";
            let stock_display = product.stock === 0 ? "∞" : product.stock;
            let produknya = `≫ *${product.product_name}*`;
            formattedResponse += `
${produknya}

> Kode : ${product.buyer_sku_code}
> Status : ${statusEmoji} ${status}
> Harga : ${formatmoney(product.price)}
> Kategori : ${product.category}
> Tipe : ${product.type}
> Stock : ${stock_display}
> Deskripsi : ${product.desc}
> Cara Order : Reply pesan ini dengan *${prefix}order ${product.buyer_sku_code} <tujuan/userid/zone>*

---------------------------------------
`;
        }
    });

    if (!productsFound) {
        formattedResponse += "Oops, produk tidak tersedia saat ini.";
    }

    AnanthaGanz.sendMessage(m.chat, {
        text: formattedResponse,
        contextInfo: {
            externalAdReply: {
                title: `${footer}`,
                thumbnailUrl: `https://i.ibb.co/0KGj27t/20240223-202951.jpg`,
                sourceUrl: `https://wa.me/${botNumber}?text=menu`,
                mediaType: 1,
                renderLargerThumbnail: true
            }
        }
    }, { quoted: fdocc });
}
break;
case 'p-telkomsel': {
if (cek("verfiyemail", m.sender) == true) return reply(`Oops, Silahkan Daftarkan Email anda\nContoh : .setemail xxxxx@gmail.com`);
    if (cek("cekVerify", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, `Oops, Silahkan Verifikasi Email : ${cek("email", m.sender)}`, ['Verifikasicode','Hubungi Admin']);
    if(cek("syarat", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, 'Oops, Kamu Belum Menyetujui Syarat Ketentuan dari kami. Mohon setujuin dulu, agar dapat mengakses fitur dari kami.', ['Saya Setuju','Syarat nya apa aja']);
    let data10 = JSON.parse(fs.readFileSync('./SETTING/DB/datadigiflaz.json'));
    data10.sort((a, b) => a.price - b.price);
    let formattedResponse = `*===[ PULSA REGULER TELKOMSEL ]===*\n\n> 🪀 24/7\n> ⚡ Proses Cepat\n> ✅ Garansi Uang Kembali\n> ✅ Aman & Terpercaya\n\n*© PT ZANNPAY INDONESIA*\n---------------------------------------\n`;
    let productsFound = false;
    data10.forEach(function(product) {
        if (product.category === "Pulsa" && product.brand === "TELKOMSEL" && product.type === "Umum") {
            productsFound = true;
            const status = product.seller_product_status ? "Ready" : "Sold Out";
            const statusEmoji = product.seller_product_status ? "✅" : "❌";
            let stock_display = product.stock === 0 ? "∞" : product.stock;
            let produknya = `≫ *${product.product_name}*`;
            formattedResponse += `
${produknya}

> Kode : ${product.buyer_sku_code}
> Status : ${statusEmoji} ${status}
> Harga : ${formatmoney(product.price)}
> Kategori : ${product.category}
> Tipe : ${product.type}
> Stock : ${stock_display}
> Deskripsi : ${product.desc}
> Cara Order : Reply pesan ini dengan *${prefix}order ${product.buyer_sku_code} <tujuan/userid/zone>*

---------------------------------------
`;
        }
    });

    if (!productsFound) {
        formattedResponse += "Oops, produk tidak tersedia saat ini.";
    }

    AnanthaGanz.sendMessage(m.chat, {
        text: formattedResponse,
        contextInfo: {
            externalAdReply: {
                title: `${footer}`,
                thumbnailUrl: `https://i.ibb.co/0KGj27t/20240223-202951.jpg`,
                sourceUrl: `https://wa.me/${botNumber}?text=menu`,
                mediaType: 1,
                renderLargerThumbnail: true
            }
        }
    }, { quoted: fdocc });
}
break;
/* END TELKOM */
/* INDOSAT*/
case 'd-indosat': {
if (cek("verfiyemail", m.sender) == true) return reply(`Oops, Silahkan Daftarkan Email anda\nContoh : .setemail xxxxx@gmail.com`);
    if (cek("cekVerify", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, `Oops, Silahkan Verifikasi Email : ${cek("email", m.sender)}`, ['Verifikasicode','Hubungi Admin']);
    if(cek("syarat", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, 'Oops, Kamu Belum Menyetujui Syarat Ketentuan dari kami. Mohon setujuin dulu, agar dapat mengakses fitur dari kami.', ['Saya Setuju','Syarat nya apa aja']);
    let data10 = JSON.parse(fs.readFileSync('./SETTING/DB/datadigiflaz.json'));
    data10.sort((a, b) => a.price - b.price);
    let formattedResponse = `*===[ DATA INDOSAT ]===*\n\n> 🪀 24/7\n> ⚡ Proses Cepat\n> ✅ Garansi Uang Kembali\n> ✅ Aman & Terpercaya\n\n*© PT ZANNPAY INDONESIA*\n---------------------------------------\n`;
    let productsFound = false;
    data10.forEach(function(product) {
        if (product.category === "Data" && product.brand === "INDOSAT") {
            productsFound = true;
            const status = product.seller_product_status ? "Ready" : "Sold Out";
            const statusEmoji = product.seller_product_status ? "✅" : "❌";
            let stock_display = product.stock === 0 ? "∞" : product.stock;
            let produknya = `≫ *${product.product_name}*`;
            formattedResponse += `
${produknya}

> Kode : ${product.buyer_sku_code}
> Status : ${statusEmoji} ${status}
> Harga : ${formatmoney(product.price)}
> Kategori : ${product.category}
> Tipe : ${product.type}
> Stock : ${stock_display}
> Deskripsi : ${product.desc}
> Cara Order : Reply pesan ini dengan *${prefix}order ${product.buyer_sku_code} <tujuan/userid/zone>*

---------------------------------------
`;
        }
    });

    if (!productsFound) {
        formattedResponse += "Oops, produk tidak tersedia saat ini.";
    }

    AnanthaGanz.sendMessage(m.chat, {
        text: formattedResponse,
        contextInfo: {
            externalAdReply: {
                title: `${footer}`,
                thumbnailUrl: `https://i.ibb.co/0KGj27t/20240223-202951.jpg`,
                sourceUrl: `https://wa.me/${botNumber}?text=menu`,
                mediaType: 1,
                renderLargerThumbnail: true
            }
        }
    }, { quoted: fdocc });
}
break;

case 'v-indosat': {
if (cek("verfiyemail", m.sender) == true) return reply(`Oops, Silahkan Daftarkan Email anda\nContoh : .setemail xxxxx@gmail.com`);
    if (cek("cekVerify", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, `Oops, Silahkan Verifikasi Email : ${cek("email", m.sender)}`, ['Verifikasicode','Hubungi Admin']);
    if(cek("syarat", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, 'Oops, Kamu Belum Menyetujui Syarat Ketentuan dari kami. Mohon setujuin dulu, agar dapat mengakses fitur dari kami.', ['Saya Setuju','Syarat nya apa aja']);
    let data10 = JSON.parse(fs.readFileSync('./SETTING/DB/datadigiflaz.json'));
    data10.sort((a, b) => a.price - b.price);
    let formattedResponse = `*===[ VOUCHER INDOSAT ]===*\n\n> 🪀 24/7\n> ⚡ Proses Cepat\n> ✅ Garansi Uang Kembali\n> ✅ Aman & Terpercaya\n\n*© PT ZANNPAY INDONESIA*\n---------------------------------------\n`;
    let productsFound = false;
    data10.forEach(function(product) {
        if (product.category === "Voucher" && product.brand === "INDOSAT") {
            productsFound = true;
            const status = product.seller_product_status ? "Ready" : "Sold Out";
            const statusEmoji = product.seller_product_status ? "✅" : "❌";
            let stock_display = product.stock === 0 ? "∞" : product.stock;
            let produknya = `≫ *${product.product_name}*`;
            formattedResponse += `
${produknya}

> Kode : ${product.buyer_sku_code}
> Status : ${statusEmoji} ${status}
> Harga : ${formatmoney(product.price)}
> Kategori : ${product.category}
> Tipe : ${product.type}
> Stock : ${stock_display}
> Deskripsi : ${product.desc}
> Cara Order : Reply pesan ini dengan *${prefix}order ${product.buyer_sku_code} <tujuan/userid/zone>*

---------------------------------------
`;
        }
    });

    if (!productsFound) {
        formattedResponse += "Oops, produk tidak tersedia saat ini.";
    }

    AnanthaGanz.sendMessage(m.chat, {
        text: formattedResponse,
        contextInfo: {
            externalAdReply: {
                title: `${footer}`,
                thumbnailUrl: `https://i.ibb.co/0KGj27t/20240223-202951.jpg`,
                sourceUrl: `https://wa.me/${botNumber}?text=menu`,
                mediaType: 1,
                renderLargerThumbnail: true
            }
        }
    }, { quoted: fdocc });
}
break;

case 't-indosat': {
if (cek("verfiyemail", m.sender) == true) return reply(`Oops, Silahkan Daftarkan Email anda\nContoh : .setemail xxxxx@gmail.com`);
    if (cek("cekVerify", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, `Oops, Silahkan Verifikasi Email : ${cek("email", m.sender)}`, ['Verifikasicode','Hubungi Admin']);
    if(cek("syarat", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, 'Oops, Kamu Belum Menyetujui Syarat Ketentuan dari kami. Mohon setujuin dulu, agar dapat mengakses fitur dari kami.', ['Saya Setuju','Syarat nya apa aja']);
    let data10 = JSON.parse(fs.readFileSync('./SETTING/DB/datadigiflaz.json'));
    data10.sort((a, b) => a.price - b.price);
    let formattedResponse = `*===[ PULSA TRANSFER INDOSAT ]===*\n\n> 🪀 24/7\n> ⚡ Proses Cepat\n> ✅ Garansi Uang Kembali\n> ✅ Aman & Terpercaya\n\n*© PT ZANNPAY INDONESIA*\n---------------------------------------`;
    let productsFound = false;
    data10.forEach(function(product) {
        if (product.category === "Pulsa" && product.brand === "INDOSAT" && product.type === "Pulsa Transfer") {
            productsFound = true;
            const status = product.seller_product_status ? "Ready" : "Sold Out";
            const statusEmoji = product.seller_product_status ? "✅" : "❌";
            let stock_display = product.stock === 0 ? "∞" : product.stock;
            let produknya = `≫ *${product.product_name}*`;
            formattedResponse += `
${produknya}

> Kode : ${product.buyer_sku_code}
> Status : ${statusEmoji} ${status}
> Harga : ${formatmoney(product.price)}
> Kategori : ${product.category}
> Tipe : ${product.type}
> Stock : ${stock_display}
> Deskripsi : ${product.desc}
> Cara Order : Reply pesan ini dengan *${prefix}order ${product.buyer_sku_code} <tujuan/userid/zone>*

---------------------------------------
`;
        }
    });

    if (!productsFound) {
        formattedResponse += "Oops, produk tidak tersedia saat ini.";
    }

    AnanthaGanz.sendMessage(m.chat, {
        text: formattedResponse,
        contextInfo: {
            externalAdReply: {
                title: `${footer}`,
                thumbnailUrl: `https://i.ibb.co/0KGj27t/20240223-202951.jpg`,
                sourceUrl: `https://wa.me/${botNumber}?text=menu`,
                mediaType: 1,
                renderLargerThumbnail: true
            }
        }
    }, { quoted: fdocc });
}
break;

case 'p-indosat': {
if (cek("verfiyemail", m.sender) == true) return reply(`Oops, Silahkan Daftarkan Email anda\nContoh : .setemail xxxxx@gmail.com`);
    if (cek("cekVerify", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, `Oops, Silahkan Verifikasi Email : ${cek("email", m.sender)}`, ['Verifikasicode','Hubungi Admin']);
    if(cek("syarat", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, 'Oops, Kamu Belum Menyetujui Syarat Ketentuan dari kami. Mohon setujuin dulu, agar dapat mengakses fitur dari kami.', ['Saya Setuju','Syarat nya apa aja']);
    let data10 = JSON.parse(fs.readFileSync('./SETTING/DB/datadigiflaz.json'));
    data10.sort((a, b) => a.price - b.price);
    let formattedResponse = `*===[ PULSA REGULER INDOSAT ]===*\n\n> 🪀 24/7\n> ⚡ Proses Cepat\n> ✅ Garansi Uang Kembali\n> ✅ Aman & Terpercaya\n\n*© PT ZANNPAY INDONESIA*\n---------------------------------------\n`;
    let productsFound = false;
    data10.forEach(function(product) {
        if (product.category === "Pulsa" && product.brand === "INDOSAT" && product.type === "Umum") {
            productsFound = true;
            const status = product.seller_product_status ? "Ready" : "Sold Out";
            const statusEmoji = product.seller_product_status ? "✅" : "❌";
            let stock_display = product.stock === 0 ? "∞" : product.stock;
            let produknya = `≫ *${product.product_name}*`;
            formattedResponse += `
${produknya}

> Kode : ${product.buyer_sku_code}
> Status : ${statusEmoji} ${status}
> Harga : ${formatmoney(product.price)}
> Kategori : ${product.category}
> Tipe : ${product.type}
> Stock : ${stock_display}
> Deskripsi : ${product.desc}
> Cara Order : Reply pesan ini dengan *${prefix}order ${product.buyer_sku_code} <tujuan/userid/zone>*

---------------------------------------
`;
        }
    });

    if (!productsFound) {
        formattedResponse += "Oops, produk tidak tersedia saat ini.";
    }

    AnanthaGanz.sendMessage(m.chat, {
        text: formattedResponse,
        contextInfo: {
            externalAdReply: {
                title: `${footer}`,
                thumbnailUrl: `https://i.ibb.co/0KGj27t/20240223-202951.jpg`,
                sourceUrl: `https://wa.me/${botNumber}?text=menu`,
                mediaType: 1,
                renderLargerThumbnail: true
            }
        }
    }, { quoted: fdocc });
}
break;
case 'd-axis': {
if (cek("verfiyemail", m.sender) == true) return reply(`Oops, Silahkan Daftarkan Email anda\nContoh : .setemail xxxxx@gmail.com`);
    if (cek("cekVerify", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, `Oops, Silahkan Verifikasi Email : ${cek("email", m.sender)}`, ['Verifikasicode','Hubungi Admin']);
    if(cek("syarat", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, 'Oops, Kamu Belum Menyetujui Syarat Ketentuan dari kami. Mohon setujuin dulu, agar dapat mengakses fitur dari kami.', ['Saya Setuju','Syarat nya apa aja']);
    let data10 = JSON.parse(fs.readFileSync('./SETTING/DB/datadigiflaz.json'));
    data10.sort((a, b) => a.price - b.price);
    let formattedResponse = `*===[ DATA AXIS ]===*\n\n> 🪀 24/7\n> ⚡ Proses Cepat\n> ✅ Garansi Uang Kembali\n> ✅ Aman & Terpercaya\n\n*© PT ZANNPAY INDONESIA*\n---------------------------------------\n`;
    let productsFound = false;
    data10.forEach(function(product) {
        if (product.category === "Data" && product.brand === "AXIS") {
            productsFound = true;
            const status = product.seller_product_status ? "Ready" : "Sold Out";
            const statusEmoji = product.seller_product_status ? "✅" : "❌";
            let stock_display = product.stock === 0 ? "∞" : product.stock;
            let produknya = `≫ *${product.product_name}*`;
            formattedResponse += `
${produknya}

> Kode : ${product.buyer_sku_code}
> Status : ${statusEmoji} ${status}
> Harga : ${formatmoney(product.price)}
> Kategori : ${product.category}
> Tipe : ${product.type}
> Stock : ${stock_display}
> Deskripsi : ${product.desc}
> Cara Order : Reply pesan ini dengan *${prefix}order ${product.buyer_sku_code} <tujuan/userid/zone>*

---------------------------------------
`;
        }
    });

    if (!productsFound) {
        formattedResponse += "Oops, produk tidak tersedia saat ini.";
    }

    AnanthaGanz.sendMessage(m.chat, {
        text: formattedResponse,
        contextInfo: {
            externalAdReply: {
                title: `${footer}`,
                thumbnailUrl: `https://i.ibb.co/0KGj27t/20240223-202951.jpg`,
                sourceUrl: `https://wa.me/${botNumber}?text=menu`,
                mediaType: 1,
                renderLargerThumbnail: true
            }
        }
    }, { quoted: fdocc });
}
break;

case 'v-axis': {
if (cek("verfiyemail", m.sender) == true) return reply(`Oops, Silahkan Daftarkan Email anda\nContoh : .setemail xxxxx@gmail.com`);
    if (cek("cekVerify", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, `Oops, Silahkan Verifikasi Email : ${cek("email", m.sender)}`, ['Verifikasicode','Hubungi Admin']);
    if(cek("syarat", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, 'Oops, Kamu Belum Menyetujui Syarat Ketentuan dari kami. Mohon setujuin dulu, agar dapat mengakses fitur dari kami.', ['Saya Setuju','Syarat nya apa aja']);
    let data10 = JSON.parse(fs.readFileSync('./SETTING/DB/datadigiflaz.json'));
    data10.sort((a, b) => a.price - b.price);
    let formattedResponse = `*===[ VOUCHER AXIS ]===*\n\n> 🪀 24/7\n> ⚡ Proses Cepat\n> ✅ Garansi Uang Kembali\n> ✅ Aman & Terpercaya\n\n*© PT ZANNPAY INDONESIA*\n---------------------------------------\n`;
    let productsFound = false;
    data10.forEach(function(product) {
        if (product.category === "Voucher" && product.brand === "AXIS") {
            productsFound = true;
            const status = product.seller_product_status ? "Ready" : "Sold Out";
            const statusEmoji = product.seller_product_status ? "✅" : "❌";
            let stock_display = product.stock === 0 ? "∞" : product.stock;
            let produknya = `≫ *${product.product_name}*`;
            formattedResponse += `
${produknya}

> Kode : ${product.buyer_sku_code}
> Status : ${statusEmoji} ${status}
> Harga : ${formatmoney(product.price)}
> Kategori : ${product.category}
> Tipe : ${product.type}
> Stock : ${stock_display}
> Deskripsi : ${product.desc}
> Cara Order : Reply pesan ini dengan *${prefix}order ${product.buyer_sku_code} <tujuan/userid/zone>*

---------------------------------------
`;
        }
    });

    if (!productsFound) {
        formattedResponse += "Oops, produk tidak tersedia saat ini.";
    }

    AnanthaGanz.sendMessage(m.chat, {
        text: formattedResponse,
        contextInfo: {
            externalAdReply: {
                title: `${footer}`,
                thumbnailUrl: `https://i.ibb.co/0KGj27t/20240223-202951.jpg`,
                sourceUrl: `https://wa.me/${botNumber}?text=menu`,
                mediaType: 1,
                renderLargerThumbnail: true
            }
        }
    }, { quoted: fdocc });
}
break;

case 't-axis': {
if (cek("verfiyemail", m.sender) == true) return reply(`Oops, Silahkan Daftarkan Email anda\nContoh : .setemail xxxxx@gmail.com`);
    if (cek("cekVerify", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, `Oops, Silahkan Verifikasi Email : ${cek("email", m.sender)}`, ['Verifikasicode','Hubungi Admin']);
    if(cek("syarat", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, 'Oops, Kamu Belum Menyetujui Syarat Ketentuan dari kami. Mohon setujuin dulu, agar dapat mengakses fitur dari kami.', ['Saya Setuju','Syarat nya apa aja']);
    let data10 = JSON.parse(fs.readFileSync('./SETTING/DB/datadigiflaz.json'));
    data10.sort((a, b) => a.price - b.price);
    let formattedResponse = `*===[ PULSA TRANSFER AXIS ]===*\n\n> 🪀 24/7\n> ⚡ Proses Cepat\n> ✅ Garansi Uang Kembali\n> ✅ Aman & Terpercaya\n\n*© PT ZANNPAY INDONESIA*\n---------------------------------------`;
    let productsFound = false;
    data10.forEach(function(product) {
        if (product.category === "Pulsa" && product.brand === "AXIS" && product.type === "Pulsa Transfer") {
            productsFound = true;
            const status = product.seller_product_status ? "Ready" : "Sold Out";
            const statusEmoji = product.seller_product_status ? "✅" : "❌";
            let stock_display = product.stock === 0 ? "∞" : product.stock;
            let produknya = `≫ *${product.product_name}*`;
            formattedResponse += `
${produknya}

> Kode : ${product.buyer_sku_code}
> Status : ${statusEmoji} ${status}
> Harga : ${formatmoney(product.price)}
> Kategori : ${product.category}
> Tipe : ${product.type}
> Stock : ${stock_display}
> Deskripsi : ${product.desc}
> Cara Order : Reply pesan ini dengan *${prefix}order ${product.buyer_sku_code} <tujuan/userid/zone>*

---------------------------------------
`;
        }
    });

    if (!productsFound) {
        formattedResponse += "Oops, produk tidak tersedia saat ini.";
    }

    AnanthaGanz.sendMessage(m.chat, {
        text: formattedResponse,
        contextInfo: {
            externalAdReply: {
                title: `${footer}`,
                thumbnailUrl: `https://i.ibb.co/0KGj27t/20240223-202951.jpg`,
                sourceUrl: `https://wa.me/${botNumber}?text=menu`,
                mediaType: 1,
                renderLargerThumbnail: true
            }
        }
    }, { quoted: fdocc });
}
break;

case 'p-axis': {
if (cek("verfiyemail", m.sender) == true) return reply(`Oops, Silahkan Daftarkan Email anda\nContoh : .setemail xxxxx@gmail.com`);
    if (cek("cekVerify", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, `Oops, Silahkan Verifikasi Email : ${cek("email", m.sender)}`, ['Verifikasicode','Hubungi Admin']);
    if(cek("syarat", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, 'Oops, Kamu Belum Menyetujui Syarat Ketentuan dari kami. Mohon setujuin dulu, agar dapat mengakses fitur dari kami.', ['Saya Setuju','Syarat nya apa aja']);
    let data10 = JSON.parse(fs.readFileSync('./SETTING/DB/datadigiflaz.json'));
    data10.sort((a, b) => a.price - b.price);
    let formattedResponse = `*===[ PULSA REGULER AXIS ]===*\n\n> 🪀 24/7\n> ⚡ Proses Cepat\n> ✅ Garansi Uang Kembali\n> ✅ Aman & Terpercaya\n\n*© PT ZANNPAY INDONESIA*\n---------------------------------------\n`;
    let productsFound = false;
    data10.forEach(function(product) {
        if (product.category === "Pulsa" && product.brand === "AXIS" && product.type === "Umum") {
            productsFound = true;
            const status = product.seller_product_status ? "Ready" : "Sold Out";
            const statusEmoji = product.seller_product_status ? "✅" : "❌";
            let stock_display = product.stock === 0 ? "∞" : product.stock;
            let produknya = `≫ *${product.product_name}*`;
            formattedResponse += `
${produknya}

> Kode : ${product.buyer_sku_code}
> Status : ${statusEmoji} ${status}
> Harga : ${formatmoney(product.price)}
> Kategori : ${product.category}
> Tipe : ${product.type}
> Stock : ${stock_display}
> Deskripsi : ${product.desc}
> Cara Order : Reply pesan ini dengan *${prefix}order ${product.buyer_sku_code} <tujuan/userid/zone>*

---------------------------------------
`;
        }
    });

    if (!productsFound) {
        formattedResponse += "Oops, produk tidak tersedia saat ini.";
    }

    AnanthaGanz.sendMessage(m.chat, {
        text: formattedResponse,
        contextInfo: {
            externalAdReply: {
                title: `${footer}`,
                thumbnailUrl: `https://i.ibb.co/0KGj27t/20240223-202951.jpg`,
                sourceUrl: `https://wa.me/${botNumber}?text=menu`,
                mediaType: 1,
                renderLargerThumbnail: true
            }
        }
    }, { quoted: fdocc });
}
break;

case 'd-tri': {
if (cek("verfiyemail", m.sender) == true) return reply(`Oops, Silahkan Daftarkan Email anda\nContoh : .setemail xxxxx@gmail.com`);
    if (cek("cekVerify", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, `Oops, Silahkan Verifikasi Email : ${cek("email", m.sender)}`, ['Verifikasicode','Hubungi Admin']);
    if(cek("syarat", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, 'Oops, Kamu Belum Menyetujui Syarat Ketentuan dari kami. Mohon setujuin dulu, agar dapat mengakses fitur dari kami.', ['Saya Setuju','Syarat nya apa aja']);
    let data10 = JSON.parse(fs.readFileSync('./SETTING/DB/datadigiflaz.json'));
    data10.sort((a, b) => a.price - b.price);
    let formattedResponse = `*===[ DATA TRI ]===*\n\n> 🪀 24/7\n> ⚡ Proses Cepat\n> ✅ Garansi Uang Kembali\n> ✅ Aman & Terpercaya\n\n*© PT ZANNPAY INDONESIA*\n---------------------------------------\n`;
    let productsFound = false;
    data10.forEach(function(product) {
        if (product.category === "Data" && product.brand === "TRI") {
            productsFound = true;
            const status = product.seller_product_status ? "Ready" : "Sold Out";
            const statusEmoji = product.seller_product_status ? "✅" : "❌";
            let stock_display = product.stock === 0 ? "∞" : product.stock;
            let produknya = `≫ *${product.product_name}*`;
            formattedResponse += `
${produknya}

> Kode : ${product.buyer_sku_code}
> Status : ${statusEmoji} ${status}
> Harga : ${formatmoney(product.price)}
> Kategori : ${product.category}
> Tipe : ${product.type}
> Stock : ${stock_display}
> Deskripsi : ${product.desc}
> Cara Order : Reply pesan ini dengan *${prefix}order ${product.buyer_sku_code} <tujuan/userid/zone>*

---------------------------------------
`;
        }
    });

    if (!productsFound) {
        formattedResponse += "Oops, produk tidak tersedia saat ini.";
    }

    AnanthaGanz.sendMessage(m.chat, {
        text: formattedResponse,
        contextInfo: {
            externalAdReply: {
                title: `${footer}`,
                thumbnailUrl: `https://i.ibb.co/0KGj27t/20240223-202951.jpg`,
                sourceUrl: `https://wa.me/${botNumber}?text=menu`,
                mediaType: 1,
                renderLargerThumbnail: true
            }
        }
    }, { quoted: fdocc });
}
break;

case 'v-tri': {
if (cek("verfiyemail", m.sender) == true) return reply(`Oops, Silahkan Daftarkan Email anda\nContoh : .setemail xxxxx@gmail.com`);
    if (cek("cekVerify", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, `Oops, Silahkan Verifikasi Email : ${cek("email", m.sender)}`, ['Verifikasicode','Hubungi Admin']);
    if(cek("syarat", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, 'Oops, Kamu Belum Menyetujui Syarat Ketentuan dari kami. Mohon setujuin dulu, agar dapat mengakses fitur dari kami.', ['Saya Setuju','Syarat nya apa aja']);
    let data10 = JSON.parse(fs.readFileSync('./SETTING/DB/datadigiflaz.json'));
    data10.sort((a, b) => a.price - b.price);
    let formattedResponse = `*===[ VOUCHER TRI ]===*\n\n> 🪀 24/7\n> ⚡ Proses Cepat\n> ✅ Garansi Uang Kembali\n> ✅ Aman & Terpercaya\n\n*© PT ZANNPAY INDONESIA*\n---------------------------------------\n`;
    let productsFound = false;
    data10.forEach(function(product) {
        if (product.category === "Voucher" && product.brand === "TRI") {
            productsFound = true;
            const status = product.seller_product_status ? "Ready" : "Sold Out";
            const statusEmoji = product.seller_product_status ? "✅" : "❌";
            let stock_display = product.stock === 0 ? "∞" : product.stock;
            let produknya = `≫ *${product.product_name}*`;
            formattedResponse += `
${produknya}

> Kode : ${product.buyer_sku_code}
> Status : ${statusEmoji} ${status}
> Harga : ${formatmoney(product.price)}
> Kategori : ${product.category}
> Tipe : ${product.type}
> Stock : ${stock_display}
> Deskripsi : ${product.desc}
> Cara Order : Reply pesan ini dengan *${prefix}order ${product.buyer_sku_code} <tujuan/userid/zone>*

---------------------------------------
`;
        }
    });

    if (!productsFound) {
        formattedResponse += "Oops, produk tidak tersedia saat ini.";
    }

    AnanthaGanz.sendMessage(m.chat, {
        text: formattedResponse,
        contextInfo: {
            externalAdReply: {
                title: `${footer}`,
                thumbnailUrl: `https://i.ibb.co/0KGj27t/20240223-202951.jpg`,
                sourceUrl: `https://wa.me/${botNumber}?text=menu`,
                mediaType: 1,
                renderLargerThumbnail: true
            }
        }
    }, { quoted: fdocc });
}
break;

case 't-tri': {
if (cek("verfiyemail", m.sender) == true) return reply(`Oops, Silahkan Daftarkan Email anda\nContoh : .setemail xxxxx@gmail.com`);
    if (cek("cekVerify", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, `Oops, Silahkan Verifikasi Email : ${cek("email", m.sender)}`, ['Verifikasicode','Hubungi Admin']);
    if(cek("syarat", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, 'Oops, Kamu Belum Menyetujui Syarat Ketentuan dari kami. Mohon setujuin dulu, agar dapat mengakses fitur dari kami.', ['Saya Setuju','Syarat nya apa aja']);
    let data10 = JSON.parse(fs.readFileSync('./SETTING/DB/datadigiflaz.json'));
    data10.sort((a, b) => a.price - b.price);
    let formattedResponse = `*===[ PULSA TRANSFER TRI ]===*\n\n> 🪀 24/7\n> ⚡ Proses Cepat\n> ✅ Garansi Uang Kembali\n> ✅ Aman & Terpercaya\n\n*© PT ZANNPAY INDONESIA*\n---------------------------------------`;
    let productsFound = false;
    data10.forEach(function(product) {
        if (product.category === "Pulsa" && product.brand === "TRI" && product.type === "Pulsa Transfer") {
            productsFound = true;
            const status = product.seller_product_status ? "Ready" : "Sold Out";
            const statusEmoji = product.seller_product_status ? "✅" : "❌";
            let stock_display = product.stock === 0 ? "∞" : product.stock;
            let produknya = `≫ *${product.product_name}*`;
            formattedResponse += `
${produknya}

> Kode : ${product.buyer_sku_code}
> Status : ${statusEmoji} ${status}
> Harga : ${formatmoney(product.price)}
> Kategori : ${product.category}
> Tipe : ${product.type}
> Stock : ${stock_display}
> Deskripsi : ${product.desc}
> Cara Order : Reply pesan ini dengan *${prefix}order ${product.buyer_sku_code} <tujuan/userid/zone>*

---------------------------------------
`;
        }
    });

    if (!productsFound) {
        formattedResponse += "Oops, produk tidak tersedia saat ini.";
    }

    AnanthaGanz.sendMessage(m.chat, {
        text: formattedResponse,
        contextInfo: {
            externalAdReply: {
                title: `${footer}`,
                thumbnailUrl: `https://i.ibb.co/0KGj27t/20240223-202951.jpg`,
                sourceUrl: `https://wa.me/${botNumber}?text=menu`,
                mediaType: 1,
                renderLargerThumbnail: true
            }
        }
    }, { quoted: fdocc });
}
break;

case 'p-tri': {
if (cek("verfiyemail", m.sender) == true) return reply(`Oops, Silahkan Daftarkan Email anda\nContoh : .setemail xxxxx@gmail.com`);
    if (cek("cekVerify", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, `Oops, Silahkan Verifikasi Email : ${cek("email", m.sender)}`, ['Verifikasicode','Hubungi Admin']);
    if(cek("syarat", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, 'Oops, Kamu Belum Menyetujui Syarat Ketentuan dari kami. Mohon setujuin dulu, agar dapat mengakses fitur dari kami.', ['Saya Setuju','Syarat nya apa aja']);
    let data10 = JSON.parse(fs.readFileSync('./SETTING/DB/datadigiflaz.json'));
    data10.sort((a, b) => a.price - b.price);
    let formattedResponse = `*===[ PULSA REGULER TRI ]===*\n\n> 🪀 24/7\n> ⚡ Proses Cepat\n> ✅ Garansi Uang Kembali\n> ✅ Aman & Terpercaya\n\n*© PT ZANNPAY INDONESIA*\n---------------------------------------\n`;
    let productsFound = false;
    data10.forEach(function(product) {
        if (product.category === "Pulsa" && product.brand === "TRI" && product.type === "Umum") {
            productsFound = true;
            const status = product.seller_product_status ? "Ready" : "Sold Out";
            const statusEmoji = product.seller_product_status ? "✅" : "❌";
            let stock_display = product.stock === 0 ? "∞" : product.stock;
            let produknya = `≫ *${product.product_name}*`;
            formattedResponse += `
${produknya}

> Kode : ${product.buyer_sku_code}
> Status : ${statusEmoji} ${status}
> Harga : ${formatmoney(product.price)}
> Kategori : ${product.category}
> Tipe : ${product.type}
> Stock : ${stock_display}
> Deskripsi : ${product.desc}
> Cara Order : Reply pesan ini dengan *${prefix}order ${product.buyer_sku_code} <tujuan/userid/zone>*

---------------------------------------
`;
        }
    });

    if (!productsFound) {
        formattedResponse += "Oops, produk tidak tersedia saat ini.";
    }

    AnanthaGanz.sendMessage(m.chat, {
        text: formattedResponse,
        contextInfo: {
            externalAdReply: {
                title: `${footer}`,
                thumbnailUrl: `https://i.ibb.co/0KGj27t/20240223-202951.jpg`,
                sourceUrl: `https://wa.me/${botNumber}?text=menu`,
                mediaType: 1,
                renderLargerThumbnail: true
            }
        }
    }, { quoted: fdocc });
}
break;
case 'd-smartfren': {
if (cek("verfiyemail", m.sender) == true) return reply(`Oops, Silahkan Daftarkan Email anda\nContoh : .setemail xxxxx@gmail.com`);
    if (cek("cekVerify", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, `Oops, Silahkan Verifikasi Email : ${cek("email", m.sender)}`, ['Verifikasicode','Hubungi Admin']);
    if(cek("syarat", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, 'Oops, Kamu Belum Menyetujui Syarat Ketentuan dari kami. Mohon setujuin dulu, agar dapat mengakses fitur dari kami.', ['Saya Setuju','Syarat nya apa aja']);
    let data10 = JSON.parse(fs.readFileSync('./SETTING/DB/datadigiflaz.json'));
    data10.sort((a, b) => a.price - b.price);
    let formattedResponse = `*===[ DATA SMARTFREN ]===*\n\n> 🪀 24/7\n> ⚡ Proses Cepat\n> ✅ Garansi Uang Kembali\n> ✅ Aman & Terpercaya\n\n*© PT ZANNPAY INDONESIA*\n---------------------------------------\n`;
    let productsFound = false;
    data10.forEach(function(product) {
        if (product.category === "Data" && product.brand === "SMARTFREN") {
            productsFound = true;
            const status = product.seller_product_status ? "Ready" : "Sold Out";
            const statusEmoji = product.seller_product_status ? "✅" : "❌";
            let stock_display = product.stock === 0 ? "∞" : product.stock;
            let produknya = `≫ *${product.product_name}*`;
            formattedResponse += `
${produknya}

> Kode : ${product.buyer_sku_code}
> Status : ${statusEmoji} ${status}
> Harga : ${formatmoney(product.price)}
> Kategori : ${product.category}
> Tipe : ${product.type}
> Stock : ${stock_display}
> Deskripsi : ${product.desc}
> Cara Order : Reply pesan ini dengan *${prefix}order ${product.buyer_sku_code} <tujuan/userid/zone>*

---------------------------------------
`;
        }
    });

    if (!productsFound) {
        formattedResponse += "Oops, produk tidak tersedia saat ini.";
    }

    AnanthaGanz.sendMessage(m.chat, {
        text: formattedResponse,
        contextInfo: {
            externalAdReply: {
                title: `${footer}`,
                thumbnailUrl: `https://i.ibb.co/0KGj27t/20240223-202951.jpg`,
                sourceUrl: `https://wa.me/${botNumber}?text=menu`,
                mediaType: 1,
                renderLargerThumbnail: true
            }
        }
    }, { quoted: fdocc });
}
break;

case 'v-smartfren': {
if (cek("verfiyemail", m.sender) == true) return reply(`Oops, Silahkan Daftarkan Email anda\nContoh : .setemail xxxxx@gmail.com`);
    if (cek("cekVerify", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, `Oops, Silahkan Verifikasi Email : ${cek("email", m.sender)}`, ['Verifikasicode','Hubungi Admin']);
    if(cek("syarat", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, 'Oops, Kamu Belum Menyetujui Syarat Ketentuan dari kami. Mohon setujuin dulu, agar dapat mengakses fitur dari kami.', ['Saya Setuju','Syarat nya apa aja']);
    let data10 = JSON.parse(fs.readFileSync('./SETTING/DB/datadigiflaz.json'));
    data10.sort((a, b) => a.price - b.price);
    let formattedResponse = `*===[ VOUCHER SMARTFREN ]===*\n\n> 🪀 24/7\n> ⚡ Proses Cepat\n> ✅ Garansi Uang Kembali\n> ✅ Aman & Terpercaya\n\n*© PT ZANNPAY INDONESIA*\n---------------------------------------\n`;
    let productsFound = false;
    data10.forEach(function(product) {
        if (product.category === "Voucher" && product.brand === "SMARTFREN") {
            productsFound = true;
            const status = product.seller_product_status ? "Ready" : "Sold Out";
            const statusEmoji = product.seller_product_status ? "✅" : "❌";
            let stock_display = product.stock === 0 ? "∞" : product.stock;
            let produknya = `≫ *${product.product_name}*`;
            formattedResponse += `
${produknya}

> Kode : ${product.buyer_sku_code}
> Status : ${statusEmoji} ${status}
> Harga : ${formatmoney(product.price)}
> Kategori : ${product.category}
> Tipe : ${product.type}
> Stock : ${stock_display}
> Deskripsi : ${product.desc}
> Cara Order : Reply pesan ini dengan *${prefix}order ${product.buyer_sku_code} <tujuan/userid/zone>*

---------------------------------------
`;
        }
    });

    if (!productsFound) {
        formattedResponse += "Oops, produk tidak tersedia saat ini.";
    }

    AnanthaGanz.sendMessage(m.chat, {
        text: formattedResponse,
        contextInfo: {
            externalAdReply: {
                title: `${footer}`,
                thumbnailUrl: `https://i.ibb.co/0KGj27t/20240223-202951.jpg`,
                sourceUrl: `https://wa.me/${botNumber}?text=menu`,
                mediaType: 1,
                renderLargerThumbnail: true
            }
        }
    }, { quoted: fdocc });
}
break;

case 't-smartfren': {
if (cek("verfiyemail", m.sender) == true) return reply(`Oops, Silahkan Daftarkan Email anda\nContoh : .setemail xxxxx@gmail.com`);
    if (cek("cekVerify", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, `Oops, Silahkan Verifikasi Email : ${cek("email", m.sender)}`, ['Verifikasicode','Hubungi Admin']);
    if(cek("syarat", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, 'Oops, Kamu Belum Menyetujui Syarat Ketentuan dari kami. Mohon setujuin dulu, agar dapat mengakses fitur dari kami.', ['Saya Setuju','Syarat nya apa aja']);
    let data10 = JSON.parse(fs.readFileSync('./SETTING/DB/datadigiflaz.json'));
    data10.sort((a, b) => a.price - b.price);
    let formattedResponse = `*===[ PULSA TRANSFER SMARTFREN ]===*\n\n> 🪀 24/7\n> ⚡ Proses Cepat\n> ✅ Garansi Uang Kembali\n> ✅ Aman & Terpercaya\n\n*© PT ZANNPAY INDONESIA*\n---------------------------------------`;
    let productsFound = false;
    data10.forEach(function(product) {
        if (product.category === "Pulsa" && product.brand === "SMARTFREN" && product.type === "Pulsa Transfer") {
            productsFound = true;
            const status = product.seller_product_status ? "Ready" : "Sold Out";
            const statusEmoji = product.seller_product_status ? "✅" : "❌";
            let stock_display = product.stock === 0 ? "∞" : product.stock;
            let produknya = `≫ *${product.product_name}*`;
            formattedResponse += `
${produknya}

> Kode : ${product.buyer_sku_code}
> Status : ${statusEmoji} ${status}
> Harga : ${formatmoney(product.price)}
> Kategori : ${product.category}
> Tipe : ${product.type}
> Stock : ${stock_display}
> Deskripsi : ${product.desc}
> Cara Order : Reply pesan ini dengan *${prefix}order ${product.buyer_sku_code} <tujuan/userid/zone>*

---------------------------------------
`;
        }
    });

    if (!productsFound) {
        formattedResponse += "Oops, produk tidak tersedia saat ini.";
    }

   AnanthaGanz.sendMessage(m.chat, {
        text: formattedResponse,
        contextInfo: {
            externalAdReply: {
                title: `${footer}`,
                thumbnailUrl: `https://i.ibb.co/0KGj27t/20240223-202951.jpg`,
                sourceUrl: `https://wa.me/${botNumber}?text=menu`,
                mediaType: 1,
                renderLargerThumbnail: true
            }
        }
    }, { quoted: fdocc });
}
break;

case 'p-smartfren': {
if (cek("verfiyemail", m.sender) == true) return reply(`Oops, Silahkan Daftarkan Email anda\nContoh : .setemail xxxxx@gmail.com`);
    if (cek("cekVerify", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, `Oops, Silahkan Verifikasi Email : ${cek("email", m.sender)}`, ['Verifikasicode','Hubungi Admin']);
    if(cek("syarat", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, 'Oops, Kamu Belum Menyetujui Syarat Ketentuan dari kami. Mohon setujuin dulu, agar dapat mengakses fitur dari kami.', ['Saya Setuju','Syarat nya apa aja']);
    let data10 = JSON.parse(fs.readFileSync('./SETTING/DB/datadigiflaz.json'));
    data10.sort((a, b) => a.price - b.price);
    let formattedResponse = `*===[ PULSA REGULER SMARTFREN ]===*\n\n> 🪀 24/7\n> ⚡ Proses Cepat\n> ✅ Garansi Uang Kembali\n> ✅ Aman & Terpercaya\n\n*© PT ZANNPAY INDONESIA*\n---------------------------------------\n`;
    let productsFound = false;
    data10.forEach(function(product) {
        if (product.category === "Pulsa" && product.brand === "SMARTFREN" && product.type === "Umum") {
            productsFound = true;
            const status = product.seller_product_status ? "Ready" : "Sold Out";
            const statusEmoji = product.seller_product_status ? "✅" : "❌";
            let stock_display = product.stock === 0 ? "∞" : product.stock;
            let produknya = `≫ *${product.product_name}*`;
            formattedResponse += `
${produknya}

> Kode : ${product.buyer_sku_code}
> Status : ${statusEmoji} ${status}
> Harga : ${formatmoney(product.price)}
> Kategori : ${product.category}
> Tipe : ${product.type}
> Stock : ${stock_display}
> Deskripsi : ${product.desc}
> Cara Order : Reply pesan ini dengan *${prefix}order ${product.buyer_sku_code} <tujuan/userid/zone>*

---------------------------------------
`;
        }
    });

    if (!productsFound) {
        formattedResponse += "Oops, produk tidak tersedia saat ini.";
    }

    AnanthaGanz.sendMessage(m.chat, {
        text: formattedResponse,
        contextInfo: {
            externalAdReply: {
                title: `${footer}`,
                thumbnailUrl: `https://i.ibb.co/0KGj27t/20240223-202951.jpg`,
                sourceUrl: `https://wa.me/${botNumber}?text=menu`,
                mediaType: 1,
                renderLargerThumbnail: true
            }
        }
    }, { quoted: fdocc });
}
break;
case 'd-by.u': {
if (cek("verfiyemail", m.sender) == true) return reply(`Oops, Silahkan Daftarkan Email anda\nContoh : .setemail xxxxx@gmail.com`);
    if (cek("cekVerify", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, `Oops, Silahkan Verifikasi Email : ${cek("email", m.sender)}`, ['Verifikasicode','Hubungi Admin']);
    if(cek("syarat", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, 'Oops, Kamu Belum Menyetujui Syarat Ketentuan dari kami. Mohon setujuin dulu, agar dapat mengakses fitur dari kami.', ['Saya Setuju','Syarat nya apa aja']);
    let data10 = JSON.parse(fs.readFileSync('./SETTING/DB/datadigiflaz.json'));
    data10.sort((a, b) => a.price - b.price);
    let formattedResponse = `*===[ DATA by.U ]===*\n\n> 🪀 24/7\n> ⚡ Proses Cepat\n> ✅ Garansi Uang Kembali\n> ✅ Aman & Terpercaya\n\n*© PT ZANNPAY INDONESIA*\n---------------------------------------\n`;
    let productsFound = false;
    data10.forEach(function(product) {
        if (product.category === "Data" && product.brand === "by.U") {
            productsFound = true;
            const status = product.seller_product_status ? "Ready" : "Sold Out";
            const statusEmoji = product.seller_product_status ? "✅" : "❌";
            let stock_display = product.stock === 0 ? "∞" : product.stock;
            let produknya = `≫ *${product.product_name}*`;
            formattedResponse += `
${produknya}

> Kode : ${product.buyer_sku_code}
> Status : ${statusEmoji} ${status}
> Harga : ${formatmoney(product.price)}
> Kategori : ${product.category}
> Tipe : ${product.type}
> Stock : ${stock_display}
> Deskripsi : ${product.desc}
> Cara Order : Reply pesan ini dengan *${prefix}order ${product.buyer_sku_code} <tujuan/userid/zone>*

---------------------------------------
`;
        }
    });

    if (!productsFound) {
        formattedResponse += "Oops, produk tidak tersedia saat ini.";
    }

    AnanthaGanz.sendMessage(m.chat, {
        text: formattedResponse,
        contextInfo: {
            externalAdReply: {
                title: `${footer}`,
                thumbnailUrl: `https://i.ibb.co/0KGj27t/20240223-202951.jpg`,
                sourceUrl: `https://wa.me/${botNumber}?text=menu`,
                mediaType: 1,
                renderLargerThumbnail: true
            }
        }
    }, { quoted: fdocc });
}
break;

case 'v-by.u': {
if (cek("verfiyemail", m.sender) == true) return reply(`Oops, Silahkan Daftarkan Email anda\nContoh : .setemail xxxxx@gmail.com`);
    if (cek("cekVerify", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, `Oops, Silahkan Verifikasi Email : ${cek("email", m.sender)}`, ['Verifikasicode','Hubungi Admin']);
    if(cek("syarat", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, 'Oops, Kamu Belum Menyetujui Syarat Ketentuan dari kami. Mohon setujuin dulu, agar dapat mengakses fitur dari kami.', ['Saya Setuju','Syarat nya apa aja']);
    let data10 = JSON.parse(fs.readFileSync('./SETTING/DB/datadigiflaz.json'));
    data10.sort((a, b) => a.price - b.price);
    let formattedResponse = `*===[ VOUCHER by.U ]===*\n\n> 🪀 24/7\n> ⚡ Proses Cepat\n> ✅ Garansi Uang Kembali\n> ✅ Aman & Terpercaya\n\n*© PT ZANNPAY INDONESIA*\n---------------------------------------\n`;
    let productsFound = false;
    data10.forEach(function(product) {
        if (product.category === "Voucher" && product.brand === "by.U") {
            productsFound = true;
            const status = product.seller_product_status ? "Ready" : "Sold Out";
            const statusEmoji = product.seller_product_status ? "✅" : "❌";
            let stock_display = product.stock === 0 ? "∞" : product.stock;
            let produknya = `≫ *${product.product_name}*`;
            formattedResponse += `
${produknya}

> Kode : ${product.buyer_sku_code}
> Status : ${statusEmoji} ${status}
> Harga : ${formatmoney(product.price)}
> Kategori : ${product.category}
> Tipe : ${product.type}
> Stock : ${stock_display}
> Deskripsi : ${product.desc}
> Cara Order : Reply pesan ini dengan *${prefix}order ${product.buyer_sku_code} <tujuan/userid/zone>*

---------------------------------------
`;
        }
    });

    if (!productsFound) {
        formattedResponse += "Oops, produk tidak tersedia saat ini.";
    }

    AnanthaGanz.sendMessage(m.chat, {
        text: formattedResponse,
        contextInfo: {
            externalAdReply: {
                title: `${footer}`,
                thumbnailUrl: `https://i.ibb.co/0KGj27t/20240223-202951.jpg`,
                sourceUrl: `https://wa.me/${botNumber}?text=menu`,
                mediaType: 1,
                renderLargerThumbnail: true
            }
        }
    }, { quoted: fdocc });
}
break;

case 't-by.u': {
if (cek("verfiyemail", m.sender) == true) return reply(`Oops, Silahkan Daftarkan Email anda\nContoh : .setemail xxxxx@gmail.com`);
    if (cek("cekVerify", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, `Oops, Silahkan Verifikasi Email : ${cek("email", m.sender)}`, ['Verifikasicode','Hubungi Admin']);
    if(cek("syarat", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, 'Oops, Kamu Belum Menyetujui Syarat Ketentuan dari kami. Mohon setujuin dulu, agar dapat mengakses fitur dari kami.', ['Saya Setuju','Syarat nya apa aja']);
    let data10 = JSON.parse(fs.readFileSync('./SETTING/DB/datadigiflaz.json'));
    data10.sort((a, b) => a.price - b.price);
    let formattedResponse = `*===[ PULSA TRANSFER by.U ]===*\n\n> 🪀 24/7\n> ⚡ Proses Cepat\n> ✅ Garansi Uang Kembali\n> ✅ Aman & Terpercaya\n\n*© PT ZANNPAY INDONESIA*\n---------------------------------------\n`;
    let productsFound = false;
    data10.forEach(function(product) {
        if (product.category === "Pulsa" && product.brand === "by.U" && product.type === "Pulsa Transfer") {
            productsFound = true;
            const status = product.seller_product_status ? "Ready" : "Sold Out";
            const statusEmoji = product.seller_product_status ? "✅" : "❌";
            let stock_display = product.stock === 0 ? "∞" : product.stock;
            let produknya = `≫ *${product.product_name}*`;
            formattedResponse += `
${produknya}

> Kode : ${product.buyer_sku_code}
> Status : ${statusEmoji} ${status}
> Harga : ${formatmoney(product.price)}
> Kategori : ${product.category}
> Tipe : ${product.type}
> Stock : ${stock_display}
> Deskripsi : ${product.desc}
> Cara Order : Reply pesan ini dengan *${prefix}order ${product.buyer_sku_code} <tujuan/userid/zone>*

---------------------------------------
`;
        }
    });

    if (!productsFound) {
        formattedResponse += "Oops, produk tidak tersedia saat ini.";
    }

    AnanthaGanz.sendMessage(m.chat, {
        text: formattedResponse,
        contextInfo: {
            externalAdReply: {
                title: `${footer}`,
                thumbnailUrl: `https://i.ibb.co/0KGj27t/20240223-202951.jpg`,
                sourceUrl: `https://wa.me/${botNumber}?text=menu`,
                mediaType: 1,
                renderLargerThumbnail: true
            }
        }
    }, { quoted: fdocc });
}
break;

case 'p-by.u': {
if (cek("verfiyemail", m.sender) == true) return reply(`Oops, Silahkan Daftarkan Email anda\nContoh : .setemail xxxxx@gmail.com`);
    if (cek("cekVerify", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, `Oops, Silahkan Verifikasi Email : ${cek("email", m.sender)}`, ['Verifikasicode','Hubungi Admin']);
    if(cek("syarat", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, 'Oops, Kamu Belum Menyetujui Syarat Ketentuan dari kami. Mohon setujuin dulu, agar dapat mengakses fitur dari kami.', ['Saya Setuju','Syarat nya apa aja']);
    let data10 = JSON.parse(fs.readFileSync('./SETTING/DB/datadigiflaz.json'));
    data10.sort((a, b) => a.price - b.price);
        let formattedResponse = `*===[ PULSA REGULER by.U ]===*\n\n> 🪀 24/7\n> ⚡ Proses Cepat\n> ✅ Garansi Uang Kembali\n> ✅ Aman & Terpercaya\n\n*© PT ZANNPAY INDONESIA*\n---------------------------------------\n`;
    let productsFound = false;
    data10.forEach(function(product) {
        if (product.category === "Pulsa" && product.brand === "by.U" && product.type === "Umum") {
            productsFound = true;
            const status = product.seller_product_status ? "Ready" : "Sold Out";
            const statusEmoji = product.seller_product_status ? "✅" : "❌";
            let stock_display = product.stock === 0 ? "∞" : product.stock;
            let produknya = `≫ *${product.product_name}*`;
            formattedResponse += `
${produknya}

> Kode : ${product.buyer_sku_code}
> Status : ${statusEmoji} ${status}
> Harga : ${formatmoney(product.price)}
> Kategori : ${product.category}
> Tipe : ${product.type}
> Stock : ${stock_display}
> Deskripsi : ${product.desc}
> Cara Order : Reply pesan ini dengan *${prefix}order ${product.buyer_sku_code} <tujuan/userid/zone>*

---------------------------------------
`;
        }
    });

    if (!productsFound) {
        formattedResponse += "Oops, produk tidak tersedia saat ini.";
    }

    AnanthaGanz.sendMessage(m.chat, {
        text: formattedResponse,
        contextInfo: {
            externalAdReply: {
                title: `${footer}`,
                thumbnailUrl: `https://i.ibb.co/0KGj27t/20240223-202951.jpg`,
                sourceUrl: `https://wa.me/${botNumber}?text=menu`,
                mediaType: 1,
                renderLargerThumbnail: true
            }
        }
    }, { quoted: fdocc });
}
break;
case 'setstatus': case 'setbiobot': case 'setbotbio': {
if (cek("verfiyemail", m.sender) == true) return reply(`Oops, Silahkan Daftarkan Email anda\nContoh : .setemail xxxxx@gmail.com`);
    if (cek("cekVerify", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, `Oops, Silahkan Verifikasi Email : ${cek("email", m.sender)}`, ['Verifikasicode','Hubungi Admin']);
    if(cek("syarat", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, 'Oops, Kamu Belum Menyetujui Syarat Ketentuan dari kami. Mohon setujuin dulu, agar dapat mengakses fitur dari kami.', ['Saya Setuju','Syarat nya apa aja']);
            if (!text) throw `this is a WhatsApp Bot named Hisoka-Morou`
            let name = await AnanthaGanz.updateProfileStatus(text)
            m.reply(`Successfully changed bot bio status to ${name}`)
            }
            break
                        case 'listpc': {
                 let anu = await store.chats.all().filter(v => v.id.endsWith('.net')).map(v => v.id)
                 let teks = `⬣ *LIST PERSONAL CHAT*\n\nTotal Chat : ${anu.length} Chat\n\n`
                 for (let i of anu) {
                     let nama = store.messages[i].array[0].pushName
                     teks += `⬡ *Nama :* ${nama}\n⬡ *User :* @${i.split('@')[0]}\n⬡ *Chat :* https://wa.me/${i.split('@')[0]}\n\n────────────────────────\n\n`
                 }
                 AnanthaGanz.sendTextWithMentions(m.chat, teks, m)
             }
             break
             case 'listgc': {
                 let anu = await store.chats.all().filter(v => v.id.endsWith('@g.us')).map(v => v.id)
                 let teks = `⬣ *LIST GROUP CHAT*\n\nTotal Group : ${anu.length} Group\n\n`
                 for (let i of anu) {
                     let metadata = await AnanthaGanz.groupMetadata(i)
                     teks += `⬡ *Nama :* ${metadata.subject}\n⬡ *Owner :* ${metadata.owner !== undefined ? '@' + metadata.owner.split`@`[0] : 'Tidak diketahui'}\n⬡ *ID :* ${metadata.id}\n⬡ *Dibuat :* ${moment(metadata.creation * 1000).tz('Asia/Jakarta').format('DD/MM/YYYY HH:mm:ss')}\n⬡ *Member :* ${metadata.participants.length}\n\n────────────────────────\n\n`
                 }
                 AnanthaGanz.sendTextWithMentions(m.chat, teks, m)
             }
             break
             case 'listonline': case 'liston': {
                    let id = args && /\d+\-\d+@g.us/.test(args[0]) ? args[0] : m.chat
                    let online = [...Object.keys(store.presences[id]), botNumber]
                    AnanthaGanz.sendText(m.chat, 'List Online:\n\n' + online.map(v => '⭔ @' + v.replace(/@.+/, '')).join`\n`, m, { mentions: online })
             }
             break
                     case 'simih': case 'simisimi': {
            if (!text) throw `Example : ${prefix + command} text`
            hm = await fetchJson(api('zenz', '/api/simisimi', { text : text }, 'apikey'))
            m.reply(hm.result.message)
            }
            break
            case 'imagenobg': case 'removebg': case 'remove-bg': {
	    if (!/image/.test(mime)) throw `Kirim/Reply Image Dengan Caption ${prefix + command}`
	    if (/webp/.test(mime)) throw `Kirim/Reply Image Dengan Caption ${prefix + command}`
	    let remobg = require('remove.bg')
	    let apirnobg = ['q61faXzzR5zNU6cvcrwtUkRU','S258diZhcuFJooAtHTaPEn4T','5LjfCVAp4vVNYiTjq9mXJWHF','aT7ibfUsGSwFyjaPZ9eoJc61','BY63t7Vx2tS68YZFY6AJ4HHF','5Gdq1sSWSeyZzPMHqz7ENfi8','86h6d6u4AXrst4BVMD9dzdGZ','xp8pSDavAgfE5XScqXo9UKHF','dWbCoCb3TacCP93imNEcPxcL']
	    let apinobg = apirnobg[Math.floor(Math.random() * apirnobg.length)]
	    hmm = await './src/remobg-'+getRandom('')
	    localFile = await AnanthaGanz.downloadAndSaveMediaMessage(qmsg, hmm)
	    outputFile = await './src/hremo-'+getRandom('.png')
	    m.reply(mess.wait)
	    remobg.removeBackgroundFromImageFile({
	      path: localFile,
	      apiKey: apinobg,
	      size: "regular",
	      type: "auto",
	      scale: "100%",
	      outputFile 
	    }).then(async result => {
	    AnanthaGanz.sendMessage(m.chat, {image: fs.readFileSync(outputFile), caption: mess.success}, { quoted : m })
	    await fs.unlinkSync(localFile)
	    await fs.unlinkSync(outputFile)
	    })
	    }
	    break
	    case 'google': {
                if (!text) throw `Example : ${prefix + command} fatih arridho`
                let google = require('google-it')
                google({'query': text}).then(res => {
                let teks = `Google Search From : ${text}\n\n`
                for (let g of res) {
                teks += `⭔ *Title* : ${g.title}\n`
                teks += `⭔ *Description* : ${g.snippet}\n`
                teks += `⭔ *Link* : ${g.link}\n\n────────────────────────\n\n`
                } 
                m.reply(teks)
                })
                }
                break
  case 'hapus_akun':{
  AnanthaGanz.sendPoll(m.chat, "Apakah Ada Yakin Untuk Menghapus Akun Anda?semua data deposit dll akan ilang", ['HapusAkun Aja','GaJadi Hapus']);
  }
  break
  case 'hapusakun':
    const index = user.findIndex(u => u.id === m.sender);
    if (index !== -1) {
        // Hapus akun dari user.json
        setTimeout(() => {
            user.splice(index, 1);
            fs.writeFileSync('./SETTING/DB/user.json', JSON.stringify(user));
        }, 3000);
        console.log("Akun telah berhasil dihapus.");
        // Tambahkan pesan respons langsung
        reply("Akun Anda telah berhasil dihapus.");
        
        // Hapus riwayat deposit dari depouser.json
        const depoFilePath = './SETTING/DB/TRANSACTION/depouser.json';
        setTimeout(() => {
            try {
                // Baca file JSON
                const depoFileData = fs.readFileSync(depoFilePath, 'utf8');
                let allDepoUserData = JSON.parse(depoFileData);

                // Filter data untuk m.sender tertentu
                const depoUserData = allDepoUserData.filter(data => data.buyer === m.sender);

                if (depoUserData.length > 0) {
                    // Hapus data dari file JSON
                    allDepoUserData = allDepoUserData.filter(data => data.buyer !== m.sender);
                    fs.writeFileSync(depoFilePath, JSON.stringify(allDepoUserData));
                }
            } catch (error) {
                console.error("Error:", error);
            }
        }, 5000);
        
        // Hapus riwayat transaksi dari trxuser.json
        const trxFilePath = './SETTING/DB/trxuser.json';
        try {
            // Baca file JSON
            const trxFileData = fs.readFileSync(trxFilePath, 'utf8');
            let allTrxUserData = JSON.parse(trxFileData);

            // Filter data untuk m.sender tertentu
            const trxUserData = allTrxUserData.filter(data => data.buyer === m.sender);

            if (trxUserData.length > 0) {
                // Hapus data dari file JSON
                allTrxUserData = allTrxUserData.filter(data => data.buyer !== m.sender);
                fs.writeFileSync(trxFilePath, JSON.stringify(allTrxUserData));
            }
        } catch (error) {
            console.error("Error:", error);
        }
    } else {
        console.log("Pengguna tidak ditemukan.");
        // Tambahkan pesan respons langsung
        reply("Maaf, akun Anda tidak ditemukan.");
    }
    break;
    case 'editnama': {
    // Memeriksa apakah pengguna adalah pemilik bot
    if (!isOwner) return reply(mess.owner);
    
    // Memisahkan argumen dari pesan
    const args = text.split(' ');

    // Memeriksa apakah jumlah argumen sesuai
    if (args.length < 2) {
        reply(`Contoh: ${prefix}editnama <buyer_sku_code> <new_product_name>`);
        return;
    }
    
    // Mendapatkan kode SKU pembeli dan nama produk baru dari argumen
    const buyerSkuCode = args[0];
    const newProductName = args.slice(1).join(' '); 
    
    // Mendapatkan data customer_kode dari file JSON
    let jsonData;
    try {
        jsonData = JSON.parse(fs.readFileSync('./SETTING/DB/datadigiflaz.json', 'utf8'));
    } catch (error) {
        reply("Error reading 'datadigiflaz.json': " + error.message);
        return;
    }
    
    let updated = false;
    let oldProductName = '';
    
    // Iterasi untuk mencari customer_kode dengan kode SKU yang sesuai
    for (let product of jsonData) {
        if (product.buyer_sku_code === buyerSkuCode) {
            // Menyimpan nama produk lama
            oldProductName = product.product_name;
            
            // Memperbarui nama produk
            product.product_name = newProductName;
            updated = true;
            break;
        }
    }
    
    // Menulis kembali data customer_kode ke file JSON jika ada pembaruan
    if (updated) {
        fs.writeFileSync('./SETTING/DB/datadigiflaz.json', JSON.stringify(jsonData, null, 2), 'utf8');
        
        // Memberikan balasan dengan informasi tentang produk yang diperbarui
        reply(`Nama produk dengan KODE SKU ${buyerSkuCode} berhasil diperbarui.\nNama sebelumnya: ${oldProductName}\nNama baru: ${newProductName}`);
    } else {
        reply(`Gagal, Produk dengan KODE SKU ${buyerSkuCode} tidak ditemukan`);
    }
    break;
}
// E WALLET CEK
 case 'cekdana-wallet':{
if (cek("verfiyemail", m.sender) == true) return reply(`Oops, Silahkan Daftarkan Email anda\nContoh : .setemail xxxxx@gmail.com`);
    if (cek("cekVerify", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, `Oops, Silahkan Verifikasi Email : ${cek("email", m.sender)}`, ['Verifikasicode','Hubungi Admin']);
if(cek("syarat", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, 'Oops, Kamu Belum Menyetujui Syarat Ketentuan dari kami. Mohon setujuin dulu, agar dapat mengakses fitur dari kami.', ['Saya Setuju','Syarat nya apa aja']);
if(cek("level", m.sender) == "Basic") return reply(`Oops, Fitur Ini Khusus Untuk Akun Premium! Silahkan Upgrade akun anda`)
let axios = require('axios');
const id = args[0];
        if (!id) {
          return reply(`E WALLET : DANA \nMasukan No Hp, contoh:\n*.cekdana-wallet* 087837456208`)
        }
const url = `https://${global.APIcek}/api/dana-ewallet/?target=${id}&api_key=${global.KEYcek}`

axios.get(url)
  .then(response => {
  console.log(response.data);
      reply(`「 *AKUN DANA* 」\n\n> Nama : ${response.data.data.nickname}\n> No : ${args[0]}\n\n${toko}`);
  })
  .catch(error => {
    console.error(error.response.data);
    if(error.response.data.code == "404") {
    reply("Oops, Akun Tidak Dapat ditemukan")
    } else if ( error.response.data.code = "422") {
    reply("Oops, Silahkan Input No dengan benar")
    }
  });
  }
  break
  case 'cekovo-wallet':{
if (cek("verfiyemail", m.sender) == true) return reply(`Oops, Silahkan Daftarkan Email anda\nContoh : .setemail xxxxx@gmail.com`);
    if (cek("cekVerify", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, `Oops, Silahkan Verifikasi Email : ${cek("email", m.sender)}`, ['Verifikasicode','Hubungi Admin']);
if(cek("syarat", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, 'Oops, Kamu Belum Menyetujui Syarat Ketentuan dari kami. Mohon setujuin dulu, agar dapat mengakses fitur dari kami.', ['Saya Setuju','Syarat nya apa aja']);
if(cek("level", m.sender) == "Basic") return reply(`Oops, Fitur Ini Khusus Untuk Akun Premium! Silahkan Upgrade akun anda`)
let axios = require('axios');
const id = args[0];
        if (!id) {
          return reply(`E WALLET : OVO \nMasukan No Hp, contoh:\n*.cekovo-wallet* 087837456208`)
        }
const url = `https://${global.APIcek}/api/ovo-ewallet/?target=${id}&api_key=${global.KEYcek}`

axios.get(url)
  .then(response => {
  console.log(response.data);
      reply(`「 *AKUN OVO* 」\n\n> Nama : ${response.data.data.nickname}\n> No : ${args[0]}\n\n${toko}`);
  })
  .catch(error => {
    console.error(error.response.data);
    if(error.response.data.code == "404") {
    reply("Oops, Akun Tidak Dapat ditemukan")
    } else if ( error.response.data.code = "422") {
    reply("Oops, Silahkan Input No dengan benar")
    }
  });
  }
  break
  case 'cekgopay-wallet':{
if (cek("verfiyemail", m.sender) == true) return reply(`Oops, Silahkan Daftarkan Email anda\nContoh : .setemail xxxxx@gmail.com`);
    if (cek("cekVerify", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, `Oops, Silahkan Verifikasi Email : ${cek("email", m.sender)}`, ['Verifikasicode','Hubungi Admin']);
if(cek("syarat", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, 'Oops, Kamu Belum Menyetujui Syarat Ketentuan dari kami. Mohon setujuin dulu, agar dapat mengakses fitur dari kami.', ['Saya Setuju','Syarat nya apa aja']);
if(cek("level", m.sender) == "Basic") return reply(`Oops, Fitur Ini Khusus Untuk Akun Premium! Silahkan Upgrade akun anda`)
let axios = require('axios');
const id = args[0];
        if (!id) {
          return reply(`E WALLET : GOPAY \nMasukan No Hp, contoh:\n*.cekgopay-wallet* 087837456208`)
        }
const url = `https://${global.APIcek}/api/gopay-ewallet/?target=${id}&api_key=${global.KEYcek}`

axios.get(url)
  .then(response => {
  console.log(response.data);
      reply(`「 *AKUN GOPAY* 」\n\n> Nama : ${response.data.data.nickname}\n> No : ${args[0]}\n\n${toko}`);
  })
  .catch(error => {
    console.error(error.response.data);
    if(error.response.data.code == "404") {
    reply("Oops, Akun Tidak Dapat ditemukan")
    } else if ( error.response.data.code = "422") {
    reply("Oops, Silahkan Input No dengan benar")
    }
  });
  }
  break
  case 'ceklinkaja-wallet':{
if (cek("verfiyemail", m.sender) == true) return reply(`Oops, Silahkan Daftarkan Email anda\nContoh : .setemail xxxxx@gmail.com`);
    if (cek("cekVerify", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, `Oops, Silahkan Verifikasi Email : ${cek("email", m.sender)}`, ['Verifikasicode','Hubungi Admin']);
if(cek("syarat", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, 'Oops, Kamu Belum Menyetujui Syarat Ketentuan dari kami. Mohon setujuin dulu, agar dapat mengakses fitur dari kami.', ['Saya Setuju','Syarat nya apa aja']);
if(cek("level", m.sender) == "Basic") return reply(`Oops, Fitur Ini Khusus Untuk Akun Premium! Silahkan Upgrade akun anda`)
let axios = require('axios');
const id = args[0];
        if (!id) {
          return reply(`E WALLET : LINKAJA \nMasukan No Hp, contoh:\n*.ceklinkaja-wallet* 087837456208`)
        }
const url = `https://${global.APIcek}/api/link-aja-ewallet/?target=${id}&api_key=${global.KEYcek}`

axios.get(url)
  .then(response => {
  console.log(response.data);
      reply(`「 *AKUN LINKAJA* 」\n\n> Nama : ${response.data.data.nickname}\n> No : ${args[0]}\n\n${toko}`);
  })
  .catch(error => {
    console.error(error.response.data);
    if(error.response.data.code == "404") {
    reply("Oops, Akun Tidak Dapat ditemukan")
    } else if ( error.response.data.code = "422") {
    reply("Oops, Silahkan Input No dengan benar")
    }
  });
  }
  break
    case 'cekshopeepay-wallet':{
if (cek("verfiyemail", m.sender) == true) return reply(`Oops, Silahkan Daftarkan Email anda\nContoh : .setemail xxxxx@gmail.com`);
    if (cek("cekVerify", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, `Oops, Silahkan Verifikasi Email : ${cek("email", m.sender)}`, ['Verifikasicode','Hubungi Admin']);
if(cek("syarat", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, 'Oops, Kamu Belum Menyetujui Syarat Ketentuan dari kami. Mohon setujuin dulu, agar dapat mengakses fitur dari kami.', ['Saya Setuju','Syarat nya apa aja']);
if(cek("level", m.sender) == "Basic") return reply(`Oops, Fitur Ini Khusus Untuk Akun Premium! Silahkan Upgrade akun anda`)
let axios = require('axios');
const id = args[0];
        if (!id) {
          return reply(`E WALLET : SHOPEEPAY \nMasukan No Hp, contoh:\n*.ceklinkaja-wallet* 087837456208`)
        }
const url = `https://${global.APIcek}/api/shopee-pay-ewallet/?target=${id}&api_key=${global.KEYcek}`

axios.get(url)
  .then(response => {
  console.log(response.data);
      reply(`「 *AKUN SHOPEEPAY* 」\n\n> Nama : ${response.data.data.nickname}\n> No : ${args[0]}\n\n${toko}`);
  })
  .catch(error => {
    console.error(error.response.data);
    if(error.response.data.code == "404") {
    reply("Oops, Akun Tidak Dapat ditemukan")
    } else if ( error.response.data.code = "422") {
    reply("Oops, Silahkan Input No dengan benar")
    }
  });
  }
  break
 
 // GAMES CEKNICKNAME 
case 'cekff':{
if (cek("verfiyemail", m.sender) == true) return reply(`Oops, Silahkan Daftarkan Email anda\nContoh : .setemail xxxxx@gmail.com`);
    if (cek("cekVerify", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, `Oops, Silahkan Verifikasi Email : ${cek("email", m.sender)}`, ['Verifikasicode','Hubungi Admin']);
if(cek("syarat", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, 'Oops, Kamu Belum Menyetujui Syarat Ketentuan dari kami. Mohon setujuin dulu, agar dapat mengakses fitur dari kami.', ['Saya Setuju','Syarat nya apa aja']);
if(cek("level", m.sender) == "Basic") return reply(`Oops, Fitur Ini Khusus Untuk Akun Premium! Silahkan Upgrade akun anda`)
let axios = require('axios');
const id = args[0];
        if (!id) {
          return reply(`GAME : FREE FIRE \nMasukan ID dan Server dengan benar, contoh:\n*.cekff* 7194234362`)
        }
const url = `https://${global.APIcek}/api/free-fire/?target=${id}&api_key=${global.KEYcek}`

axios.get(url)
  .then(response => {
  console.log(response.data);
      reply(`「 *Free Fire* 」\n\n> Username : ${response.data.data.nickname}\n> ID : ${args[0]}\n\n${toko}`);
  })
  .catch(error => {
    console.error(error.response.data);
    if(error.response.data.code == "404") {
    reply("Oops, Nickname Tidak Dapat ditemukan")
    } else if ( error.response.data.code = "422") {
    reply("Oops, Silahkan Input Userid dengan benar")
    }
  });
  }
  break
  case 'cekvalo':{
if (cek("verfiyemail", m.sender) == true) return reply(`Oops, Silahkan Daftarkan Email anda\nContoh : .setemail xxxxx@gmail.com`);
    if (cek("cekVerify", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, `Oops, Silahkan Verifikasi Email : ${cek("email", m.sender)}`, ['Verifikasicode','Hubungi Admin']);
if(cek("syarat", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, 'Oops, Kamu Belum Menyetujui Syarat Ketentuan dari kami. Mohon setujuin dulu, agar dapat mengakses fitur dari kami.', ['Saya Setuju','Syarat nya apa aja']);
if(cek("level", m.sender) == "Basic") return reply(`Oops, Fitur Ini Khusus Untuk Akun Premium! Silahkan Upgrade akun anda`)
let axios = require('axios');
const id = args[0];
        if (!id) {
          return reply(`GAME : VALORANT \nMasukan ID dan Server dengan benar, contoh:\n*.cekvalo* Nyx%236477`)
        }
const url = `https://${global.APIcek}/api/valorant/?target=${id}&api_key=${global.KEYcek}`

axios.get(url)
  .then(response => {
  console.log(response.data);
      reply(`「 *Valorant* 」\n\n> Username : ${response.data.data.nickname}\n> ID : ${args[0]}\n\n${toko}`);
  })
  .catch(error => {
    console.error(error.response.data);
    if(error.response.data.code == "404") {
    reply("Oops, Nickname Tidak Dapat ditemukan")
    } else if ( error.response.data.code = "422") {
    reply("Oops, Silahkan Input Userid dengan benar")
    }
  });
  }
  break
  case 'cekpb':{
if (cek("verfiyemail", m.sender) == true) return reply(`Oops, Silahkan Daftarkan Email anda\nContoh : .setemail xxxxx@gmail.com`);
    if (cek("cekVerify", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, `Oops, Silahkan Verifikasi Email : ${cek("email", m.sender)}`, ['Verifikasicode','Hubungi Admin']);
if(cek("syarat", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, 'Oops, Kamu Belum Menyetujui Syarat Ketentuan dari kami. Mohon setujuin dulu, agar dapat mengakses fitur dari kami.', ['Saya Setuju','Syarat nya apa aja']);
if(cek("level", m.sender) == "Basic") return reply(`Oops, Fitur Ini Khusus Untuk Akun Premium! Silahkan Upgrade akun anda`)
let axios = require('axios');
const id = args[0];
        if (!id) {
          return reply(`GAME : POINT BLANK \nMasukan ID dan Server dengan benar, contoh:\n*.cekpb* catsdoto`)
        }
const url = `https://${global.APIcek}/api/point-blank/?target=${id}&api_key=${global.KEYcek}`

axios.get(url)
  .then(response => {
  console.log(response.data);
      reply(`「 *Point Blank* 」\n\n> Username : ${response.data.data.nickname}\n> ID : ${args[0]}\n\n${toko}`);
  })
  .catch(error => {
    console.error(error.response.data);
    if(error.response.data.code == "404") {
    reply("Oops, Nickname Tidak Dapat ditemukan")
    } else if ( error.response.data.code = "422") {
    reply("Oops, Silahkan Input Userid dengan benar")
    }
  });
  }
  break
  case 'ceksausageman':{
if (cek("verfiyemail", m.sender) == true) return reply(`Oops, Silahkan Daftarkan Email anda\nContoh : .setemail xxxxx@gmail.com`);
    if (cek("cekVerify", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, `Oops, Silahkan Verifikasi Email : ${cek("email", m.sender)}`, ['Verifikasicode','Hubungi Admin']);
if(cek("syarat", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, 'Oops, Kamu Belum Menyetujui Syarat Ketentuan dari kami. Mohon setujuin dulu, agar dapat mengakses fitur dari kami.', ['Saya Setuju','Syarat nya apa aja']);
if(cek("level", m.sender) == "Basic") return reply(`Oops, Fitur Ini Khusus Untuk Akun Premium! Silahkan Upgrade akun anda`)
let axios = require('axios');
const id = args[0];
        if (!id) {
          return reply(`GAME : SAUSAGEMAN \nMasukan ID dan Server dengan benar, contoh:\n*.ceksausageman* 5sn9jf`)
        }
const url = `https://${global.APIcek}/api/sausageman/?target=${id}&api_key=${global.KEYcek}`

axios.get(url)
  .then(response => {
  console.log(response.data);
      reply(`「 *SauSageman* 」\n\n> Username : ${response.data.data.nickname}\n> ID : ${args[0]}\n\n${toko}`);
  })
  .catch(error => {
    console.error(error.response.data);
    if(error.response.data.code == "404") {
    reply("Oops, Nickname Tidak Dapat ditemukan")
    } else if ( error.response.data.code = "422") {
    reply("Oops, Silahkan Input Userid dengan benar")
    }
  });
  }
  break
  case 'cekhi3':{
if (cek("verfiyemail", m.sender) == true) return reply(`Oops, Silahkan Daftarkan Email anda\nContoh : .setemail xxxxx@gmail.com`);
    if (cek("cekVerify", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, `Oops, Silahkan Verifikasi Email : ${cek("email", m.sender)}`, ['Verifikasicode','Hubungi Admin']);
if(cek("syarat", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, 'Oops, Kamu Belum Menyetujui Syarat Ketentuan dari kami. Mohon setujuin dulu, agar dapat mengakses fitur dari kami.', ['Saya Setuju','Syarat nya apa aja']);
if(cek("level", m.sender) == "Basic") return reply(`Oops, Fitur Ini Khusus Untuk Akun Premium! Silahkan Upgrade akun anda`)
let axios = require('axios');
const id = args[0];
        if (!id) {
          return reply(`GAME : Honkai Impact 3 \nMasukan ID dan Server dengan benar, contoh:\n*.cekhi3* 14629300`)
        }
const url = `https://${global.APIcek}/api/honkai-impact/?target=${id}&api_key=${global.KEYcek}`

axios.get(url)
  .then(response => {
  console.log(response.data);
      reply(`「 *Honkai Impact 3* 」\n\n> Username : ${response.data.data.nickname}\n> ID : ${args[0]}\n\n${toko}`);
  })
  .catch(error => {
    console.error(error.response.data);
    if(error.response.data.code == "404") {
    reply("Oops, Nickname Tidak Dapat ditemukan")
    } else if ( error.response.data.code = "422") {
    reply("Oops, Silahkan Input Userid dengan benar")
    }
  });
  }
  break
   case 'cekcod':{
if (cek("verfiyemail", m.sender) == true) return reply(`Oops, Silahkan Daftarkan Email anda\nContoh : .setemail xxxxx@gmail.com`);
    if (cek("cekVerify", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, `Oops, Silahkan Verifikasi Email : ${cek("email", m.sender)}`, ['Verifikasicode','Hubungi Admin']);
if(cek("syarat", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, 'Oops, Kamu Belum Menyetujui Syarat Ketentuan dari kami. Mohon setujuin dulu, agar dapat mengakses fitur dari kami.', ['Saya Setuju','Syarat nya apa aja']);
if(cek("level", m.sender) == "Basic") return reply(`Oops, Fitur Ini Khusus Untuk Akun Premium! Silahkan Upgrade akun anda`)
let axios = require('axios');
const id = args[0];
        if (!id) {
          return reply(`GAME : Call Of Duty \nMasukan ID dan Server dengan benar, contoh:\n*.cekcod* 3661482077829392935`)
        }
const url = `https://${global.APIcek}/api/callofduty/?target=${id}&api_key=${global.KEYcek}`

axios.get(url)
  .then(response => {
  console.log(response.data);
      reply(`「 *Call Of Duty* 」\n\n> Username : ${response.data.data.nickname}\n> ID : ${args[0]}\n\n${toko}`);
  })
  .catch(error => {
    console.error(error.response.data);
    if(error.response.data.code == "404") {
    reply("Oops, Nickname Tidak Dapat ditemukan")
    } else if ( error.response.data.code = "422") {
    reply("Oops, Silahkan Input Userid dengan benar")
    }
  });
  }
  break
  case 'cekaov':{
if (cek("verfiyemail", m.sender) == true) return reply(`Oops, Silahkan Daftarkan Email anda\nContoh : .setemail xxxxx@gmail.com`);
    if (cek("cekVerify", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, `Oops, Silahkan Verifikasi Email : ${cek("email", m.sender)}`, ['Verifikasicode','Hubungi Admin']);
if(cek("syarat", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, 'Oops, Kamu Belum Menyetujui Syarat Ketentuan dari kami. Mohon setujuin dulu, agar dapat mengakses fitur dari kami.', ['Saya Setuju','Syarat nya apa aja']);
if(cek("level", m.sender) == "Basic") return reply(`Oops, Fitur Ini Khusus Untuk Akun Premium! Silahkan Upgrade akun anda`)
let axios = require('axios');
const id = args[0];
        if (!id) {
          return reply(`GAME : Arena Of Valor \nMasukan ID dan Server dengan benar, contoh:\n*.cekaov* 888347346994333`)
        }
const url = `https://${global.APIcek}/api/aov/?target=${id}&api_key=${global.KEYcek}`

axios.get(url)
  .then(response => {
  console.log(response.data);
      reply(`「 *Arena Of Valor* 」\n\n> Username : ${response.data.data.nickname}\n> ID : ${args[0]}\n\n${toko}`);
  })
  .catch(error => {
    console.error(error.response.data);
    if(error.response.data.code == "404") {
    reply("Oops, Nickname Tidak Dapat ditemukan")
    } else if ( error.response.data.code = "422") {
    reply("Oops, Silahkan Input Userid dengan benar")
    }
  });
  }
  break
  case 'cekau2m':{
if (cek("verfiyemail", m.sender) == true) return reply(`Oops, Silahkan Daftarkan Email anda\nContoh : .setemail xxxxx@gmail.com`);
    if (cek("cekVerify", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, `Oops, Silahkan Verifikasi Email : ${cek("email", m.sender)}`, ['Verifikasicode','Hubungi Admin']);
if(cek("syarat", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, 'Oops, Kamu Belum Menyetujui Syarat Ketentuan dari kami. Mohon setujuin dulu, agar dapat mengakses fitur dari kami.', ['Saya Setuju','Syarat nya apa aja']);
if(cek("level", m.sender) == "Basic") return reply(`Oops, Fitur Ini Khusus Untuk Akun Premium! Silahkan Upgrade akun anda`)
let axios = require('axios');
const id = args[0];
        if (!id) {
          return reply(`GAME : AU2 Mobile \nMasukan ID dan Server dengan benar, contoh:\n*.cekau2m* 3178235`)
        }
const url = `https://${global.APIcek}/api/au2m/?target=${id}&api_key=${global.KEYcek}`

axios.get(url)
  .then(response => {
  console.log(response.data);
      reply(`「 *AU2 Mobile* 」\n\n> Username : ${response.data.data.nickname}\n> ID : ${args[0]}\n\n${toko}`);
  })
  .catch(error => {
    console.error(error.response.data);
    if(error.response.data.code == "404") {
    reply("Oops, Nickname Tidak Dapat ditemukan")
    } else if ( error.response.data.code = "422") {
    reply("Oops, Silahkan Input Userid dengan benar")
    }
  });
  }
  break
  case 'cekblackcloverm':{
if (cek("verfiyemail", m.sender) == true) return reply(`Oops, Silahkan Daftarkan Email anda\nContoh : .setemail xxxxx@gmail.com`);
    if (cek("cekVerify", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, `Oops, Silahkan Verifikasi Email : ${cek("email", m.sender)}`, ['Verifikasicode','Hubungi Admin']);
if(cek("syarat", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, 'Oops, Kamu Belum Menyetujui Syarat Ketentuan dari kami. Mohon setujuin dulu, agar dapat mengakses fitur dari kami.', ['Saya Setuju','Syarat nya apa aja']);
if(cek("level", m.sender) == "Basic") return reply(`Oops, Fitur Ini Khusus Untuk Akun Premium! Silahkan Upgrade akun anda`)
let axios = require('axios');
const id = args[0];
        if (!id) {
          return reply(`GAME : BLACK CLOVER MOBILE \nMasukan ID dan Server dengan benar, contoh:\n*.cekblackcloverm* PQML1258684807`)
        }
const url = `https://${global.APIcek}/api/blackcloverm/?target=${id}&api_key=${global.KEYcek}`

axios.get(url)
  .then(response => {
  console.log(response.data);
      reply(`「 *BLACK CLOVER MOBILE* 」\n\n> Username : ${response.data.data.nickname}\n> ID : ${args[0]}\n\n${toko}`);
  })
  .catch(error => {
    console.error(error.response.data);
    if(error.response.data.code == "404") {
    reply("Oops, Nickname Tidak Dapat ditemukan")
    } else if ( error.response.data.code = "422") {
    reply("Oops, Silahkan Input Userid dengan benar")
    }
  });
  }
  break
  case 'cekdragon-raja':{
if (cek("verfiyemail", m.sender) == true) return reply(`Oops, Silahkan Daftarkan Email anda\nContoh : .setemail xxxxx@gmail.com`);
    if (cek("cekVerify", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, `Oops, Silahkan Verifikasi Email : ${cek("email", m.sender)}`, ['Verifikasicode','Hubungi Admin']);
if(cek("syarat", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, 'Oops, Kamu Belum Menyetujui Syarat Ketentuan dari kami. Mohon setujuin dulu, agar dapat mengakses fitur dari kami.', ['Saya Setuju','Syarat nya apa aja']);
if(cek("level", m.sender) == "Basic") return reply(`Oops, Fitur Ini Khusus Untuk Akun Premium! Silahkan Upgrade akun anda`)
let axios = require('axios');
const id = args[0];
        if (!id) {
          return reply(`GAME : DRAGON RAJA \nMasukan ID dan Server dengan benar, contoh:\n*.cekdragon-raja* 282830040`)
        }
const url = `https://${global.APIcek}/api/dragon-raja/?target=${id}&api_key=${global.KEYcek}`

axios.get(url)
  .then(response => {
  console.log(response.data);
      reply(`「 *Dragon Raja* 」\n\n> Username : ${response.data.data.nickname}\n> ID : ${args[0]}\n\n${toko}`);
  })
  .catch(error => {
    console.error(error.response.data);
    if(error.response.data.code == "404") {
    reply("Oops, Nickname Tidak Dapat ditemukan")
    } else if ( error.response.data.code = "422") {
    reply("Oops, Silahkan Input Userid dengan benar")
    }
  });
  }
  break
  case 'cekpln':{
if (cek("verfiyemail", m.sender) == true) return reply(`Oops, Silahkan Daftarkan Email anda\nContoh : .setemail xxxxx@gmail.com`);
    if (cek("cekVerify", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, `Oops, Silahkan Verifikasi Email : ${cek("email", m.sender)}`, ['Verifikasicode','Hubungi Admin']);
if(cek("syarat", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, 'Oops, Kamu Belum Menyetujui Syarat Ketentuan dari kami. Mohon setujuin dulu, agar dapat mengakses fitur dari kami.', ['Saya Setuju','Syarat nya apa aja']);
if(cek("level", m.sender) == "Basic") return reply(`Oops, Fitur Ini Khusus Untuk Akun Premium! Silahkan Upgrade akun anda`)
let axios = require('axios');
const id = args[0];
        if (!id) {
          return reply(`PLN PRABAYAR \nMasukan ID dengan benar, contoh:\n*.cekpln* 551200816435`)
        }
const url = `https://${global.APIcek}/api/pln-token/?target=${id}&api_key=${global.KEYcek}`

axios.get(url)
  .then(response => {
  console.log(response.data);
      reply(`「 *PLN PRABAYAR* 」\n\n> Nama : ${response.data.data.nama_pelanggan}\n> No Meter : ${response.data.data.no_pelanggan}\n> Daya : ${response.data.data.daya}\n\n${toko}`);
  })
  .catch(error => {
    console.error(error.response.data);
    if(error.response.data.code == "404") {
    reply("Oops, Nickname Tidak Dapat ditemukan")
    } else if ( error.response.data.code = "422") {
    reply("Oops, Silahkan Input Userid dengan benar")
    }
  });
  }
  break

  case 'cekgarena-undawn':{
if (cek("verfiyemail", m.sender) == true) return reply(`Oops, Silahkan Daftarkan Email anda\nContoh : .setemail xxxxx@gmail.com`);
    if (cek("cekVerify", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, `Oops, Silahkan Verifikasi Email : ${cek("email", m.sender)}`, ['Verifikasicode','Hubungi Admin']);
if(cek("syarat", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, 'Oops, Kamu Belum Menyetujui Syarat Ketentuan dari kami. Mohon setujuin dulu, agar dapat mengakses fitur dari kami.', ['Saya Setuju','Syarat nya apa aja']);
if(cek("level", m.sender) == "Basic") return reply(`Oops, Fitur Ini Khusus Untuk Akun Premium! Silahkan Upgrade akun anda`)
let axios = require('axios');
const id = args[0];
        if (!id) {
          return reply(`GAME : GARENA UNDAWN \nMasukan ID dan Server dengan benar, contoh:\n*.cekgarena-undawn* 13004216394`)
        }
const url = `https://${global.APIcek}/api/garena-undawn/?target=${id}&api_key=${global.KEYcek}`

axios.get(url)
  .then(response => {
  console.log(response.data);
      reply(`「 *Garena Undawn* 」\n\n> Username : ${response.data.data.nickname}\n> ID : ${args[0]}\n\n${toko}`);
  })
  .catch(error => {
    console.error(error.response.data);
    if(error.response.data.code == "404") {
    reply("Oops, Nickname Tidak Dapat ditemukan")
    } else if ( error.response.data.code = "422") {
    reply("Oops, Silahkan Input Userid dengan benar")
    }
  });
  }
  break
  case 'cekml':{
if (cek("verfiyemail", m.sender) == true) return reply(`Oops, Silahkan Daftarkan Email anda\nContoh : .setemail xxxxx@gmail.com`);
    if (cek("cekVerify", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, `Oops, Silahkan Verifikasi Email : ${cek("email", m.sender)}`, ['Verifikasicode','Hubungi Admin']);
if(cek("syarat", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, 'Oops, Kamu Belum Menyetujui Syarat Ketentuan dari kami. Mohon setujuin dulu, agar dapat mengakses fitur dari kami.', ['Saya Setuju','Syarat nya apa aja']);
if(cek("level", m.sender) == "Basic") return reply(`Oops, Fitur Ini Khusus Untuk Akun Premium! Silahkan Upgrade akun anda`)
let axios = require('axios');
let id = args[0];
let zone = args[1];
        if (!id || !zone) {
          return reply(`GAME : Mobile Legends\nMasukan ID dan Server dengan benar, contoh:\n*.cekml* 1374117562 15661`)
        }
const url = `https://${global.APIcek}/api/mobile-legends/?target=${id}&zone=${zone}&api_key=${global.KEYcek}`

axios.get(url)
  .then(response => {
  console.log(response.data);
      reply(`「 *Mobile Legends* 」\n\n> Username : ${response.data.data.nickname}\n> ID : ${id} (${zone})\n\n${toko}`);
  })
  .catch(error => {
    console.error(error.response.data);
    if(error.response.data.code == "404") {
    reply("Oops, Nickname Tidak Dapat ditemukan")
    } else if ( error.response.data.code = "422") {
    reply("Oops, Silahkan Input Userid dengan benar")
    }
  });
  }
  break
  case 'cekgi':{
if (cek("verfiyemail", m.sender) == true) return reply(`Oops, Silahkan Daftarkan Email anda\nContoh : .setemail xxxxx@gmail.com`);
    if (cek("cekVerify", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, `Oops, Silahkan Verifikasi Email : ${cek("email", m.sender)}`, ['Verifikasicode','Hubungi Admin']);
if(cek("syarat", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, 'Oops, Kamu Belum Menyetujui Syarat Ketentuan dari kami. Mohon setujuin dulu, agar dapat mengakses fitur dari kami.', ['Saya Setuju','Syarat nya apa aja']);
if(cek("level", m.sender) == "Basic") return reply(`Oops, Fitur Ini Khusus Untuk Akun Premium! Silahkan Upgrade akun anda`)
let axios = require('axios');
let id = args[0];
let zone = args[1];
        if (!id || !zone) {
          return reply(`GAME : Genshin Impact\nMasukan ID dan Server dengan benar,\nGunakan salah satu server :\n> Asia = os_asia\n> America = os_usa\n> Europe = os_euro\n> TW, HK, MO = os_cht\n contoh:\n*.cekgi* 815969773 os_asia`)
        }
const url = `https://${global.APIcek}/api/genshin-impact/?target=${id}&zone=${zone}&api_key=${global.KEYcek}`

axios.get(url)
  .then(response => {
  console.log(response.data);
      reply(`「 *Genshin Impact* 」\n\n> Username : ${response.data.data.nickname}\n> ID : ${id}\n> Server : ${zone}\n\n${toko}`);
  })
  .catch(error => {
    console.error(error.response.data);
    if(error.response.data.code == "404") {
    reply("Oops, Nickname Tidak Dapat ditemukan")
    } else if ( error.response.data.code = "422") {
    reply("Oops, Silahkan Input Userid dengan benar")
    }
  });
  }
  break
   case 'ceklife-after':{
if (cek("verfiyemail", m.sender) == true) return reply(`Oops, Silahkan Daftarkan Email anda\nContoh : .setemail xxxxx@gmail.com`);
    if (cek("cekVerify", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, `Oops, Silahkan Verifikasi Email : ${cek("email", m.sender)}`, ['Verifikasicode','Hubungi Admin']);
if(cek("syarat", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, 'Oops, Kamu Belum Menyetujui Syarat Ketentuan dari kami. Mohon setujuin dulu, agar dapat mengakses fitur dari kami.', ['Saya Setuju','Syarat nya apa aja']);
if(cek("level", m.sender) == "Basic") return reply(`Oops, Fitur Ini Khusus Untuk Akun Premium! Silahkan Upgrade akun anda`)
let axios = require('axios');
let id = args[0];
let zone = args[1];
        if (!id || !zone) {
          return reply(`GAME : Life After\nMasukan ID dan Server dengan benar,\nGunakan salah satu server :\n> 500001 = MiskaTown\n> 500002 = SandCastle\n> 500003 = MouthSwamp\n> 500004 = RedwoodTown\n> 500005 = Obelisk\n> 500007 = ChaosOutpost\n> 500008 = IronStride\n> 510001 = FallForest\n> 510002 = MountSnow\n> 520001 = NancyCity\n> 520002 = CharlesTown\n> 520003 = SnowHighlands\n> 520004 = Santopany\n> 520005 = LevinCity\n> 520007 = ChaosCity\n> 520008 = TwinIslands\n> 520009 = HopeWall\n> 500006 = NewLand\n> 500009 = CrystalthornSea\n> 520006 = MileStone\n> 520010 = LabyrinthSea\n contoh:\n*.ceklife-after* 22512309 520006`)
        }
const url = `https://${global.APIcek}/api/life-after/?target=${id}&zone=${zone}&api_key=${global.KEYcek}`

axios.get(url)
  .then(response => {
  console.log(response.data);
      reply(`「 *Life After* 」\n\n> Username : ${response.data.data.nickname}\n> ID : ${id}\n> Server : ${zone}\n\n${toko}`);
  })
  .catch(error => {
    console.error(error.response.data);
    if(error.response.data.code == "404") {
    reply("Oops, Nickname Tidak Dapat ditemukan")
    } else if ( error.response.data.code = "422") {
    reply("Oops, Silahkan Input Userid dengan benar")
    }
  });
  }
  break
  case 'cekhsr':{
if (cek("verfiyemail", m.sender) == true) return reply(`Oops, Silahkan Daftarkan Email anda\nContoh : .setemail xxxxx@gmail.com`);
    if (cek("cekVerify", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, `Oops, Silahkan Verifikasi Email : ${cek("email", m.sender)}`, ['Verifikasicode','Hubungi Admin']);
if(cek("syarat", m.sender) == true) return AnanthaGanz.sendPoll(m.chat, 'Oops, Kamu Belum Menyetujui Syarat Ketentuan dari kami. Mohon setujuin dulu, agar dapat mengakses fitur dari kami.', ['Saya Setuju','Syarat nya apa aja']);
if(cek("level", m.sender) == "Basic") return reply(`Oops, Fitur Ini Khusus Untuk Akun Premium! Silahkan Upgrade akun anda`)
let axios = require('axios');
let id = args[0];
let zone = args[1];
        if (!id || !zone) {
          return reply(`GAME : Honkai: Star Rail\nMasukan ID dan Server dengan benar,\nGunakan salah satu server :\n> Asia = os_asia/prod_official_asia\n> America = os_usa/prod_official_usa\n> Europe = os_euro/prod_official_eurprod_official_eur\n> TW, HK, MO = os_cht/prod_official_cht\n contoh:\n*.cekhsr* 803952809 prod_official_asia`)
        }
const url = `https://${global.APIcek}/api/honkai-star-rail/?target=${id}&zone=${zone}&api_key=${global.KEYcek}`

axios.get(url)
  .then(response => {
  console.log(response.data);
      reply(`「 *Honkai: Star Rail* 」\n\n> Username : ${response.data.data.nickname}\n> ID : ${id}\n> Server : ${zone}\n\n${toko}`);
  })
  .catch(error => {
    console.error(error.response.data);
    if(error.response.data.code == "404") {
    reply("Oops, Nickname Tidak Dapat ditemukan")
    } else if (error.response.data.code = "422") {
    reply("Oops, Silahkan Input Userid dengan benar")
    }
  });
  }
  break
  
  case 'print': {
    let refId = q.split(" ")[0]; // Menyimpan ref_id yang ingin diperiksa

    if (!refId) {
        reply("Kamu belum memasukkan ref_id yang ingin diperiksa.\n\nContoh : print ZNxxxxx");
        return;
    }

    const filePath = './SETTING/DB/trxuser.json';
    try {
        const fileData = fs.readFileSync(filePath, 'utf8');
        const allUserData = JSON.parse(fileData);

        const userData = allUserData.find(data => data.ref_id === refId); // Mencari transaksi berdasarkan refId

        if (!userData) {
            return reply(`Oops, tidak dapat melakukan print silahkan cek refid pembelian`);
        }

        // Memanggil fungsi createReceipt dengan userData yang sesuai
        createReceipt(userData);
function createReceipt(userData) {
        const { createCanvas, loadImage } = require('canvas');
const path = require('path');
  const width = 800; // Lebar struk
  const height = 1200; // Tinggi struk
  const canvas = createCanvas(width, height);
  const context = canvas.getContext('2d');

  context.fillStyle = '#fff';
  context.fillRect(0, 0, width, height);

  context.textAlign = 'center';
  context.font = 'bold 30px Arial';
  context.fillStyle = '#000';
  context.fillText('ZANNSTORE', width / 2, 120); // Posisi disesuaikan
  context.textAlign = 'center';
  context.font = '25px Arial';
  context.fillText(`${userData.jam} | ${userData.waktu}`, width / 2, 150); // Posisi disesuaikan
  context.textAlign = 'center';
  context.font = 'italic 30px Arial';
  context.fillText('===============================', width / 2, 220);

  // Menambahkan detail transaksi dengan font yang lebih besar
  context.textAlign = 'center';
  context.font = 'bold 40px Arial';
  context.fillText('STRUK PEMBAYARAN', width / 2, 330);
  context.fillStyle = '#000';
  context.textAlign = 'left';
  context.font = 'serif 35px Arial';
  context.fillText(`\nID TRX : ${userData.ref_id}`, 10, 380);
  context.fillText(`\nLayanan : ${userData.produk}`, 10, 420);
  context.fillText(`\nTujuan : ${userData.tujuan}`, 10, 460);
  context.fillText(`\nHarga : ${formatmoney(userData.harga)}`, 10, 500);
  context.fillText(`\nStatus : Succes`, 10, 540);
  
  context.textAlign = 'center';
  context.font = 'bold 35px Arial';
  context.fillText('SN/KODE/TOKEN :', width / 2, 680);
  context.fillStyle = '#000';
  context.font = 'bold 14px Arial';
  context.fillText(`\n${userData.invoice}\n`, width / 2, 750);
  
  context.textAlign = 'center';
  context.font = 'italic 30px Arial';
  context.fillText('===============================', width / 2, 890);
  context.textAlign = 'center';
  context.font = 'italic 30px Arial';
  context.fillText('Menyediakan Pulsa, Data, Topup Game, Token PLN,\nBayar Tagihan Listrik, Pdam, Internet, etc', width / 2, 980);
  
  // Menambahkan instruksi di bawah serial number
  context.textAlign = 'center';
  context.font = 'italic 25px Arial';
  context.fillText('PT ZANNPAY INDONESIA', width / 2, 1080);


  

                // Simpan struk sebagai gambar PNG
                const buffer = canvas.toBuffer('image/png');
                fs.writeFileSync(`./SETTING/DB/TRANSACTION/${userData.ref_id}.png`, buffer);

                // Memanggil fungsi sendReceiptImage di dalam createReceipt setelah struk dibuat
                sendReceiptImage(`./SETTING/DB/TRANSACTION/${userData.ref_id}.png`);
           
        }

        // Fungsi untuk mengirim gambar struk
        function sendReceiptImage(filePath) {
            const fs = require('fs');
            let image = fs.readFileSync(filePath);
            AnanthaGanz.sendMessage(from, { image: image, caption: "Struk Pembelian" }, { quoted: m });
            // Hapus file setelah dikirim
            setTimeout(() => {
                fs.unlinkSync(filePath);
            }, 4000);
        }

        
    } catch (error) {
        console.error('Error reading the transaction history file:', error);
        reply("Gagal, Ada Masalah Ketika Membaca data, silahkan hubungi Admin");
    }
    break;
}

            default:
                if (budy.startsWith('=>')) {
                    if (!isOwner) return m.reply(mess.owner)
                    function Return(sul) {
                        sat = JSON.stringify(sul, null, 2)
                        bang = util.format(sat)
                            if (sat == undefined) {
                                bang = util.format(sul)
                            }
                            return m.reply(bang)
                    }
                    try {
                        m.reply(util.format(eval(`(async () => { return ${budy.slice(3)} })()`)))
                    } catch (e) {
                        m.reply(String(e))
                    }
                }

                if (budy.startsWith('>')) {
                    if (!isOwner) return m.reply(mess.owner)
                    try {
                        let evaled = await eval(budy.slice(2))
                        if (typeof evaled !== 'string') evaled = require('util').inspect(evaled)
                        await m.reply(evaled)
                    } catch (err) {
                        await m.reply(String(err))
                    }
                }

                if (budy.startsWith('$')) {
                    if (!isOwner) return m.reply(mess.owner)
                    exec(budy.slice(2), (err, stdout) => {
                        if (err) return m.reply(`${err}`)
                        if (stdout) return m.reply(stdout)
                    })
                }
		
			
	
        }
        

    } catch (err) {
        m.reply(util.format(err))
    }
}


let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
})
