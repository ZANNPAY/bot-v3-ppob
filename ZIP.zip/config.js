/**
   * Create By Anantha 
   * Contact Me on wa.me/6285174667722
*/

const fs = require('fs')
const chalk = require('chalk')

global.APIs = {
	zenz: 'https://api.zahwazein.xyz',
}
global.APIKeys = {
	'https://api.zahwazein.xyz': 'Your Key',
}
global.owner = ['6285174279764'] 
global.premium = ['6285174667722']
global.syarat = ['6285174667722']
global.botNumber = '6285174667722'
global.ownerNomor = '6285174667722'
global.botname = 'ZANNBOTZ' 
global.ownername = 'Anantha' 
global.footer = 'ZANNSTORE'
global.packname = `ZANNSTORE` 
global.toko = `© 𝟮𝟬𝟮𝟮 PT ZANNPAY INDONESIA`
global.sessionName = 'session.json'
global.prefa = ['','!','.','🐦','🐤','🗿']
global.grup = `https://chat.whatsapp.com/Ccvmx3e0oXoBb9rmUuWOEM`
global.apiNick = 'api-rekening.lfourr.com'
global.digiFlazz = 'api.digiflazz.com'
global.APIcek = "cekid.tokogar.com"
global.Wilayah = "Makassar"
global.antilink = false
global.emailNotif = "notifikasizannstore@gmail.com"
global.pwNotif = "wuuwzdkxjawhblws"
global.mess = {
wait: 'Nunggu bentar ya, lagi Loading...',
succes: 'Yes, Berhasil!',
admin: 'Oops, Hanya Admin Grup yang Boleh',
botAdmin: 'Waduh, Botnya Belum Jadi Admin',
owner: 'Maaf, Cuma Developer yang Bisa',
group: 'Aduh, Fitur Ini Khusus untuk Grup',
private: 'Maaf, Fitur Ini Hanya untuk Obrolan Pribadi',
bot: 'Aduh, Fitur Ini Hanya untuk Pengguna Bot!',
error: 'Ups, Ada Kesalahan...',
text: 'Hmm, Teksnya Kok Ga Ada Ya?'
}


let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update'${__filename}'`))
	delete require.cache[file]
	require(file)
})
