// API VIP RESELLER
global.keyId = 'PfGVOQmi' // API ID VIP RESELLER KAMU
global.signId = '7e9df2fe49bfb84eca62039b69b83fcf' // API Key VIP RESELLER KAMU
global.KEYcek = "420252ef-042c-4679-a30d-c2420d296d3a"
// API CEK NICK 
global.ceknickKey = 'UfFLvFcZRL1GOZv6A9PDNRWSUjgDtmNS'
global.cekpln = `https://ariepulsa.com/api/get-nickname-pln`
global.cekgame = `https://ariepulsa.com/api/get-nickname-game`
global.cekwallet = `https://ariepulsa.com/api/get-nickname-ewallet`
global.merchatapi = 'M230322MRRV4377FN'
global.signapi = '519e176a641606131fe5cb07f81030b4'
global.lolhumankey = 'digezzz'

// API PG PAYDISINI
global.key = 'eb58ca0f23696e8db6af1b3ae5e04165';

//API PAYMENT GATEWAY TOKOPAY 
global.merchant_id = 'M231204FSVYS378'
global.secret_key = 'f819ce792a81cc8235f2d8e804655beae69c736305eafdb133af8610c23fdad6'


const digiuser = 'recafeDbjwND'
const digiapi = 'key-tgxiubfkefgabysfgkdnbppwfxtoducs-zxyytfyou'

const nomorKu = `${owner}@s.whatsapp.net`

module.exports = {
    digiuser,
    digiapi,
    nomorKu
}