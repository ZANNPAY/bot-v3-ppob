const fs = require('fs');
const crypto = require('crypto');
const axios = require('axios');

function getLayanann(id_smm, key_smm, persesmm) {
    const url = "https://irvankedesmm.co.id/api/services";

        axios('https://irvankedesmm.co.id/api/services',{
method: 'POST',
data: new URLSearchParams(Object.entries({
api_id: id_smm,
api_key: key_smm,
}))}).then((response) => {
    if (response.data.status == false) {
            AnanthaGanz.sendMessage(from, { text: `${res.data.msg}`}, { quoted: m })
          } 
  if (response.data.status == true) {
  let data = JSON.stringify(response.data.data);
      fs.writeFileSync("./Pengaturan/database/irvanpanel.json", data);
      let dataup = JSON.parse(fs.readFileSync("./Pengaturan/database/irvanpanel.json"));
      let smmpers = persesmm;
      dataup.forEach((product) => (product.price + product.price * (smmpers / 100) + 100));
      let updatedData = JSON.stringify(dataup);
      fs.writeFileSync("./Pengaturan/database/irvanpanel.json", updatedData);
             }
            })
          }


module.exports = { getLayanann };